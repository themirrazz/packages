w96.sys.execCmd("monaco", ["C:/local/WScript/test.by.gemini.js"]).catch(error => {
    w96.sys.execCmd("textpad", ["C:/local/WScript/test.by.gemini.js"]);
});

w96.util.wait(320).then(_ => {
    w96.sys.execCmd("wscript", ["C:/local/WScript/test.by.gemini.js"])
});