//!wrt
alert("To finish uninstalling, please reboot your system.");