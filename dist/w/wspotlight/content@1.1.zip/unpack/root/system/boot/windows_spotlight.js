//!wrt $BSPEC:{"frn":"Windows Spotlight Boot Script","icn":"C:/local/WSpotlight/bingicon.png"}
await w96.sys.execFile('C:/local/WSpotlight/spotlight', []);