//!wrt $BSPEC:{"frn":"DynLib Loader (V2)","icn":"mime/library","dsc":"Adds a dynamic link library format for Windows 96","aut":"themirrazz"}
if(w96 && w96.sys) {
    w96.sys.hasDynLib = async function (id) {
        if(!(id.includes('/')||id.includes('\\'))) {
            id = `C:/system/local/lib/${id}.wll`;
        }
        return w96.FS.exists(id);
    };
    w96.sys.isDynLib = async function (path) {
        return (await w96.FS.readstr(path)).startsWith('//!wrtl');
    };
    w96.sys.getDynLib = async function (id) {
        if(!(id.includes('/')||id.includes('\\'))) {
            id = `C:/system/local/lib/${id}.wll`;
        }
        if(!await w96.sys.isDynLib(id)) {
            throw new Error('Path specified is not a dynamic library');
        }
        return await w96.WRT.runFile(id, { envType: 'dynlib' });
    };
}