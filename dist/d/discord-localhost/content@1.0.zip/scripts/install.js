(async () => {
    alert(
        [
            "You'll need to install the Discord localhost proxy on your computer. You can get",
            "it at https://github.com/themirrazz/discord96-proxy.",
            "",
            "NodeJS/NPM are required.",
            "",
            "You may need to install CORS Unblock/CORS Everywhere and/or HiFrame/Ignore X-Frame Options."
        ].join('<br>'),
        {
            title: "Discord (Localhosted)",
            icon: "error"
        }
    )
})();


(async () => {
    alert("Do you want to add Discord to your desktop?", {
        title: "Discord (Localhosted)",
        buttons: [
            {
                text: 'Yes',
                action: async e => {
                    try {
                        await w96.FS.cpfile('C:/system/programs/Network/Discord (Localhosted).link', 'C:/user/desktop/Discord (Localhosted).link');
                        e.dlg.close();
                    } catch (error) {
                        e.dlg.close();
                        alert(
                            "Failed to add to desktop!",
                            {
                                title: "Discord (Localhosted)",
                                icon: 'error'
                            }
                        );
                    }
                }
            },
            {
                text: 'No',
                action: e => e.dlg.close()
            }
        ]
    });
})();

(async () => {
    alert("Do you want Discord to launch at bootup?", {
        title: "Discord (Localhosted)",
        buttons: [
            {
                text: 'Yes',
                action: async e => {
                    try {
                        await w96.FS.cpfile('C:/system/programs/Network/Discord (Localhosted).link', 'C:/system/startup/Discord (Localhosted).link');
                        e.dlg.close();
                    } catch (error) {
                        e.dlg.close();
                        alert(
                            "Failed to add to startup programs!",
                            {
                                title: "Discord (Localhosted)",
                                icon: 'error'
                            }
                        );
                    }
                }
            },
            {
                text: 'No',
                action: e => e.dlg.close()
            }
        ]
    });
})();