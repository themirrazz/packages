const ipc = window.ipc = {
    target: parent,
    _send: (data) => {
        ipc.target.postMessage(JSON.stringify(data), '*');
    },
    indicate: (channel, data) => {
        ipc._send({
            type: 'indicate',
            channel,
            data
        });
    },
    _nonce: 0,
    ask: (channel, data) => {
        return new Promise(resolve => {
            const current = ipc._nonce;
            ipc._nonce += 1;
            /** @param {MessageEvent} event */
            const listener = event => {
                if(event.source !== ipc.target) return;
                const data = JSON.parse(event.data);
                if(data.type !== 'answer') return;
                if(data.nonce !== current) return;
                if(data.channel !== channel) return;
                window.removeEventListener('message', listener);
                resolve(data.data);
            };
            window.addEventListener('message', listener);
            ipc._send({
                type: 'ask',
                nonce: current,
                channel,
                data
            });
        });
    },
    when: (channel, handler) => {
        window.addEventListener('message', async event => {
            if(event.source !== ipc.target) return;
            const data = JSON.parse(event.data);
            if(data.type !== 'ask') return;
            if(data.channel !== channel) return;
            const result = await handler({
                type: 'AskEvent',
                channel: data.channel,
                data: data.data,
                raw: event.data
            });
            ipc._send({
                type: 'answer',
                nonce: data.nonce,
                channel: data.channel,
                data: result
            });
        });
    },
    on: (channel, action) => {
        window.addEventListener('message', event => {
            if(event.source !== ipc.target) return;
            const data = JSON.parse(event.data);
            if(data.type !== 'indicate') return;
            if(data.channel !== channel) return;
            action({
                type: 'IndicateEvent',
                data: data.data,
                channel: data.channel,
                raw: event.data
            });
        });
    }
};