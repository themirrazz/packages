//!wrt $BSPEC:{"frn": "Discord Updater (UI)","icn":"C:/local/discord/app.ico"}

const UPDATE_TIMEOUT_WAIT = 10000;
const RETRY_CAP_SECONDS = 60;
const LOADING_WINDOW_WIDTH = 300;
const LOADING_WINDOW_HEIGHT = 350;
const CHECKING_FOR_UPDATES = 'checking-for-updates';
const UPDATE_CHECK_FINISHED = 'update-check-finished';
const UPDATE_FAILURE = 'update-failure';
const LAUNCHING = 'launching';
const DOWNLOADING_MODULE = 'downloading-module';
const DOWNLOADING_UPDATES = 'downloading-updates';
const DOWNLOADING_MODULES_FINISHED = 'downloading-modules-finished';
const DOWNLOADING_MODULE_PROGRESS = 'downloading-module-progress';
const DOWNLOADED_MODULE = 'downloaded-module';
const NO_PENDING_UPDATES = 'no-pending-updates';
const INSTALLING_MODULE = 'installing-module';
const INSTALLING_UPDATES = 'installing-updates';
const INSTALLED_MODULE = 'installed-module';
const INSTALLING_MODULE_PROGRESS = 'installing-module-progress';
const INSTALLING_MODULES_FINISHED = 'installing-modules-finished';
const UPDATE_MANUALLY = 'update-manually';

class DiscordUpdater extends WApplication {
    constructor() {
        super();
    }

    async main(argv) {
        super.main(argv);
        const icon = await w96.FS.toURL("C:/local/discord/app.ico");
        const win = this.createWindow({
            title: "Discord Updater",
            taskbar: true,
            initialHeight: LOADING_WINDOW_HEIGHT,
            initialWidth: LOADING_WINDOW_WIDTH,
            body: "<iframe style='height: 100%; width: 100%; border: none; pointer-events: none;'></iframe>",
            center: true,
            icon,
            resizable: false,
            mobResize: false
        });
        const body = win.wndObject;
        body.querySelector('.titlebar').remove();
        body.querySelector('.titlebar-icon').remove();
        body.querySelector('.window-html-content').classList.remove('nodrag');
        const frame = body.querySelector('iframe');
        frame.src = '/_/C/local/discord/bootstrap/splash/index.html';
        win.show();
        const eventListeners = [];
        const context = frame.contentWindow;
        frame.onload = () => {
            context.DiscordSplash = {
                getReleaseChannel: () => {
                    return 'stable';
                },
                onStateUpdate: listener => eventListeners.push(listener),
                onQuoteUpdate: event => {},
                openUrl: url => {
                    w96.sys.execCmd('internete', [ url ]);
                },
                signalReady: () => {
                    // todo
                    setTimeout(launchDiscord, 300);
                },
                getBuildOverride: async () => {
                    throw 1
                }
            };
        }
        const launchDiscord = () => {
            eventListeners.forEach(e => e({
                status: LAUNCHING,
            }));
            setTimeout(() => {
                this.terminate();
                w96.sys.execFile('C:/local/discord/app/discord.js').catch(error => {
                    alert('Failed to launch discord', {
                        title: 'Discord',
                        icon: 'error'
                    });
                });
            }, 1000);
        };
    }
}

return await WApplication.execAsync(new DiscordUpdater(), this.boxedEnv.args);