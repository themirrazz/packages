//!wrt $BSPEC:{"frn": "Discord","icn":"C:/local/discord/app.ico"}

const path = this.launchCommand;
const similar = w96.state.processes.filter(process => {
    return process && process.execCtx.launchCommand === path;
});

if(similar[0]) {
    return similar[0].activate();
}

class DiscordApp extends WApplication {
    constructor() {
        super();
    }

    taskName = "Discord";
    title = "Discord";
    /** @type {w96.StandardWindow} */
    _win;

    async main(argv) {
        super.main(argv);
        this.title = "Discord"; // for task manager
        // window logic
        const hiddenWin = this.createWindow({ taskbar: false });
        const icon = await w96.FS.toURL("C:/local/discord/app.ico");
        const win = this._win = new w96.StandardWindow({
            center: true,
            body: "<iframe style='height: 100%; width: 100%; border: none;' allow='camera; microphone'></iframe>",
            taskbar: true,
            title: "Discord",
            initialHeight: window.innerHeight - 100,
            initialWidth: window.innerWidth - 200,
            icon,
            iframeFix: false
        });
        // get the main elements
        const body = win.wndObject;
        const frame = body.querySelector('iframe');
        const taskbar = document.getElementById(`${win.id}_appbar`);
        this._taskbar = taskbar;
        frame.src = `http://localhost:3000/embed?origin=${location.origin}`;
        // make it so closing the window minimizes it to the tray
        win.force_close = win.close;
        win.onclose = () => {
            if(!this._terminating) this.terminate();
        };
        win.close = () => {
            if(!win.minimized) win.toggleMinimize();
            taskbar.style.display = 'none';
        };
        // remove the built-in titlebar
        body.querySelector('.titlebar').style.display = 'none';
        if(body.querySelector('.titlebar-icon')) {
            body.querySelector('.titlebar-icon').style.display = 'none';
        }
        body.querySelector('.window-html-content').classList.remove('nodrag');
        // now we create our own
        win.getBodyContainer().style.position = 'relative';
        const customTitlebar = document.createElement('div');
        customTitlebar.style.position = 'absolute';
        customTitlebar.style.height = '32px';
        customTitlebar.style.width = 'calc(100% - 230px)';
        customTitlebar.style.top = '0px';
        customTitlebar.style.left = '0px';
        win.getBodyContainer().appendChild(customTitlebar);
        // mimic real behavior of Electron draggable areas
        customTitlebar.oncontextmenu = event => {
            win.showTitlebarMenu(event);
        };
        // tray icon
        const trayURL = await w96.FS.toURL("C:/local/discord/tray/tray@3x.png");
        const trayIcon = new w96.shell.NotifyIcon({
            tooltip: "Discord",
            onclick: ({ event }) => {
                if(event.button === 0 && win.shown) this.activate();
            },
            iconUrl: trayURL
        });
        w96.shell.Taskbar.registerNotifyIcon(trayIcon);
        // tray icon context menus
        const trayMenu = new w96.ui.ContextMenu([
            {
                type: 'normal',
                icon: trayURL,
                label: 'Discord',
                disabled: true
            },
            {
                type: 'separator'
            },
            {
                type: 'normal',
                label: 'Check for Updates...',
                onclick: () => {
                    alert('Feature unavailable.', { icon: 'error', title: 'Discord' });
                }
            },
            {
                type: 'normal',
                label: 'Acknowledgemenets',
                onclick: () => {
                    w96.urlopen('https://discord.com/acknowledgements');
                }
            },
            {
                type: 'separator'
            },
            {
                type: 'normal',
                label: 'Quit Discord',
                onclick: () => {
                    this.terminate();
                }
            }
        ]);
        let oldMenu;
        trayIcon.notifyEl.addEventListener('contextmenu', event => {
            if(oldMenu && oldMenu.parentNode) oldMenu.remove();
            const div = oldMenu = trayMenu.renderMenu(event.clientX, event.clientY);
            const newX = event.clientX - div.clientWidth;
            const newY = event.clientY - div.clientHeight;
            div.style.top = `${newY}px`;
            div.style.left = `${newX}px`;
        });
        // handle complete app termination
        hiddenWin.onclose = () => {
            trayIcon.destroy();
            win.force_close();
            // shelf.remove();
            if(fpw) fpw.close();
            if(kURD) kURD.close();
            window.removeEventListener('mousedown', onMouseDownChange);
            window.removeEventListener('mouseup', onMouseDownChange);
            clearTimeout(initUnresponsiveTimer);
        };
        hiddenWin.registerWindow();
        // we have to declare all the other windows right here
        // Issues with `let` and `const`
        /** @type {w96.StandardWindow} */
        let fpw = null;
        let isPickingFile = false;
        // iframe related stuff
        let mouseIsDown = false;
        /** @param {MouseEvent} event */
        const onMouseDownChange = event => {
            if(event.type === 'mousedown') {
                mouseIsDown = true;
            } else if(event.type === 'mouseup') {
                mouseIsDown = false;
            }
            updatePointerEvents();
        };
        window.addEventListener('mousedown', onMouseDownChange);
        window.addEventListener('mouseup', onMouseDownChange);
        const updatePointerEvents = () => {
            if(isPickingFile || mouseIsDown) {
                frame.style.pointerEvents = 'none';
                return;
            }
            frame.style.pointerEvents = '';
        };
        // If we don't get a signal from Discord,
        // we assume it hung or failed to load
        let initUnresponsiveTimer = 0;
        /** @type {Dialog} */
        let kURD;
        const setInitialUnResponsiveTimer = () => {
            initUnresponsiveTimer = setTimeout(() => {
                const dlg = new w96.ui.DialogCreator.Dialog({
                    title: "Discord",
                    icon: 'error',
                    body: "Sorry, we're having trouble loading Discord. Your internet might just be slow, or this could be a problem on our end. Do you want to restart Discord?",
                    buttons: [
                        {
                            text: "Wait",
                            action: event => {
                                dlg.close();
                            }
                        },
                        {
                            text: "Quit",
                            action: event => {
                                dlg.wnd.onclose = () => { };
                                this.terminate();
                            }
                        },
                        {
                            text: "Restart",
                            action: event => {
                                dlg.wnd.onclose = () => { };
                                this.terminate();
                                setTimeout(() => {
                                    w96.sys.execFile('C:/local/discord/updater.js');
                                }, 2400);
                            }
                        }
                    ]
                });
                kURD = dlg;
                clearTimeout(initUnresponsiveTimer);
                dlg.show();
                dlg.center();
                dlg.wnd.onclose = () => {
                    kURD = null;
                    setInitialUnResponsiveTimer();
                };
            }, 20000);
        };
        // actually start it
        setInitialUnResponsiveTimer();
        // IPC
        const ipc = await new Promise(resolve => {
            frame.onload = () => {
                const ipcWin = frame.contentWindow.frames[0];
                let ipc = {
                    on: (channel, cb) => { },
                    when: (channel, responder) => { },
                    ask: (channel, data) => { },
                    indicate: (channel, data) => { }
                };
                ipcWin.w96 = w96;
                ipcWin.kernel = window;
                w96.FS.readstr('C:/local/discord/app/mainScreenPreload.js').then(contents => {
                    ipcWin.eval(contents);
                    ipc = ipcWin.ipc;
                    resolve(ipc);
                });
            };
        });
        let lsData = await this.getLSData();
        await w96.util.wait(500);
        await ipc.ask('ready', {
            ls: lsData,
            // TODO: notifications
            nnCapable: window.sb_send ? true : false
        });
        // we know it's loaded now
        clearTimeout(initUnresponsiveTimer);
        if(kURD) kURD.close();
        // future features
        ipc.on('clicked-link', event => {
            if(event.data.type === 'launch') {
                w96.urlopen(event.data.url);
            } else if(event.data.type === 'download') {
                alert('Feature unavailable.', { icon: 'error', title: 'Discord' });
            }
        })
        // focus the window when you click inside it
        ipc.on('mouse-down', event => {
            if(!win.isActive()) win.activate();
        });
        // redirect local storage to local FS
        ipc.on('ls-set', event => {
            lsData[event.data.key] = event.data.value;
            w96.FS.writestr(
                'C:/user/appdata/Discord/localStorage.json',
                JSON.stringify(lsData)
            );
        });
        ipc.on('ls-rm', event => {
            lsData[event.data.key] = undefined;
            w96.FS.writestr(
                'C:/user/appdata/Discord/localStorage.json',
                JSON.stringify(lsData)
            );
        });
        ipc.on('ls-clear', _ => {
            lsData = { };
            w96.FS.writestr(
                'C:/user/appdata/Discord/localStorage.json',
                JSON.stringify(lsData)
            );
        });
        ipc.on('nn-show', event => {
            sb_send(event.data.title || 'Discord', event.data.options.body, event.data.options.icon || event.data.options.image || 'noicon')
        });
        ipc.on('nn-uncapable', _ => {
            alert("This feature requires a third-party dependency.", { icon: 'error', title: 'Discord' });
        });
        win.show();
        // notifications - every desktop app requires notifications!!
        // const shelf = document.createElement('div');
        // document.body.appendChild(shelf);
        // shelf.style.position = 'fixed';
        // shelf.style.zIndex = '99999999';
        // shelf.style.bottom = '20px';
        // shelf.style.right = '20px';
        // Now, for the fun stuff!
        // Preparing other tray icons
        const trayUnreadURL = await w96.FS.toURL("C:/local/discord/tray/tray-unread@3x.png");
        // Changing the window title dynamically
        ipc.on('window-title', event => {
            const data = this.parseDiscordTitle(event.data.title);
            if(data.change === false) return;
            win.setTitle(data.title + ' - Discord');
            if(data.unreads) {
                trayIcon.setIcon(trayUnreadURL);
            } else {
                trayIcon.setIcon(trayURL);
            }
        });
        // custom titlebar actions
        ipc.on('title-button', event => {
            if(event.data === 'close') win.close();
            else if(event.data === 'force-close') this.terminate();
            else if(event.data === 'maximize') win.toggleMaximize();
            else if(event.data === 'minimize') win.toggleMinimize();
        });
        // file uploads
        ipc.when('file-picker', event => {
            return new Promise(async resolve => {
                if(isPickingFile) {
                    return resolve({ ok: false });
                }
                isPickingFile = true;
                updatePointerEvents();
                const dlg = new w96.ui.OpenFileDialog(
                    'C:/user',
                    [ '' ],
                    async (path) => {
                        isPickingFile = false;
                        fpw = null;
                        updatePointerEvents();
                        if(path) {
                            try {
                                const buffer = await w96.FS.readbin(path);
                                const name = w96.FSUtil.fname(path);
                                resolve({
                                    ok: true,
                                    files: [
                                        { buffer: Array.from(buffer), name }
                                    ]
                                });
                            } catch (error) {
                                resolve({ ok: false });
                            }
                        } else {
                            resolve({ ok: false });
                        }
                    }
                );
                await dlg.show();
                fpw = dlg.dlg;
            });
        });
    }

    activate() {
        this._taskbar.style.display = '';
        if(this._win.minimized) this._win.toggleMinimize();
        this._win.activate();
    }

    async getLSData() {
        try {
            const raw = await w96.FS.readstr('C:/user/appdata/Discord/localStorage.json');
            return JSON.parse(raw);
        } catch (error) {
            if(!await w96.FS.exists('C:/user/appdata/Discord')) {
                await w96.FS.mkdir('C:/user/appdata/Discord');
            }
            w96.FS.writestr('C:/user/appdata/Discord/localStorage.json', '{}');
            return { };
        }
    }

    /**
     * @param {string} title
     */
    parseDiscordTitle(title) {
        if(title.charCodeAt(0) === 8226) {
            // Unreads, but no mentions
            return {
                title: title.slice(12),
                unreads: true,
                count: 0
            };
        } else if(title[0] === '(') {
            // Mentions
            const numEnd = title.indexOf(')');
            return {
                title: title.slice(numEnd + 12),
                count: Number(title.slice(1, numEnd)),
                unreads: true
            }
        } else if(title.startsWith('Discord |')) {
            // No unreads at all.
            return {
                title: title.slice(10),
                count: 0,
                unreads: false
            }
        } else {
            // Weird edge cases
            return { change: false }
        }
    }
}

return await WApplication.execAsync(new DiscordApp(), this.boxedEnv.args, this);