var DiscordSplash = {
    getReleaseChannel: () => {
        return 'stable';
    },
    onStateUpdate: event => {
        setTimeout(() => {
            event({ status: 'launching' });
        }, 1000);
    },
    onQuoteUpdate: e => {},
    signalReady: () => {},
    getBuildOverride: async () => {
        throw 1
    }
}