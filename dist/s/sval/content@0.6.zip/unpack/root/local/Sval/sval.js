!(function () {
  function _array_like_to_array(arr, len) {
    if (len == null || len > arr.length) len = arr.length;
    for (var i = 0, arr2 = new Array(len); i < len; i++) arr2[i] = arr[i];
    return arr2;
  }
  function _array_without_holes(arr) {
    if (Array.isArray(arr)) return _array_like_to_array(arr);
  }
  function _class_call_check(instance, Constructor) {
    if (!(instance instanceof Constructor)) {
      throw new TypeError("Cannot call a class as a function");
    }
  }
  function _construct(Parent, args, Class) {
    if (_is_native_reflect_construct()) {
      _construct = Reflect.construct;
    } else {
      _construct = function construct(Parent, args, Class) {
        var a = [null];
        a.push.apply(a, args);
        var Constructor = Function.bind.apply(Parent, a);
        var instance = new Constructor();
        if (Class) _set_prototype_of(instance, Class.prototype);
        return instance;
      };
    }
    return _construct.apply(null, arguments);
  }
  function _defineProperties(target, props) {
    for (var i = 0; i < props.length; i++) {
      var descriptor = props[i];
      descriptor.enumerable = descriptor.enumerable || false;
      descriptor.configurable = true;
      if ("value" in descriptor) descriptor.writable = true;
      Object.defineProperty(target, descriptor.key, descriptor);
    }
  }
  function _create_class(Constructor, protoProps, staticProps) {
    if (protoProps) _defineProperties(Constructor.prototype, protoProps);
    if (staticProps) _defineProperties(Constructor, staticProps);
    return Constructor;
  }
  function _define_property(obj, key, value) {
    if (key in obj) {
      Object.defineProperty(obj, key, {
        value: value,
        enumerable: true,
        configurable: true,
        writable: true,
      });
    } else {
      obj[key] = value;
    }
    return obj;
  }
  function _instanceof(left, right) {
    if (
      right != null &&
      typeof Symbol !== "undefined" &&
      right[Symbol.hasInstance]
    ) {
      return !!right[Symbol.hasInstance](left);
    } else {
      return left instanceof right;
    }
  }
  function _iterable_to_array(iter) {
    if (
      (typeof Symbol !== "undefined" && iter[Symbol.iterator] != null) ||
      iter["@@iterator"] != null
    )
      return Array.from(iter);
  }
  function _non_iterable_spread() {
    throw new TypeError(
      "Invalid attempt to spread non-iterable instance.\\nIn order to be iterable, non-array objects must have a [Symbol.iterator]() method."
    );
  }
  function _set_prototype_of(o, p) {
    _set_prototype_of =
      Object.setPrototypeOf ||
      function setPrototypeOf(o, p) {
        o.__proto__ = p;
        return o;
      };
    return _set_prototype_of(o, p);
  }
  function _to_consumable_array(arr) {
    return (
      _array_without_holes(arr) ||
      _iterable_to_array(arr) ||
      _unsupported_iterable_to_array(arr) ||
      _non_iterable_spread()
    );
  }
  function _type_of(obj) {
    "@swc/helpers - typeof";
    return obj && typeof Symbol !== "undefined" && obj.constructor === Symbol
      ? "symbol"
      : typeof obj;
  }
  function _unsupported_iterable_to_array(o, minLen) {
    if (!o) return;
    if (typeof o === "string") return _array_like_to_array(o, minLen);
    var n = Object.prototype.toString.call(o).slice(8, -1);
    if (n === "Object" && o.constructor) n = o.constructor.name;
    if (n === "Map" || n === "Set") return Array.from(n);
    if (n === "Arguments" || /^(?:Ui|I)nt(?:8|16|32)(?:Clamped)?Array$/.test(n))
      return _array_like_to_array(o, minLen);
  }
  function _is_native_reflect_construct() {
    try {
      var result = !Boolean.prototype.valueOf.call(
        Reflect.construct(Boolean, [], function () {})
      );
    } catch (_) {}
    return (_is_native_reflect_construct = function () {
      return !!result;
    })();
  }
  function _ts_generator(thisArg, body) {
    var f,
      y,
      t,
      _ = {
        label: 0,
        sent: function () {
          if (t[0] & 1) throw t[1];
          return t[1];
        },
        trys: [],
        ops: [],
      },
      g = Object.create(
        (typeof Iterator === "function" ? Iterator : Object).prototype
      );
    return (
      (g.next = verb(0)),
      (g["throw"] = verb(1)),
      (g["return"] = verb(2)),
      typeof Symbol === "function" &&
        (g[Symbol.iterator] = function () {
          return this;
        }),
      g
    );
    function verb(n) {
      return function (v) {
        return step([n, v]);
      };
    }
    function step(op) {
      if (f) throw new TypeError("Generator is already executing.");
      while ((g && ((g = 0), op[0] && (_ = 0)), _))
        try {
          if (
            ((f = 1),
            y &&
              (t =
                op[0] & 2
                  ? y["return"]
                  : op[0]
                  ? y["throw"] || ((t = y["return"]) && t.call(y), 0)
                  : y.next) &&
              !(t = t.call(y, op[1])).done)
          )
            return t;
          if (((y = 0), t)) op = [op[0] & 2, t.value];
          switch (op[0]) {
            case 0:
            case 1:
              t = op;
              break;
            case 4:
              _.label++;
              return { value: op[1], done: false };
            case 5:
              _.label++;
              y = op[1];
              op = [0];
              continue;
            case 7:
              op = _.ops.pop();
              _.trys.pop();
              continue;
            default:
              if (
                !((t = _.trys), (t = t.length > 0 && t[t.length - 1])) &&
                (op[0] === 6 || op[0] === 2)
              ) {
                _ = 0;
                continue;
              }
              if (op[0] === 3 && (!t || (op[1] > t[0] && op[1] < t[3]))) {
                _.label = op[1];
                break;
              }
              if (op[0] === 6 && _.label < t[1]) {
                _.label = t[1];
                t = op;
                break;
              }
              if (t && _.label < t[2]) {
                _.label = t[2];
                _.ops.push(op);
                break;
              }
              if (t[2]) _.ops.pop();
              _.trys.pop();
              continue;
          }
          op = body.call(thisArg, _);
        } catch (e) {
          op = [6, e];
          y = 0;
        } finally {
          f = t = 0;
        }
      if (op[0] & 5) throw op[1];
      return { value: op[0] ? op[1] : void 0, done: true };
    }
  }
  function _ts_values(o) {
    var s = typeof Symbol === "function" && Symbol.iterator,
      m = s && o[s],
      i = 0;
    if (m) return m.call(o);
    if (o && typeof o.length === "number")
      return {
        next: function () {
          if (o && i >= o.length) o = void 0;
          return { value: o && o[i++], done: !o };
        },
      };
    throw new TypeError(
      s ? "Object is not iterable." : "Symbol.iterator is not defined."
    );
  }
  (function (Ve, Te) {
    (typeof exports === "undefined" ? "undefined" : _type_of(exports)) ==
      "object" &&
    (typeof module === "undefined" ? "undefined" : _type_of(module)) < "u"
      ? (module.exports = Te())
      : typeof define == "function" && define.amd
      ? define(Te)
      : ((Ve =
          (typeof globalThis === "undefined"
            ? "undefined"
            : _type_of(globalThis)) < "u"
            ? globalThis
            : Ve || self),
        (Ve.Sval = Te()));
  })(this, function _target() {
    "use strict";
    var Ve = Object.freeze(
        Object.defineProperty(
          {
            __proto__: null,
            get BlockStatement() {
              return ae;
            },
            get BreakStatement() {
              return za;
            },
            get CatchClause() {
              return ji;
            },
            get ContinueStatement() {
              return Ga;
            },
            get DebuggerStatement() {
              return qa;
            },
            get DoWhileStatement() {
              return $i;
            },
            get EmptyStatement() {
              return $a;
            },
            get ExpressionStatement() {
              return Ua;
            },
            get ForInStatement() {
              return Wi;
            },
            get ForOfStatement() {
              return zi;
            },
            get ForStatement() {
              return qi;
            },
            get IfStatement() {
              return Oi;
            },
            get LabeledStatement() {
              return Ha;
            },
            get ReturnStatement() {
              return Wa;
            },
            get SwitchCase() {
              return Fi;
            },
            get SwitchStatement() {
              return Di;
            },
            get ThrowStatement() {
              return Ka;
            },
            get TryStatement() {
              return Mi;
            },
            get WhileStatement() {
              return Ui;
            },
            get WithStatement() {
              return Bi;
            },
          },
          Symbol.toStringTag,
          { value: "Module" }
        )
      ),
      Te = Object.freeze(
        Object.defineProperty(
          {
            __proto__: null,
            get ClassBody() {
              return Hi;
            },
            get ClassDeclaration() {
              return Xa;
            },
            get ExportAllDeclaration() {
              return es;
            },
            get ExportDefaultDeclaration() {
              return Za;
            },
            get ExportNamedDeclaration() {
              return Ja;
            },
            get FunctionDeclaration() {
              return Qa;
            },
            get ImportDeclaration() {
              return Ya;
            },
            get MethodDefinition() {
              return Ki;
            },
            get PropertyDefinition() {
              return It;
            },
            get StaticBlock() {
              return Qi;
            },
            get VariableDeclaration() {
              return xe;
            },
            get VariableDeclarator() {
              return Gi;
            },
          },
          Symbol.toStringTag,
          { value: "Module" }
        )
      ),
      xr = Object.freeze(
        Object.defineProperty(
          {
            __proto__: null,
            get BlockStatement() {
              return se;
            },
            get BreakStatement() {
              return Vs;
            },
            get CatchClause() {
              return or;
            },
            get ContinueStatement() {
              return Ts;
            },
            get DebuggerStatement() {
              return Ps;
            },
            get DoWhileStatement() {
              return lr;
            },
            get EmptyStatement() {
              return As;
            },
            get ExpressionStatement() {
              return Is;
            },
            get ForInStatement() {
              return hr;
            },
            get ForOfStatement() {
              return fr;
            },
            get ForStatement() {
              return cr;
            },
            get IfStatement() {
              return rr;
            },
            get LabeledStatement() {
              return Ns;
            },
            get ReturnStatement() {
              return Ls;
            },
            get SwitchCase() {
              return sr;
            },
            get SwitchStatement() {
              return ar;
            },
            get ThrowStatement() {
              return Rs;
            },
            get TryStatement() {
              return nr;
            },
            get WhileStatement() {
              return ur;
            },
            get WithStatement() {
              return ir;
            },
          },
          Symbol.toStringTag,
          { value: "Module" }
        )
      ),
      br = Object.freeze(
        Object.defineProperty(
          {
            __proto__: null,
            get ClassBody() {
              return dr;
            },
            get ClassDeclaration() {
              return Os;
            },
            get ExportAllDeclaration() {
              return js;
            },
            get ExportDefaultDeclaration() {
              return Fs;
            },
            get ExportNamedDeclaration() {
              return Ms;
            },
            get FunctionDeclaration() {
              return Bs;
            },
            get ImportDeclaration() {
              return Ds;
            },
            get MethodDefinition() {
              return yr;
            },
            get PropertyDefinition() {
              return Pt;
            },
            get StaticBlock() {
              return mr;
            },
            get VariableDeclaration() {
              return be;
            },
            get VariableDeclarator() {
              return pr;
            },
          },
          Symbol.toStringTag,
          { value: "Module" }
        )
      ),
      ze = Object.freeze,
      w = Object.defineProperty,
      ue = Object.getOwnPropertyDescriptor,
      vr = Object.prototype.hasOwnProperty;
    function lt(e, t) {
      return vr.call(e, t);
    }
    var ct = Object.getOwnPropertyNames,
      Bt = Object.setPrototypeOf;
    function Sr(e, t) {
      Bt ? Bt(e, t) : (e.__proto__ = t);
    }
    var Ot = Object.getPrototypeOf;
    function Dt(e) {
      return Ot ? Ot(e) : e.__proto__;
    }
    var wr = Object.getOwnPropertyDescriptor;
    function Ft(e, t, r) {
      for (; t; ) {
        var i = wr(t, r),
          a =
            (typeof i === "undefined" ? "undefined" : _type_of(i)) < "u" &&
            _type_of(i.writable) > "u" &&
            typeof i[e] == "function" &&
            i[e];
        if (a) return a;
        t = Dt(t);
      }
    }
    function Mt(e, t) {
      return Ft("get", e, t);
    }
    function jt(e, t) {
      return Ft("set", e, t);
    }
    var ve = Object.create;
    function Ut(e, t) {
      Sr(e, t),
        (e.prototype = ve(t.prototype, {
          constructor: { value: e, writable: !0 },
        }));
    }
    function Ge(e, t) {
      var r =
        arguments.length > 2 && arguments[2] !== void 0 ? arguments[2] : [];
      var i = !1;
      try {
        i = !Boolean.prototype.valueOf.call(
          Reflect.construct(Boolean, [], function () {})
        );
      } catch (e) {}
      return i ? Reflect.construct(t, r, Dt(e).constructor) : t.apply(e, r);
    }
    function kr(e) {
      for (var t = 1; t < arguments.length; ++t) {
        var r = arguments[t];
        for (var i in r) lt(r, i) && (e[i] = r[i]);
      }
      return e;
    }
    var N = Object.assign || kr;
    var He = [],
      f = ve(null);
    var Ke = function (e) {
      if (!e.Object) throw 0;
      He = ct((f = e)).filter(function (t) {
        return ["webkitStorageInfo", "GLOBAL", "root"].indexOf(t) === -1;
      });
    };
    try {
      Ke(window);
    } catch (e) {
      try {
        Ke(self);
      } catch (e) {
        try {
          Ke(global);
        } catch (e) {
          try {
            Ke(globalThis);
          } catch (e) {
            try {
              f.Object = Object;
            } catch (e) {}
            try {
              f.Function = Function;
            } catch (e) {}
            try {
              f.Array = Array;
            } catch (e) {}
            try {
              f.Number = Number;
            } catch (e) {}
            try {
              f.parseFloat = parseFloat;
            } catch (e) {}
            try {
              f.parseInt = parseInt;
            } catch (e) {}
            try {
              f.Infinity = 1 / 0;
            } catch (e) {}
            try {
              f.NaN = NaN;
            } catch (e) {}
            try {
              f.undefined = void 0;
            } catch (e) {}
            try {
              f.Boolean = Boolean;
            } catch (e) {}
            try {
              f.String = String;
            } catch (e) {}
            try {
              f.Symbol = Symbol;
            } catch (e) {}
            try {
              f.Date = Date;
            } catch (e) {}
            try {
              f.Promise = Promise;
            } catch (e) {}
            try {
              f.RegExp = RegExp;
            } catch (e) {}
            try {
              f.Error = Error;
            } catch (e) {}
            try {
              f.EvalError = EvalError;
            } catch (e) {}
            try {
              f.RangeError = RangeError;
            } catch (e) {}
            try {
              f.ReferenceError = ReferenceError;
            } catch (e) {}
            try {
              f.SyntaxError = SyntaxError;
            } catch (e) {}
            try {
              f.TypeError = TypeError;
            } catch (e) {}
            try {
              f.URIError = URIError;
            } catch (e) {}
            try {
              f.JSON = JSON;
            } catch (e) {}
            try {
              f.Math = Math;
            } catch (e) {}
            try {
              f.console = console;
            } catch (e) {}
            try {
              f.Intl = Intl;
            } catch (e) {}
            try {
              f.ArrayBuffer = ArrayBuffer;
            } catch (e) {}
            try {
              f.Uint8Array = Uint8Array;
            } catch (e) {}
            try {
              f.Int8Array = Int8Array;
            } catch (e) {}
            try {
              f.Uint16Array = Uint16Array;
            } catch (e) {}
            try {
              f.Int16Array = Int16Array;
            } catch (e) {}
            try {
              f.Uint32Array = Uint32Array;
            } catch (e) {}
            try {
              f.Int32Array = Int32Array;
            } catch (e) {}
            try {
              f.Float32Array = Float32Array;
            } catch (e) {}
            try {
              f.Float64Array = Float64Array;
            } catch (e) {}
            try {
              f.Uint8ClampedArray = Uint8ClampedArray;
            } catch (e) {}
            try {
              f.DataView = DataView;
            } catch (e) {}
            try {
              f.Map = Map;
            } catch (e) {}
            try {
              f.Set = Set;
            } catch (e) {}
            try {
              f.WeakMap = WeakMap;
            } catch (e) {}
            try {
              f.WeakSet = WeakSet;
            } catch (e) {}
            try {
              f.Proxy = Proxy;
            } catch (e) {}
            try {
              f.Reflect = Reflect;
            } catch (e) {}
            try {
              f.BigInt = BigInt;
            } catch (e) {}
            try {
              f.decodeURI = decodeURI;
            } catch (e) {}
            try {
              f.decodeURIComponent = decodeURIComponent;
            } catch (e) {}
            try {
              f.encodeURI = encodeURI;
            } catch (e) {}
            try {
              f.encodeURIComponent = encodeURIComponent;
            } catch (e) {}
            try {
              f.escape = escape;
            } catch (e) {}
            try {
              f.unescape = unescape;
            } catch (e) {}
            try {
              f.eval = eval;
            } catch (e) {}
            try {
              f.isFinite = isFinite;
            } catch (e) {}
            try {
              f.isNaN = isNaN;
            } catch (e) {}
            try {
              f.SharedArrayBuffer = SharedArrayBuffer;
            } catch (e) {}
            try {
              f.Atomics = Atomics;
            } catch (e) {}
            try {
              f.WebAssembly = WebAssembly;
            } catch (e) {}
            try {
              f.clearInterval = clearInterval;
            } catch (e) {}
            try {
              f.clearTimeout = clearTimeout;
            } catch (e) {}
            try {
              f.setInterval = setInterval;
            } catch (e) {}
            try {
              f.setTimeout = setTimeout;
            } catch (e) {}
            try {
              f.crypto = crypto;
            } catch (e) {}
            try {
              f.URL = URL;
            } catch (e) {}
            He = ct(f);
          }
        }
      }
    }
    f.Symbol &&
      (!f.Symbol.iterator && (f.Symbol.iterator = R("iterator")),
      !f.Symbol.asyncIterator && (f.Symbol.asyncIterator = R("asynciterator")));
    var $t = ve({});
    for (var e = 0; e < He.length; e++) {
      var t = He[e];
      try {
        $t[t] = f[t];
      } catch (e) {}
    }
    var Ne = R("window");
    function Er() {
      return N(ve(_define_property({}, Ne, f)), $t);
    }
    function R(e) {
      return e + Math.random().toString(36).substring(2);
    }
    function Cr(e) {
      var t;
      if (
        (typeof Symbol == "function" &&
          ((t = e[Symbol.asyncIterator]), !t && (t = e[Symbol.iterator])),
        t)
      )
        return t.call(e);
      if (typeof e.next == "function") return e;
      {
        var r = 0;
        return {
          next: function next() {
            return (
              e && r >= e.length && (e = void 0),
              { value: e && e[r++], done: !e }
            );
          },
        };
      }
    }
    var _r = [
        509, 0, 227, 0, 150, 4, 294, 9, 1368, 2, 2, 1, 6, 3, 41, 2, 5, 0, 166,
        1, 574, 3, 9, 9, 7, 9, 32, 4, 318, 1, 80, 3, 71, 10, 50, 3, 123, 2, 54,
        14, 32, 10, 3, 1, 11, 3, 46, 10, 8, 0, 46, 9, 7, 2, 37, 13, 2, 9, 6, 1,
        45, 0, 13, 2, 49, 13, 9, 3, 2, 11, 83, 11, 7, 0, 3, 0, 158, 11, 6, 9, 7,
        3, 56, 1, 2, 6, 3, 1, 3, 2, 10, 0, 11, 1, 3, 6, 4, 4, 68, 8, 2, 0, 3, 0,
        2, 3, 2, 4, 2, 0, 15, 1, 83, 17, 10, 9, 5, 0, 82, 19, 13, 9, 214, 6, 3,
        8, 28, 1, 83, 16, 16, 9, 82, 12, 9, 9, 7, 19, 58, 14, 5, 9, 243, 14,
        166, 9, 71, 5, 2, 1, 3, 3, 2, 0, 2, 1, 13, 9, 120, 6, 3, 6, 4, 0, 29, 9,
        41, 6, 2, 3, 9, 0, 10, 10, 47, 15, 343, 9, 54, 7, 2, 7, 17, 9, 57, 21,
        2, 13, 123, 5, 4, 0, 2, 1, 2, 6, 2, 0, 9, 9, 49, 4, 2, 1, 2, 4, 9, 9,
        330, 3, 10, 1, 2, 0, 49, 6, 4, 4, 14, 10, 5350, 0, 7, 14, 11465, 27,
        2343, 9, 87, 9, 39, 4, 60, 6, 26, 9, 535, 9, 470, 0, 2, 54, 8, 3, 82, 0,
        12, 1, 19628, 1, 4178, 9, 519, 45, 3, 22, 543, 4, 4, 5, 9, 7, 3, 6, 31,
        3, 149, 2, 1418, 49, 513, 54, 5, 49, 9, 0, 15, 0, 23, 4, 2, 14, 1361, 6,
        2, 16, 3, 6, 2, 1, 2, 4, 101, 0, 161, 6, 10, 9, 357, 0, 62, 13, 499, 13,
        245, 1, 2, 9, 726, 6, 110, 6, 6, 9, 4759, 9, 787719, 239,
      ],
      qt = [
        0, 11, 2, 25, 2, 18, 2, 1, 2, 14, 3, 13, 35, 122, 70, 52, 268, 28, 4,
        48, 48, 31, 14, 29, 6, 37, 11, 29, 3, 35, 5, 7, 2, 4, 43, 157, 19, 35,
        5, 35, 5, 39, 9, 51, 13, 10, 2, 14, 2, 6, 2, 1, 2, 10, 2, 14, 2, 6, 2,
        1, 4, 51, 13, 310, 10, 21, 11, 7, 25, 5, 2, 41, 2, 8, 70, 5, 3, 0, 2,
        43, 2, 1, 4, 0, 3, 22, 11, 22, 10, 30, 66, 18, 2, 1, 11, 21, 11, 25, 71,
        55, 7, 1, 65, 0, 16, 3, 2, 2, 2, 28, 43, 28, 4, 28, 36, 7, 2, 27, 28,
        53, 11, 21, 11, 18, 14, 17, 111, 72, 56, 50, 14, 50, 14, 35, 39, 27, 10,
        22, 251, 41, 7, 1, 17, 2, 60, 28, 11, 0, 9, 21, 43, 17, 47, 20, 28, 22,
        13, 52, 58, 1, 3, 0, 14, 44, 33, 24, 27, 35, 30, 0, 3, 0, 9, 34, 4, 0,
        13, 47, 15, 3, 22, 0, 2, 0, 36, 17, 2, 24, 20, 1, 64, 6, 2, 0, 2, 3, 2,
        14, 2, 9, 8, 46, 39, 7, 3, 1, 3, 21, 2, 6, 2, 1, 2, 4, 4, 0, 19, 0, 13,
        4, 31, 9, 2, 0, 3, 0, 2, 37, 2, 0, 26, 0, 2, 0, 45, 52, 19, 3, 21, 2,
        31, 47, 21, 1, 2, 0, 185, 46, 42, 3, 37, 47, 21, 0, 60, 42, 14, 0, 72,
        26, 38, 6, 186, 43, 117, 63, 32, 7, 3, 0, 3, 7, 2, 1, 2, 23, 16, 0, 2,
        0, 95, 7, 3, 38, 17, 0, 2, 0, 29, 0, 11, 39, 8, 0, 22, 0, 12, 45, 20, 0,
        19, 72, 200, 32, 32, 8, 2, 36, 18, 0, 50, 29, 113, 6, 2, 1, 2, 37, 22,
        0, 26, 5, 2, 1, 2, 31, 15, 0, 328, 18, 16, 0, 2, 12, 2, 33, 125, 0, 80,
        921, 103, 110, 18, 195, 2637, 96, 16, 1071, 18, 5, 26, 3994, 6, 582,
        6842, 29, 1763, 568, 8, 30, 18, 78, 18, 29, 19, 47, 17, 3, 32, 20, 6,
        18, 433, 44, 212, 63, 129, 74, 6, 0, 67, 12, 65, 1, 2, 0, 29, 6135, 9,
        1237, 42, 9, 8936, 3, 2, 6, 2, 1, 2, 290, 16, 0, 30, 2, 3, 0, 15, 3, 9,
        395, 2309, 106, 6, 12, 4, 8, 8, 9, 5991, 84, 2, 70, 2, 1, 3, 0, 3, 1, 3,
        3, 2, 11, 2, 0, 2, 6, 2, 64, 2, 3, 3, 7, 2, 6, 2, 27, 2, 3, 2, 4, 2, 0,
        4, 6, 2, 339, 3, 24, 2, 24, 2, 30, 2, 24, 2, 30, 2, 24, 2, 30, 2, 24, 2,
        30, 2, 24, 2, 7, 1845, 30, 7, 5, 262, 61, 147, 44, 11, 6, 17, 0, 322,
        29, 19, 43, 485, 27, 229, 29, 3, 0, 496, 6, 2, 3, 2, 1, 2, 14, 2, 196,
        60, 67, 8, 0, 1205, 3, 2, 26, 2, 1, 2, 0, 3, 0, 2, 9, 2, 3, 2, 0, 2, 0,
        7, 0, 5, 0, 2, 0, 2, 0, 2, 2, 2, 1, 2, 0, 3, 0, 2, 0, 2, 0, 2, 0, 2, 0,
        2, 1, 2, 0, 3, 3, 2, 6, 2, 3, 2, 3, 2, 0, 2, 9, 2, 16, 6, 2, 2, 4, 2,
        16, 4421, 42719, 33, 4153, 7, 221, 3, 5761, 15, 7472, 16, 621, 2467,
        541, 1507, 4938, 6, 4191,
      ],
      Ir =
        "‌‍\xb7̀-ͯ·҃-֑҇-ׇֽֿׁׂׅׄؐ-ًؚ-٩ٰۖ-ۜ۟-۪ۤۧۨ-ۭ۰-۹ܑܰ-݊ަ-ް߀-߉߫-߽߳ࠖ-࠙ࠛ-ࠣࠥ-ࠧࠩ-࡙࠭-࡛ࢗ-࢟࣊-ࣣ࣡-ःऺ-़ा-ॏ॑-ॗॢॣ०-९ঁ-ঃ়া-ৄেৈো-্ৗৢৣ০-৯৾ਁ-ਃ਼ਾ-ੂੇੈੋ-੍ੑ੦-ੱੵઁ-ઃ઼ા-ૅે-ૉો-્ૢૣ૦-૯ૺ-૿ଁ-ଃ଼ା-ୄେୈୋ-୍୕-ୗୢୣ୦-୯ஂா-ூெ-ைொ-்ௗ௦-௯ఀ-ఄ఼ా-ౄె-ైొ-్ౕౖౢౣ౦-౯ಁ-ಃ಼ಾ-ೄೆ-ೈೊ-್ೕೖೢೣ೦-೯ೳഀ-ഃ഻഼ാ-ൄെ-ൈൊ-്ൗൢൣ൦-൯ඁ-ඃ්ා-ුූෘ-ෟ෦-෯ෲෳัิ-ฺ็-๎๐-๙ັິ-ຼ່-໎໐-໙༘༙༠-༩༹༵༷༾༿ཱ-྄྆྇ྍ-ྗྙ-ྼ࿆ါ-ှ၀-၉ၖ-ၙၞ-ၠၢ-ၤၧ-ၭၱ-ၴႂ-ႍႏ-ႝ፝-፟፩-፱ᜒ-᜕ᜲ-᜴ᝒᝓᝲᝳ឴-៓៝០-៩᠋-᠍᠏-᠙ᢩᤠ-ᤫᤰ-᤻᥆-᥏᧐-᧚ᨗ-ᨛᩕ-ᩞ᩠-᩿᩼-᪉᪐-᪙᪰-᪽ᪿ-ᫎᬀ-ᬄ᬴-᭄᭐-᭙᭫-᭳ᮀ-ᮂᮡ-ᮭ᮰-᮹᯦-᯳ᰤ-᰷᱀-᱉᱐-᱙᳐-᳔᳒-᳨᳭᳴᳷-᳹᷀-᷿‌‍‿⁀⁔⃐-⃥⃜⃡-⃰⳯-⵿⳱ⷠ-〪ⷿ-゙゚〯・꘠-꘩꙯ꙴ-꙽ꚞꚟ꛰꛱ꠂ꠆ꠋꠣ-ꠧ꠬ꢀꢁꢴ-ꣅ꣐-꣙꣠-꣱ꣿ-꤉ꤦ-꤭ꥇ-꥓ꦀ-ꦃ꦳-꧀꧐-꧙ꧥ꧰-꧹ꨩ-ꨶꩃꩌꩍ꩐-꩙ꩻ-ꩽꪰꪲ-ꪴꪷꪸꪾ꪿꫁ꫫ-ꫯꫵ꫶ꯣ-ꯪ꯬꯭꯰-꯹ﬞ︀-️︠-︯︳︴﹍-﹏０-９＿･",
      Wt =
        "\xaa\xb5\xba\xc0-\xd6\xd8-\xf6\xf8-ˁˆ-ˑˠ-ˤˬˮͰ-ʹͶͷͺ-ͽͿΆΈ-ΊΌΎ-ΡΣ-ϵϷ-ҁҊ-ԯԱ-Ֆՙՠ-ֈא-תׯ-ײؠ-يٮٯٱ-ۓەۥۦۮۯۺ-ۼۿܐܒ-ܯݍ-ޥޱߊ-ߪߴߵߺࠀ-ࠕࠚࠤࠨࡀ-ࡘࡠ-ࡪࡰ-ࢇࢉ-ࢎࢠ-ࣉऄ-हऽॐक़-ॡॱ-ঀঅ-ঌএঐও-নপ-রলশ-হঽৎড়ঢ়য়-ৡৰৱৼਅ-ਊਏਐਓ-ਨਪ-ਰਲਲ਼ਵਸ਼ਸਹਖ਼-ੜਫ਼ੲ-ੴઅ-ઍએ-ઑઓ-નપ-રલળવ-હઽૐૠૡૹଅ-ଌଏଐଓ-ନପ-ରଲଳଵ-ହଽଡ଼ଢ଼ୟ-ୡୱஃஅ-ஊஎ-ஐஒ-கஙசஜஞடணதந-பம-ஹௐఅ-ఌఎ-ఐఒ-నప-హఽౘ-ౚౝౠౡಀಅ-ಌಎ-ಐಒ-ನಪ-ಳವ-ಹಽೝೞೠೡೱೲഄ-ഌഎ-ഐഒ-ഺഽൎൔ-ൖൟ-ൡൺ-ൿඅ-ඖක-නඳ-රලව-ෆก-ะาำเ-ๆກຂຄຆ-ຊຌ-ຣລວ-ະາຳຽເ-ໄໆໜ-ໟༀཀ-ཇཉ-ཬྈ-ྌက-ဪဿၐ-ၕၚ-ၝၡၥၦၮ-ၰၵ-ႁႎႠ-ჅჇჍა-ჺჼ-ቈቊ-ቍቐ-ቖቘቚ-ቝበ-ኈኊ-ኍነ-ኰኲ-ኵኸ-ኾዀዂ-ዅወ-ዖዘ-ጐጒ-ጕጘ-ፚᎀ-ᎏᎠ-Ᏽᏸ-ᏽᐁ-ᙬᙯ-ᙿᚁ-ᚚᚠ-ᛪᛮ-ᛸᜀ-ᜑᜟ-ᜱᝀ-ᝑᝠ-ᝬᝮ-ᝰក-ឳៗៜᠠ-ᡸᢀ-ᢨᢪᢰ-ᣵᤀ-ᤞᥐ-ᥭᥰ-ᥴᦀ-ᦫᦰ-ᧉᨀ-ᨖᨠ-ᩔᪧᬅ-ᬳᭅ-ᭌᮃ-ᮠᮮᮯᮺ-ᯥᰀ-ᰣᱍ-ᱏᱚ-ᱽᲀ-ᲊᲐ-ᲺᲽ-Ჿᳩ-ᳬᳮ-ᳳᳵᳶᳺᴀ-ᶿḀ-ἕἘ-Ἕἠ-ὅὈ-Ὅὐ-ὗὙὛὝὟ-ώᾀ-ᾴᾶ-ᾼιῂ-ῄῆ-ῌῐ-ΐῖ-Ίῠ-Ῥῲ-ῴῶ-ῼⁱⁿₐ-ₜℂℇℊ-ℓℕ℘-ℝℤΩℨK-ℹℼ-ℿⅅ-ⅉⅎⅠ-ↈⰀ-ⳤⳫ-ⳮⳲⳳⴀ-ⴥⴧⴭⴰ-ⵧⵯⶀ-ⶖⶠ-ⶦⶨ-ⶮⶰ-ⶶⶸ-ⶾⷀ-ⷆⷈ-ⷎⷐ-ⷖⷘ-ⷞ々-〇〡-〩〱-〵〸-〼ぁ-ゖ゛-ゟァ-ヺー-ヿㄅ-ㄯㄱ-ㆎㆠ-ㆿㇰ-ㇿ㐀-䶿一-ꒌꓐ-ꓽꔀ-ꘌꘐ-ꘟꘪꘫꙀ-ꙮꙿ-ꚝꚠ-ꛯꜗ-ꜟꜢ-ꞈꞋ-ꟍꟐꟑꟓꟕ-Ƛꟲ-ꠁꠃ-ꠅꠇ-ꠊꠌ-ꠢꡀ-ꡳꢂ-ꢳꣲ-ꣷꣻꣽꣾꤊ-ꤥꤰ-ꥆꥠ-ꥼꦄ-ꦲꧏꧠ-ꧤꧦ-ꧯꧺ-ꧾꨀ-ꨨꩀ-ꩂꩄ-ꩋꩠ-ꩶꩺꩾ-ꪯꪱꪵꪶꪹ-ꪽꫀꫂꫛ-ꫝꫠ-ꫪꫲ-ꫴꬁ-ꬆꬉ-ꬎꬑ-ꬖꬠ-ꬦꬨ-ꬮꬰ-ꭚꭜ-ꭩꭰ-ꯢ가-힣ힰ-ퟆퟋ-ퟻ豈-舘並-龎ﬀ-ﬆﬓ-ﬗיִײַ-ﬨשׁ-זּטּ-לּמּנּסּףּפּצּ-ﮱﯓ-ﴽﵐ-ﶏﶒ-ﷇﷰ-ﷻﹰ-ﹴﹶ-ﻼＡ-Ｚａ-ｚｦ-ﾾￂ-ￇￊ-ￏￒ-ￗￚ-ￜ",
      ht = {
        3: "abstract boolean byte char class double enum export extends final float goto implements import int interface long native package private protected public short static super synchronized throws transient volatile",
        5: "class enum extends super const export import",
        6: "enum",
        strict:
          "implements interface let package private protected public static yield",
        strictBind: "eval arguments",
      },
      ft =
        "break case catch continue debugger default do else finally for function if return switch throw try var while with null true false instanceof typeof void delete new in this",
      Ar = {
        5: ft,
        "5module": ft + " export import",
        6: ft + " const class extends export import super",
      },
      Pr = /^in(stanceof)?$/,
      Lr = new RegExp("[" + Wt + "]"),
      Vr = new RegExp("[" + Wt + Ir + "]");
    function pt(e, t) {
      for (var r = 65536, i = 0; i < t.length; i += 2) {
        if (((r += t[i]), r > e)) return !1;
        if (((r += t[i + 1]), r >= e)) return !0;
      }
      return !1;
    }
    function ee(e, t) {
      return e < 65
        ? e === 36
        : e < 91
        ? !0
        : e < 97
        ? e === 95
        : e < 123
        ? !0
        : e <= 65535
        ? e >= 170 && Lr.test(String.fromCharCode(e))
        : t === !1
        ? !1
        : pt(e, qt);
    }
    function Se(e, t) {
      return e < 48
        ? e === 36
        : e < 58
        ? !0
        : e < 65
        ? !1
        : e < 91
        ? !0
        : e < 97
        ? e === 95
        : e < 123
        ? !0
        : e <= 65535
        ? e >= 170 && Vr.test(String.fromCharCode(e))
        : t === !1
        ? !1
        : pt(e, qt) || pt(e, _r);
    }
    var k = function k(t, r) {
      r === void 0 && (r = {}),
        (this.label = t),
        (this.keyword = r.keyword),
        (this.beforeExpr = !!r.beforeExpr),
        (this.startsExpr = !!r.startsExpr),
        (this.isLoop = !!r.isLoop),
        (this.isAssign = !!r.isAssign),
        (this.prefix = !!r.prefix),
        (this.postfix = !!r.postfix),
        (this.binop = r.binop || null),
        (this.updateContext = null);
    };
    function $(e, t) {
      return new k(e, { beforeExpr: !0, binop: t });
    }
    var q = { beforeExpr: !0 },
      D = { startsExpr: !0 },
      dt = {};
    function v(e, t) {
      return t === void 0 && (t = {}), (t.keyword = e), (dt[e] = new k(e, t));
    }
    var o = {
        num: new k("num", D),
        regexp: new k("regexp", D),
        string: new k("string", D),
        name: new k("name", D),
        privateId: new k("privateId", D),
        eof: new k("eof"),
        bracketL: new k("[", { beforeExpr: !0, startsExpr: !0 }),
        bracketR: new k("]"),
        braceL: new k("{", { beforeExpr: !0, startsExpr: !0 }),
        braceR: new k("}"),
        parenL: new k("(", { beforeExpr: !0, startsExpr: !0 }),
        parenR: new k(")"),
        comma: new k(",", q),
        semi: new k(";", q),
        colon: new k(":", q),
        dot: new k("."),
        question: new k("?", q),
        questionDot: new k("?."),
        arrow: new k("=>", q),
        template: new k("template"),
        invalidTemplate: new k("invalidTemplate"),
        ellipsis: new k("...", q),
        backQuote: new k("`", D),
        dollarBraceL: new k("${", { beforeExpr: !0, startsExpr: !0 }),
        eq: new k("=", { beforeExpr: !0, isAssign: !0 }),
        assign: new k("_=", { beforeExpr: !0, isAssign: !0 }),
        incDec: new k("++/--", { prefix: !0, postfix: !0, startsExpr: !0 }),
        prefix: new k("!/~", { beforeExpr: !0, prefix: !0, startsExpr: !0 }),
        logicalOR: $("||", 1),
        logicalAND: $("&&", 2),
        bitwiseOR: $("|", 3),
        bitwiseXOR: $("^", 4),
        bitwiseAND: $("&", 5),
        equality: $("==/!=/===/!==", 6),
        relational: $("</>/<=/>=", 7),
        bitShift: $("<</>>/>>>", 8),
        plusMin: new k("+/-", {
          beforeExpr: !0,
          binop: 9,
          prefix: !0,
          startsExpr: !0,
        }),
        modulo: $("%", 10),
        star: $("*", 10),
        slash: $("/", 10),
        starstar: new k("**", { beforeExpr: !0 }),
        coalesce: $("??", 1),
        _break: v("break"),
        _case: v("case", q),
        _catch: v("catch"),
        _continue: v("continue"),
        _debugger: v("debugger"),
        _default: v("default", q),
        _do: v("do", { isLoop: !0, beforeExpr: !0 }),
        _else: v("else", q),
        _finally: v("finally"),
        _for: v("for", { isLoop: !0 }),
        _function: v("function", D),
        _if: v("if"),
        _return: v("return", q),
        _switch: v("switch"),
        _throw: v("throw", q),
        _try: v("try"),
        _var: v("var"),
        _const: v("const"),
        _while: v("while", { isLoop: !0 }),
        _with: v("with"),
        _new: v("new", { beforeExpr: !0, startsExpr: !0 }),
        _this: v("this", D),
        _super: v("super", D),
        _class: v("class", D),
        _extends: v("extends", q),
        _export: v("export"),
        _import: v("import", D),
        _null: v("null", D),
        _true: v("true", D),
        _false: v("false", D),
        _in: v("in", { beforeExpr: !0, binop: 7 }),
        _instanceof: v("instanceof", { beforeExpr: !0, binop: 7 }),
        _typeof: v("typeof", { beforeExpr: !0, prefix: !0, startsExpr: !0 }),
        _void: v("void", { beforeExpr: !0, prefix: !0, startsExpr: !0 }),
        _delete: v("delete", { beforeExpr: !0, prefix: !0, startsExpr: !0 }),
      },
      W = /\r\n?|\n|\u2028|\u2029/,
      Tr = new RegExp(W.source, "g");
    function we(e) {
      return e === 10 || e === 13 || e === 8232 || e === 8233;
    }
    function zt(e, t, r) {
      r === void 0 && (r = e.length);
      for (var i = t; i < r; i++) {
        var a = e.charCodeAt(i);
        if (we(a))
          return i < r - 1 && a === 13 && e.charCodeAt(i + 1) === 10
            ? i + 2
            : i + 1;
      }
      return -1;
    }
    var Gt = /[\u1680\u2000-\u200a\u202f\u205f\u3000\ufeff]/,
      z = /(?:\s|\/\/.*|\/\*[^]*?\*\/)*/g,
      Ht = Object.prototype,
      Nr = Ht.hasOwnProperty,
      Rr = Ht.toString,
      ke =
        Object.hasOwn ||
        function (e, t) {
          return Nr.call(e, t);
        },
      Kt =
        Array.isArray ||
        function (e) {
          return Rr.call(e) === "[object Array]";
        },
      Qt = Object.create(null);
    function le(e) {
      return (
        Qt[e] || (Qt[e] = new RegExp("^(?:" + e.replace(/ /g, "|") + ")$"))
      );
    }
    function te(e) {
      return e <= 65535
        ? String.fromCharCode(e)
        : ((e -= 65536),
          String.fromCharCode((e >> 10) + 55296, (e & 1023) + 56320));
    }
    var Br =
        /(?:[\uD800-\uDBFF](?![\uDC00-\uDFFF])|(?:[^\uD800-\uDBFF]|^)[\uDC00-\uDFFF])/,
      Re = function Re(t, r) {
        (this.line = t), (this.column = r);
      };
    Re.prototype.offset = function (t) {
      return new Re(this.line, this.column + t);
    };
    var Qe = function Qe(t, r, i) {
      (this.start = r),
        (this.end = i),
        t.sourceFile !== null && (this.source = t.sourceFile);
    };
    function Xt(e, t) {
      for (var r = 1, i = 0; ; ) {
        var a = zt(e, i, t);
        if (a < 0) return new Re(r, t - i);
        ++r, (i = a);
      }
    }
    var yt = {
        ecmaVersion: null,
        sourceType: "script",
        onInsertedSemicolon: null,
        onTrailingComma: null,
        allowReserved: null,
        allowReturnOutsideFunction: !1,
        allowImportExportEverywhere: !1,
        allowAwaitOutsideFunction: null,
        allowSuperOutsideMethod: null,
        allowHashBang: !1,
        checkPrivateFields: !0,
        locations: !1,
        onToken: null,
        onComment: null,
        ranges: !1,
        program: null,
        sourceFile: null,
        directSourceFile: null,
        preserveParens: !1,
      },
      Yt = !1;
    function Or(e) {
      var t = {};
      for (var r in yt) t[r] = e && ke(e, r) ? e[r] : yt[r];
      if (
        (t.ecmaVersion === "latest"
          ? (t.ecmaVersion = 1e8)
          : t.ecmaVersion == null
          ? (!Yt &&
              (typeof console === "undefined"
                ? "undefined"
                : _type_of(console)) == "object" &&
              console.warn &&
              ((Yt = !0),
              console.warn(
                "Since Acorn 8.0.0, options.ecmaVersion is required.\nDefaulting to 2020, but this will stop working in the future."
              )),
            (t.ecmaVersion = 11))
          : t.ecmaVersion >= 2015 && (t.ecmaVersion -= 2009),
        t.allowReserved == null && (t.allowReserved = t.ecmaVersion < 5),
        (!e || e.allowHashBang == null) &&
          (t.allowHashBang = t.ecmaVersion >= 14),
        Kt(t.onToken))
      ) {
        var i = t.onToken;
        t.onToken = function (a) {
          return i.push(a);
        };
      }
      return Kt(t.onComment) && (t.onComment = Dr(t, t.onComment)), t;
    }
    function Dr(e, t) {
      return function (r, i, a, s, n, u) {
        var l = { type: r ? "Block" : "Line", value: i, start: a, end: s };
        e.locations && (l.loc = new Qe(this, n, u)),
          e.ranges && (l.range = [a, s]),
          t.push(l);
      };
    }
    var Be = 1,
      Ee = 2,
      mt = 4,
      Zt = 8,
      gt = 16,
      Jt = 32,
      Xe = 64,
      ei = 128,
      ye = 256,
      Oe = 512,
      Ye = Be | Ee | ye;
    function xt(e, t) {
      return Ee | (e ? mt : 0) | (t ? Zt : 0);
    }
    var Ze = 0,
      bt = 1,
      ie = 2,
      ti = 3,
      ii = 4,
      ri = 5,
      V = function V(t, r, i) {
        (this.options = t = Or(t)),
          (this.sourceFile = t.sourceFile),
          (this.keywords = le(
            Ar[
              t.ecmaVersion >= 6 ? 6 : t.sourceType === "module" ? "5module" : 5
            ]
          ));
        var a = "";
        t.allowReserved !== !0 &&
          ((a = ht[t.ecmaVersion >= 6 ? 6 : t.ecmaVersion === 5 ? 5 : 3]),
          t.sourceType === "module" && (a += " await")),
          (this.reservedWords = le(a));
        var s = (a ? a + " " : "") + ht.strict;
        (this.reservedWordsStrict = le(s)),
          (this.reservedWordsStrictBind = le(s + " " + ht.strictBind)),
          (this.input = String(r)),
          (this.containsEsc = !1),
          i
            ? ((this.pos = i),
              (this.lineStart = this.input.lastIndexOf("\n", i - 1) + 1),
              (this.curLine = this.input
                .slice(0, this.lineStart)
                .split(W).length))
            : ((this.pos = this.lineStart = 0), (this.curLine = 1)),
          (this.type = o.eof),
          (this.value = null),
          (this.start = this.end = this.pos),
          (this.startLoc = this.endLoc = this.curPosition()),
          (this.lastTokEndLoc = this.lastTokStartLoc = null),
          (this.lastTokStart = this.lastTokEnd = this.pos),
          (this.context = this.initialContext()),
          (this.exprAllowed = !0),
          (this.inModule = t.sourceType === "module"),
          (this.strict = this.inModule || this.strictDirective(this.pos)),
          (this.potentialArrowAt = -1),
          (this.potentialArrowInForAwait = !1),
          (this.yieldPos = this.awaitPos = this.awaitIdentPos = 0),
          (this.labels = []),
          (this.undefinedExports = Object.create(null)),
          this.pos === 0 &&
            t.allowHashBang &&
            this.input.slice(0, 2) === "#!" &&
            this.skipLineComment(2),
          (this.scopeStack = []),
          this.enterScope(Be),
          (this.regexpState = null),
          (this.privateNameStack = []);
      },
      X = {
        inFunction: { configurable: !0 },
        inGenerator: { configurable: !0 },
        inAsync: { configurable: !0 },
        canAwait: { configurable: !0 },
        allowSuper: { configurable: !0 },
        allowDirectSuper: { configurable: !0 },
        treatFunctionsAsVar: { configurable: !0 },
        allowNewDotTarget: { configurable: !0 },
        inClassStaticBlock: { configurable: !0 },
      };
    (V.prototype.parse = function () {
      var t = this.options.program || this.startNode();
      return this.nextToken(), this.parseTopLevel(t);
    }),
      (X.inFunction.get = function () {
        return (this.currentVarScope().flags & Ee) > 0;
      }),
      (X.inGenerator.get = function () {
        return (this.currentVarScope().flags & Zt) > 0;
      }),
      (X.inAsync.get = function () {
        return (this.currentVarScope().flags & mt) > 0;
      }),
      (X.canAwait.get = function () {
        for (var e = this.scopeStack.length - 1; e >= 0; e--) {
          var t = this.scopeStack[e],
            r = t.flags;
          if (r & (ye | Oe)) return !1;
          if (r & Ee) return (r & mt) > 0;
        }
        return (
          (this.inModule && this.options.ecmaVersion >= 13) ||
          this.options.allowAwaitOutsideFunction
        );
      }),
      (X.allowSuper.get = function () {
        var e = this.currentThisScope(),
          t = e.flags;
        return (t & Xe) > 0 || this.options.allowSuperOutsideMethod;
      }),
      (X.allowDirectSuper.get = function () {
        return (this.currentThisScope().flags & ei) > 0;
      }),
      (X.treatFunctionsAsVar.get = function () {
        return this.treatFunctionsAsVarInScope(this.currentScope());
      }),
      (X.allowNewDotTarget.get = function () {
        for (var e = this.scopeStack.length - 1; e >= 0; e--) {
          var t = this.scopeStack[e],
            r = t.flags;
          if (r & (ye | Oe) || (r & Ee && !(r & gt))) return !0;
        }
        return !1;
      }),
      (X.inClassStaticBlock.get = function () {
        return (this.currentVarScope().flags & ye) > 0;
      }),
      (V.extend = function () {
        for (var t = [], r = arguments.length; r--; ) t[r] = arguments[r];
        for (var i = this, a = 0; a < t.length; a++) i = t[a](i);
        return i;
      }),
      (V.parse = function (t, r) {
        return new this(r, t).parse();
      }),
      (V.parseExpressionAt = function (t, r, i) {
        var a = new this(i, t, r);
        return a.nextToken(), a.parseExpression();
      }),
      (V.tokenizer = function (t, r) {
        return new this(r, t);
      }),
      Object.defineProperties(V.prototype, X);
    var B = V.prototype,
      Fr = /^(?:'((?:\\[^]|[^'\\])*?)'|"((?:\\[^]|[^"\\])*?)")/;
    (B.strictDirective = function (e) {
      if (this.options.ecmaVersion < 5) return !1;
      for (;;) {
        (z.lastIndex = e), (e += z.exec(this.input)[0].length);
        var t = Fr.exec(this.input.slice(e));
        if (!t) return !1;
        if ((t[1] || t[2]) === "use strict") {
          z.lastIndex = e + t[0].length;
          var r = z.exec(this.input),
            i = r.index + r[0].length,
            a = this.input.charAt(i);
          return (
            a === ";" ||
            a === "}" ||
            (W.test(r[0]) &&
              !(
                /[(`.[+\-/*%<>=,?^&]/.test(a) ||
                (a === "!" && this.input.charAt(i + 1) === "=")
              ))
          );
        }
        (e += t[0].length),
          (z.lastIndex = e),
          (e += z.exec(this.input)[0].length),
          this.input[e] === ";" && e++;
      }
    }),
      (B.eat = function (e) {
        return this.type === e ? (this.next(), !0) : !1;
      }),
      (B.isContextual = function (e) {
        return this.type === o.name && this.value === e && !this.containsEsc;
      }),
      (B.eatContextual = function (e) {
        return this.isContextual(e) ? (this.next(), !0) : !1;
      }),
      (B.expectContextual = function (e) {
        this.eatContextual(e) || this.unexpected();
      }),
      (B.canInsertSemicolon = function () {
        return (
          this.type === o.eof ||
          this.type === o.braceR ||
          W.test(this.input.slice(this.lastTokEnd, this.start))
        );
      }),
      (B.insertSemicolon = function () {
        if (this.canInsertSemicolon())
          return (
            this.options.onInsertedSemicolon &&
              this.options.onInsertedSemicolon(
                this.lastTokEnd,
                this.lastTokEndLoc
              ),
            !0
          );
      }),
      (B.semicolon = function () {
        !this.eat(o.semi) && !this.insertSemicolon() && this.unexpected();
      }),
      (B.afterTrailingComma = function (e, t) {
        if (this.type === e)
          return (
            this.options.onTrailingComma &&
              this.options.onTrailingComma(
                this.lastTokStart,
                this.lastTokStartLoc
              ),
            t || this.next(),
            !0
          );
      }),
      (B.expect = function (e) {
        this.eat(e) || this.unexpected();
      }),
      (B.unexpected = function (e) {
        this.raise(
          e !== null && e !== void 0 ? e : this.start,
          "Unexpected token"
        );
      });
    var Je = function Je() {
      this.shorthandAssign =
        this.trailingComma =
        this.parenthesizedAssign =
        this.parenthesizedBind =
        this.doubleProto =
          -1;
    };
    (B.checkPatternErrors = function (e, t) {
      if (e) {
        e.trailingComma > -1 &&
          this.raiseRecoverable(
            e.trailingComma,
            "Comma is not permitted after the rest element"
          );
        var r = t ? e.parenthesizedAssign : e.parenthesizedBind;
        r > -1 &&
          this.raiseRecoverable(
            r,
            t ? "Assigning to rvalue" : "Parenthesized pattern"
          );
      }
    }),
      (B.checkExpressionErrors = function (e, t) {
        if (!e) return !1;
        var r = e.shorthandAssign,
          i = e.doubleProto;
        if (!t) return r >= 0 || i >= 0;
        r >= 0 &&
          this.raise(
            r,
            "Shorthand property assignments are valid only in destructuring patterns"
          ),
          i >= 0 &&
            this.raiseRecoverable(i, "Redefinition of __proto__ property");
      }),
      (B.checkYieldAwaitInDefaultParams = function () {
        this.yieldPos &&
          (!this.awaitPos || this.yieldPos < this.awaitPos) &&
          this.raise(
            this.yieldPos,
            "Yield expression cannot be a default value"
          ),
          this.awaitPos &&
            this.raise(
              this.awaitPos,
              "Await expression cannot be a default value"
            );
      }),
      (B.isSimpleAssignTarget = function (e) {
        return e.type === "ParenthesizedExpression"
          ? this.isSimpleAssignTarget(e.expression)
          : e.type === "Identifier" || e.type === "MemberExpression";
      });
    var g = V.prototype;
    g.parseTopLevel = function (e) {
      var t = Object.create(null);
      for (e.body || (e.body = []); this.type !== o.eof; ) {
        var r = this.parseStatement(null, !0, t);
        e.body.push(r);
      }
      if (this.inModule)
        for (
          var i = 0, a = Object.keys(this.undefinedExports);
          i < a.length;
          i += 1
        ) {
          var s = a[i];
          this.raiseRecoverable(
            this.undefinedExports[s].start,
            "Export '" + s + "' is not defined"
          );
        }
      return (
        this.adaptDirectivePrologue(e.body),
        this.next(),
        (e.sourceType = this.options.sourceType),
        this.finishNode(e, "Program")
      );
    };
    var vt = { kind: "loop" },
      Mr = { kind: "switch" };
    (g.isLet = function (e) {
      if (this.options.ecmaVersion < 6 || !this.isContextual("let")) return !1;
      z.lastIndex = this.pos;
      var t = z.exec(this.input),
        r = this.pos + t[0].length,
        i = this.input.charCodeAt(r);
      if (i === 91 || i === 92) return !0;
      if (e) return !1;
      if (i === 123 || (i > 55295 && i < 56320)) return !0;
      if (ee(i, !0)) {
        for (var a = r + 1; Se((i = this.input.charCodeAt(a)), !0); ) ++a;
        if (i === 92 || (i > 55295 && i < 56320)) return !0;
        var s = this.input.slice(r, a);
        if (!Pr.test(s)) return !0;
      }
      return !1;
    }),
      (g.isAsyncFunction = function () {
        if (this.options.ecmaVersion < 8 || !this.isContextual("async"))
          return !1;
        z.lastIndex = this.pos;
        var e = z.exec(this.input),
          t = this.pos + e[0].length,
          r;
        return (
          !W.test(this.input.slice(this.pos, t)) &&
          this.input.slice(t, t + 8) === "function" &&
          (t + 8 === this.input.length ||
            !(
              Se((r = this.input.charCodeAt(t + 8))) ||
              (r > 55295 && r < 56320)
            ))
        );
      }),
      (g.parseStatement = function (e, t, r) {
        var i = this.type,
          a = this.startNode(),
          s;
        switch ((this.isLet(e) && ((i = o._var), (s = "let")), i)) {
          case o._break:
          case o._continue:
            return this.parseBreakContinueStatement(a, i.keyword);
          case o._debugger:
            return this.parseDebuggerStatement(a);
          case o._do:
            return this.parseDoStatement(a);
          case o._for:
            return this.parseForStatement(a);
          case o._function:
            return (
              e &&
                (this.strict || (e !== "if" && e !== "label")) &&
                this.options.ecmaVersion >= 6 &&
                this.unexpected(),
              this.parseFunctionStatement(a, !1, !e)
            );
          case o._class:
            return e && this.unexpected(), this.parseClass(a, !0);
          case o._if:
            return this.parseIfStatement(a);
          case o._return:
            return this.parseReturnStatement(a);
          case o._switch:
            return this.parseSwitchStatement(a);
          case o._throw:
            return this.parseThrowStatement(a);
          case o._try:
            return this.parseTryStatement(a);
          case o._const:
          case o._var:
            return (
              (s = s || this.value),
              e && s !== "var" && this.unexpected(),
              this.parseVarStatement(a, s)
            );
          case o._while:
            return this.parseWhileStatement(a);
          case o._with:
            return this.parseWithStatement(a);
          case o.braceL:
            return this.parseBlock(!0, a);
          case o.semi:
            return this.parseEmptyStatement(a);
          case o._export:
          case o._import:
            if (this.options.ecmaVersion > 10 && i === o._import) {
              z.lastIndex = this.pos;
              var n = z.exec(this.input),
                u = this.pos + n[0].length,
                l = this.input.charCodeAt(u);
              if (l === 40 || l === 46)
                return this.parseExpressionStatement(a, this.parseExpression());
            }
            return (
              this.options.allowImportExportEverywhere ||
                (t ||
                  this.raise(
                    this.start,
                    "'import' and 'export' may only appear at the top level"
                  ),
                this.inModule ||
                  this.raise(
                    this.start,
                    "'import' and 'export' may appear only with 'sourceType: module'"
                  )),
              i === o._import ? this.parseImport(a) : this.parseExport(a, r)
            );
          default:
            if (this.isAsyncFunction())
              return (
                e && this.unexpected(),
                this.next(),
                this.parseFunctionStatement(a, !0, !e)
              );
            var c = this.value,
              h = this.parseExpression();
            return i === o.name && h.type === "Identifier" && this.eat(o.colon)
              ? this.parseLabeledStatement(a, c, h, e)
              : this.parseExpressionStatement(a, h);
        }
      }),
      (g.parseBreakContinueStatement = function (e, t) {
        var r = t === "break";
        this.next(),
          this.eat(o.semi) || this.insertSemicolon()
            ? (e.label = null)
            : this.type !== o.name
            ? this.unexpected()
            : ((e.label = this.parseIdent()), this.semicolon());
        for (var i = 0; i < this.labels.length; ++i) {
          var a = this.labels[i];
          if (
            (e.label == null || a.name === e.label.name) &&
            ((a.kind != null && (r || a.kind === "loop")) || (e.label && r))
          )
            break;
        }
        return (
          i === this.labels.length && this.raise(e.start, "Unsyntactic " + t),
          this.finishNode(e, r ? "BreakStatement" : "ContinueStatement")
        );
      }),
      (g.parseDebuggerStatement = function (e) {
        return (
          this.next(), this.semicolon(), this.finishNode(e, "DebuggerStatement")
        );
      }),
      (g.parseDoStatement = function (e) {
        return (
          this.next(),
          this.labels.push(vt),
          (e.body = this.parseStatement("do")),
          this.labels.pop(),
          this.expect(o._while),
          (e.test = this.parseParenExpression()),
          this.options.ecmaVersion >= 6 ? this.eat(o.semi) : this.semicolon(),
          this.finishNode(e, "DoWhileStatement")
        );
      }),
      (g.parseForStatement = function (e) {
        this.next();
        var t =
          this.options.ecmaVersion >= 9 &&
          this.canAwait &&
          this.eatContextual("await")
            ? this.lastTokStart
            : -1;
        if (
          (this.labels.push(vt),
          this.enterScope(0),
          this.expect(o.parenL),
          this.type === o.semi)
        )
          return t > -1 && this.unexpected(t), this.parseFor(e, null);
        var r = this.isLet();
        if (this.type === o._var || this.type === o._const || r) {
          var i = this.startNode(),
            a = r ? "let" : this.value;
          return (
            this.next(),
            this.parseVar(i, !0, a),
            this.finishNode(i, "VariableDeclaration"),
            (this.type === o._in ||
              (this.options.ecmaVersion >= 6 && this.isContextual("of"))) &&
            i.declarations.length === 1
              ? (this.options.ecmaVersion >= 9 &&
                  (this.type === o._in
                    ? t > -1 && this.unexpected(t)
                    : (e.await = t > -1)),
                this.parseForIn(e, i))
              : (t > -1 && this.unexpected(t), this.parseFor(e, i))
          );
        }
        var s = this.isContextual("let"),
          n = !1,
          u = this.containsEsc,
          l = new Je(),
          c = this.start,
          h =
            t > -1
              ? this.parseExprSubscripts(l, "await")
              : this.parseExpression(!0, l);
        return this.type === o._in ||
          (n = this.options.ecmaVersion >= 6 && this.isContextual("of"))
          ? (t > -1
              ? (this.type === o._in && this.unexpected(t), (e.await = !0))
              : n &&
                this.options.ecmaVersion >= 8 &&
                (h.start === c &&
                !u &&
                h.type === "Identifier" &&
                h.name === "async"
                  ? this.unexpected()
                  : this.options.ecmaVersion >= 9 && (e.await = !1)),
            s &&
              n &&
              this.raise(
                h.start,
                "The left-hand side of a for-of loop may not start with 'let'."
              ),
            this.toAssignable(h, !1, l),
            this.checkLValPattern(h),
            this.parseForIn(e, h))
          : (this.checkExpressionErrors(l, !0),
            t > -1 && this.unexpected(t),
            this.parseFor(e, h));
      }),
      (g.parseFunctionStatement = function (e, t, r) {
        return this.next(), this.parseFunction(e, De | (r ? 0 : St), !1, t);
      }),
      (g.parseIfStatement = function (e) {
        return (
          this.next(),
          (e.test = this.parseParenExpression()),
          (e.consequent = this.parseStatement("if")),
          (e.alternate = this.eat(o._else) ? this.parseStatement("if") : null),
          this.finishNode(e, "IfStatement")
        );
      }),
      (g.parseReturnStatement = function (e) {
        return (
          !this.inFunction &&
            !this.options.allowReturnOutsideFunction &&
            this.raise(this.start, "'return' outside of function"),
          this.next(),
          this.eat(o.semi) || this.insertSemicolon()
            ? (e.argument = null)
            : ((e.argument = this.parseExpression()), this.semicolon()),
          this.finishNode(e, "ReturnStatement")
        );
      }),
      (g.parseSwitchStatement = function (e) {
        this.next(),
          (e.discriminant = this.parseParenExpression()),
          (e.cases = []),
          this.expect(o.braceL),
          this.labels.push(Mr),
          this.enterScope(0);
        for (var t, r = !1; this.type !== o.braceR; )
          if (this.type === o._case || this.type === o._default) {
            var i = this.type === o._case;
            t && this.finishNode(t, "SwitchCase"),
              e.cases.push((t = this.startNode())),
              (t.consequent = []),
              this.next(),
              i
                ? (t.test = this.parseExpression())
                : (r &&
                    this.raiseRecoverable(
                      this.lastTokStart,
                      "Multiple default clauses"
                    ),
                  (r = !0),
                  (t.test = null)),
              this.expect(o.colon);
          } else
            t || this.unexpected(),
              t.consequent.push(this.parseStatement(null));
        return (
          this.exitScope(),
          t && this.finishNode(t, "SwitchCase"),
          this.next(),
          this.labels.pop(),
          this.finishNode(e, "SwitchStatement")
        );
      }),
      (g.parseThrowStatement = function (e) {
        return (
          this.next(),
          W.test(this.input.slice(this.lastTokEnd, this.start)) &&
            this.raise(this.lastTokEnd, "Illegal newline after throw"),
          (e.argument = this.parseExpression()),
          this.semicolon(),
          this.finishNode(e, "ThrowStatement")
        );
      });
    var jr = [];
    (g.parseCatchClauseParam = function () {
      var e = this.parseBindingAtom(),
        t = e.type === "Identifier";
      return (
        this.enterScope(t ? Jt : 0),
        this.checkLValPattern(e, t ? ii : ie),
        this.expect(o.parenR),
        e
      );
    }),
      (g.parseTryStatement = function (e) {
        if (
          (this.next(),
          (e.block = this.parseBlock()),
          (e.handler = null),
          this.type === o._catch)
        ) {
          var t = this.startNode();
          this.next(),
            this.eat(o.parenL)
              ? (t.param = this.parseCatchClauseParam())
              : (this.options.ecmaVersion < 10 && this.unexpected(),
                (t.param = null),
                this.enterScope(0)),
            (t.body = this.parseBlock(!1)),
            this.exitScope(),
            (e.handler = this.finishNode(t, "CatchClause"));
        }
        return (
          (e.finalizer = this.eat(o._finally) ? this.parseBlock() : null),
          !e.handler &&
            !e.finalizer &&
            this.raise(e.start, "Missing catch or finally clause"),
          this.finishNode(e, "TryStatement")
        );
      }),
      (g.parseVarStatement = function (e, t, r) {
        return (
          this.next(),
          this.parseVar(e, !1, t, r),
          this.semicolon(),
          this.finishNode(e, "VariableDeclaration")
        );
      }),
      (g.parseWhileStatement = function (e) {
        return (
          this.next(),
          (e.test = this.parseParenExpression()),
          this.labels.push(vt),
          (e.body = this.parseStatement("while")),
          this.labels.pop(),
          this.finishNode(e, "WhileStatement")
        );
      }),
      (g.parseWithStatement = function (e) {
        return (
          this.strict && this.raise(this.start, "'with' in strict mode"),
          this.next(),
          (e.object = this.parseParenExpression()),
          (e.body = this.parseStatement("with")),
          this.finishNode(e, "WithStatement")
        );
      }),
      (g.parseEmptyStatement = function (e) {
        return this.next(), this.finishNode(e, "EmptyStatement");
      }),
      (g.parseLabeledStatement = function (e, t, r, i) {
        for (var a = 0, s = this.labels; a < s.length; a += 1) {
          var n = s[a];
          n.name === t &&
            this.raise(r.start, "Label '" + t + "' is already declared");
        }
        for (
          var u = this.type.isLoop
              ? "loop"
              : this.type === o._switch
              ? "switch"
              : null,
            l = this.labels.length - 1;
          l >= 0;
          l--
        ) {
          var c = this.labels[l];
          if (c.statementStart === e.start)
            (c.statementStart = this.start), (c.kind = u);
          else break;
        }
        return (
          this.labels.push({ name: t, kind: u, statementStart: this.start }),
          (e.body = this.parseStatement(
            i ? (i.indexOf("label") === -1 ? i + "label" : i) : "label"
          )),
          this.labels.pop(),
          (e.label = r),
          this.finishNode(e, "LabeledStatement")
        );
      }),
      (g.parseExpressionStatement = function (e, t) {
        return (
          (e.expression = t),
          this.semicolon(),
          this.finishNode(e, "ExpressionStatement")
        );
      }),
      (g.parseBlock = function (e, t, r) {
        for (
          e === void 0 && (e = !0),
            t === void 0 && (t = this.startNode()),
            t.body = [],
            this.expect(o.braceL),
            e && this.enterScope(0);
          this.type !== o.braceR;

        ) {
          var i = this.parseStatement(null);
          t.body.push(i);
        }
        return (
          r && (this.strict = !1),
          this.next(),
          e && this.exitScope(),
          this.finishNode(t, "BlockStatement")
        );
      }),
      (g.parseFor = function (e, t) {
        return (
          (e.init = t),
          this.expect(o.semi),
          (e.test = this.type === o.semi ? null : this.parseExpression()),
          this.expect(o.semi),
          (e.update = this.type === o.parenR ? null : this.parseExpression()),
          this.expect(o.parenR),
          (e.body = this.parseStatement("for")),
          this.exitScope(),
          this.labels.pop(),
          this.finishNode(e, "ForStatement")
        );
      }),
      (g.parseForIn = function (e, t) {
        var r = this.type === o._in;
        return (
          this.next(),
          t.type === "VariableDeclaration" &&
            t.declarations[0].init != null &&
            (!r ||
              this.options.ecmaVersion < 8 ||
              this.strict ||
              t.kind !== "var" ||
              t.declarations[0].id.type !== "Identifier") &&
            this.raise(
              t.start,
              (r ? "for-in" : "for-of") +
                " loop variable declaration may not have an initializer"
            ),
          (e.left = t),
          (e.right = r ? this.parseExpression() : this.parseMaybeAssign()),
          this.expect(o.parenR),
          (e.body = this.parseStatement("for")),
          this.exitScope(),
          this.labels.pop(),
          this.finishNode(e, r ? "ForInStatement" : "ForOfStatement")
        );
      }),
      (g.parseVar = function (e, t, r, i) {
        for (e.declarations = [], e.kind = r; ; ) {
          var a = this.startNode();
          if (
            (this.parseVarId(a, r),
            this.eat(o.eq)
              ? (a.init = this.parseMaybeAssign(t))
              : !i &&
                r === "const" &&
                !(
                  this.type === o._in ||
                  (this.options.ecmaVersion >= 6 && this.isContextual("of"))
                )
              ? this.unexpected()
              : !i &&
                a.id.type !== "Identifier" &&
                !(t && (this.type === o._in || this.isContextual("of")))
              ? this.raise(
                  this.lastTokEnd,
                  "Complex binding patterns require an initialization value"
                )
              : (a.init = null),
            e.declarations.push(this.finishNode(a, "VariableDeclarator")),
            !this.eat(o.comma))
          )
            break;
        }
        return e;
      }),
      (g.parseVarId = function (e, t) {
        (e.id = this.parseBindingAtom()),
          this.checkLValPattern(e.id, t === "var" ? bt : ie, !1);
      });
    var De = 1,
      St = 2,
      ai = 4;
    (g.parseFunction = function (e, t, r, i, a) {
      this.initFunction(e),
        (this.options.ecmaVersion >= 9 ||
          (this.options.ecmaVersion >= 6 && !i)) &&
          (this.type === o.star && t & St && this.unexpected(),
          (e.generator = this.eat(o.star))),
        this.options.ecmaVersion >= 8 && (e.async = !!i),
        t & De &&
          ((e.id = t & ai && this.type !== o.name ? null : this.parseIdent()),
          e.id &&
            !(t & St) &&
            this.checkLValSimple(
              e.id,
              this.strict || e.generator || e.async
                ? this.treatFunctionsAsVar
                  ? bt
                  : ie
                : ti
            ));
      var s = this.yieldPos,
        n = this.awaitPos,
        u = this.awaitIdentPos;
      return (
        (this.yieldPos = 0),
        (this.awaitPos = 0),
        (this.awaitIdentPos = 0),
        this.enterScope(xt(e.async, e.generator)),
        t & De || (e.id = this.type === o.name ? this.parseIdent() : null),
        this.parseFunctionParams(e),
        this.parseFunctionBody(e, r, !1, a),
        (this.yieldPos = s),
        (this.awaitPos = n),
        (this.awaitIdentPos = u),
        this.finishNode(
          e,
          t & De ? "FunctionDeclaration" : "FunctionExpression"
        )
      );
    }),
      (g.parseFunctionParams = function (e) {
        this.expect(o.parenL),
          (e.params = this.parseBindingList(
            o.parenR,
            !1,
            this.options.ecmaVersion >= 8
          )),
          this.checkYieldAwaitInDefaultParams();
      }),
      (g.parseClass = function (e, t) {
        this.next();
        var r = this.strict;
        (this.strict = !0), this.parseClassId(e, t), this.parseClassSuper(e);
        var i = this.enterClassBody(),
          a = this.startNode(),
          s = !1;
        for (a.body = [], this.expect(o.braceL); this.type !== o.braceR; ) {
          var n = this.parseClassElement(e.superClass !== null);
          n &&
            (a.body.push(n),
            n.type === "MethodDefinition" && n.kind === "constructor"
              ? (s &&
                  this.raiseRecoverable(
                    n.start,
                    "Duplicate constructor in the same class"
                  ),
                (s = !0))
              : n.key &&
                n.key.type === "PrivateIdentifier" &&
                Ur(i, n) &&
                this.raiseRecoverable(
                  n.key.start,
                  "Identifier '#" + n.key.name + "' has already been declared"
                ));
        }
        return (
          (this.strict = r),
          this.next(),
          (e.body = this.finishNode(a, "ClassBody")),
          this.exitClassBody(),
          this.finishNode(e, t ? "ClassDeclaration" : "ClassExpression")
        );
      }),
      (g.parseClassElement = function (e) {
        if (this.eat(o.semi)) return null;
        var t = this.options.ecmaVersion,
          r = this.startNode(),
          i = "",
          a = !1,
          s = !1,
          n = "method",
          u = !1;
        if (this.eatContextual("static")) {
          if (t >= 13 && this.eat(o.braceL))
            return this.parseClassStaticBlock(r), r;
          this.isClassElementNameStart() || this.type === o.star
            ? (u = !0)
            : (i = "static");
        }
        if (
          ((r.static = u),
          !i &&
            t >= 8 &&
            this.eatContextual("async") &&
            ((this.isClassElementNameStart() || this.type === o.star) &&
            !this.canInsertSemicolon()
              ? (s = !0)
              : (i = "async")),
          !i && (t >= 9 || !s) && this.eat(o.star) && (a = !0),
          !i && !s && !a)
        ) {
          var l = this.value;
          (this.eatContextual("get") || this.eatContextual("set")) &&
            (this.isClassElementNameStart() ? (n = l) : (i = l));
        }
        if (
          (i
            ? ((r.computed = !1),
              (r.key = this.startNodeAt(
                this.lastTokStart,
                this.lastTokStartLoc
              )),
              (r.key.name = i),
              this.finishNode(r.key, "Identifier"))
            : this.parseClassElementName(r),
          t < 13 || this.type === o.parenL || n !== "method" || a || s)
        ) {
          var c = !r.static && et(r, "constructor"),
            h = c && e;
          c &&
            n !== "method" &&
            this.raise(r.key.start, "Constructor can't have get/set modifier"),
            (r.kind = c ? "constructor" : n),
            this.parseClassMethod(r, a, s, h);
        } else this.parseClassField(r);
        return r;
      }),
      (g.isClassElementNameStart = function () {
        return (
          this.type === o.name ||
          this.type === o.privateId ||
          this.type === o.num ||
          this.type === o.string ||
          this.type === o.bracketL ||
          this.type.keyword
        );
      }),
      (g.parseClassElementName = function (e) {
        this.type === o.privateId
          ? (this.value === "constructor" &&
              this.raise(
                this.start,
                "Classes can't have an element named '#constructor'"
              ),
            (e.computed = !1),
            (e.key = this.parsePrivateIdent()))
          : this.parsePropertyName(e);
      }),
      (g.parseClassMethod = function (e, t, r, i) {
        var a = e.key;
        e.kind === "constructor"
          ? (t && this.raise(a.start, "Constructor can't be a generator"),
            r && this.raise(a.start, "Constructor can't be an async method"))
          : e.static &&
            et(e, "prototype") &&
            this.raise(
              a.start,
              "Classes may not have a static property named prototype"
            );
        var s = (e.value = this.parseMethod(t, r, i));
        return (
          e.kind === "get" &&
            s.params.length !== 0 &&
            this.raiseRecoverable(s.start, "getter should have no params"),
          e.kind === "set" &&
            s.params.length !== 1 &&
            this.raiseRecoverable(
              s.start,
              "setter should have exactly one param"
            ),
          e.kind === "set" &&
            s.params[0].type === "RestElement" &&
            this.raiseRecoverable(
              s.params[0].start,
              "Setter cannot use rest params"
            ),
          this.finishNode(e, "MethodDefinition")
        );
      }),
      (g.parseClassField = function (e) {
        return (
          et(e, "constructor")
            ? this.raise(
                e.key.start,
                "Classes can't have a field named 'constructor'"
              )
            : e.static &&
              et(e, "prototype") &&
              this.raise(
                e.key.start,
                "Classes can't have a static field named 'prototype'"
              ),
          this.eat(o.eq)
            ? (this.enterScope(Oe | Xe),
              (e.value = this.parseMaybeAssign()),
              this.exitScope())
            : (e.value = null),
          this.semicolon(),
          this.finishNode(e, "PropertyDefinition")
        );
      }),
      (g.parseClassStaticBlock = function (e) {
        e.body = [];
        var t = this.labels;
        for (
          this.labels = [], this.enterScope(ye | Xe);
          this.type !== o.braceR;

        ) {
          var r = this.parseStatement(null);
          e.body.push(r);
        }
        return (
          this.next(),
          this.exitScope(),
          (this.labels = t),
          this.finishNode(e, "StaticBlock")
        );
      }),
      (g.parseClassId = function (e, t) {
        this.type === o.name
          ? ((e.id = this.parseIdent()),
            t && this.checkLValSimple(e.id, ie, !1))
          : (t === !0 && this.unexpected(), (e.id = null));
      }),
      (g.parseClassSuper = function (e) {
        e.superClass = this.eat(o._extends)
          ? this.parseExprSubscripts(null, !1)
          : null;
      }),
      (g.enterClassBody = function () {
        var e = { declared: Object.create(null), used: [] };
        return this.privateNameStack.push(e), e.declared;
      }),
      (g.exitClassBody = function () {
        var e = this.privateNameStack.pop(),
          t = e.declared,
          r = e.used;
        if (this.options.checkPrivateFields)
          for (
            var i = this.privateNameStack.length,
              a = i === 0 ? null : this.privateNameStack[i - 1],
              s = 0;
            s < r.length;
            ++s
          ) {
            var n = r[s];
            ke(t, n.name) ||
              (a
                ? a.used.push(n)
                : this.raiseRecoverable(
                    n.start,
                    "Private field '#" +
                      n.name +
                      "' must be declared in an enclosing class"
                  ));
          }
      });
    function Ur(e, t) {
      var r = t.key.name,
        i = e[r],
        a = "true";
      return (
        t.type === "MethodDefinition" &&
          (t.kind === "get" || t.kind === "set") &&
          (a = (t.static ? "s" : "i") + t.kind),
        (i === "iget" && a === "iset") ||
        (i === "iset" && a === "iget") ||
        (i === "sget" && a === "sset") ||
        (i === "sset" && a === "sget")
          ? ((e[r] = "true"), !1)
          : i
          ? !0
          : ((e[r] = a), !1)
      );
    }
    function et(e, t) {
      var r = e.computed,
        i = e.key;
      return (
        !r &&
        ((i.type === "Identifier" && i.name === t) ||
          (i.type === "Literal" && i.value === t))
      );
    }
    (g.parseExportAllDeclaration = function (e, t) {
      return (
        this.options.ecmaVersion >= 11 &&
          (this.eatContextual("as")
            ? ((e.exported = this.parseModuleExportName()),
              this.checkExport(t, e.exported, this.lastTokStart))
            : (e.exported = null)),
        this.expectContextual("from"),
        this.type !== o.string && this.unexpected(),
        (e.source = this.parseExprAtom()),
        this.options.ecmaVersion >= 16 &&
          (e.attributes = this.parseWithClause()),
        this.semicolon(),
        this.finishNode(e, "ExportAllDeclaration")
      );
    }),
      (g.parseExport = function (e, t) {
        if ((this.next(), this.eat(o.star)))
          return this.parseExportAllDeclaration(e, t);
        if (this.eat(o._default))
          return (
            this.checkExport(t, "default", this.lastTokStart),
            (e.declaration = this.parseExportDefaultDeclaration()),
            this.finishNode(e, "ExportDefaultDeclaration")
          );
        if (this.shouldParseExportStatement())
          (e.declaration = this.parseExportDeclaration(e)),
            e.declaration.type === "VariableDeclaration"
              ? this.checkVariableExport(t, e.declaration.declarations)
              : this.checkExport(t, e.declaration.id, e.declaration.id.start),
            (e.specifiers = []),
            (e.source = null),
            this.options.ecmaVersion >= 16 && (e.attributes = []);
        else {
          if (
            ((e.declaration = null),
            (e.specifiers = this.parseExportSpecifiers(t)),
            this.eatContextual("from"))
          )
            this.type !== o.string && this.unexpected(),
              (e.source = this.parseExprAtom()),
              this.options.ecmaVersion >= 16 &&
                (e.attributes = this.parseWithClause());
          else {
            for (var r = 0, i = e.specifiers; r < i.length; r += 1) {
              var a = i[r];
              this.checkUnreserved(a.local),
                this.checkLocalExport(a.local),
                a.local.type === "Literal" &&
                  this.raise(
                    a.local.start,
                    "A string literal cannot be used as an exported binding without `from`."
                  );
            }
            (e.source = null),
              this.options.ecmaVersion >= 16 && (e.attributes = []);
          }
          this.semicolon();
        }
        return this.finishNode(e, "ExportNamedDeclaration");
      }),
      (g.parseExportDeclaration = function (e) {
        return this.parseStatement(null);
      }),
      (g.parseExportDefaultDeclaration = function () {
        var e;
        if (this.type === o._function || (e = this.isAsyncFunction())) {
          var t = this.startNode();
          return (
            this.next(), e && this.next(), this.parseFunction(t, De | ai, !1, e)
          );
        } else if (this.type === o._class) {
          var r = this.startNode();
          return this.parseClass(r, "nullableID");
        } else {
          var i = this.parseMaybeAssign();
          return this.semicolon(), i;
        }
      }),
      (g.checkExport = function (e, t, r) {
        e &&
          (typeof t != "string" &&
            (t = t.type === "Identifier" ? t.name : t.value),
          ke(e, t) && this.raiseRecoverable(r, "Duplicate export '" + t + "'"),
          (e[t] = !0));
      }),
      (g.checkPatternExport = function (e, t) {
        var r = t.type;
        if (r === "Identifier") this.checkExport(e, t, t.start);
        else if (r === "ObjectPattern")
          for (var i = 0, a = t.properties; i < a.length; i += 1) {
            var s = a[i];
            this.checkPatternExport(e, s);
          }
        else if (r === "ArrayPattern")
          for (var n = 0, u = t.elements; n < u.length; n += 1) {
            var l = u[n];
            l && this.checkPatternExport(e, l);
          }
        else
          r === "Property"
            ? this.checkPatternExport(e, t.value)
            : r === "AssignmentPattern"
            ? this.checkPatternExport(e, t.left)
            : r === "RestElement" && this.checkPatternExport(e, t.argument);
      }),
      (g.checkVariableExport = function (e, t) {
        if (e)
          for (var r = 0, i = t; r < i.length; r += 1) {
            var a = i[r];
            this.checkPatternExport(e, a.id);
          }
      }),
      (g.shouldParseExportStatement = function () {
        return (
          this.type.keyword === "var" ||
          this.type.keyword === "const" ||
          this.type.keyword === "class" ||
          this.type.keyword === "function" ||
          this.isLet() ||
          this.isAsyncFunction()
        );
      }),
      (g.parseExportSpecifier = function (e) {
        var t = this.startNode();
        return (
          (t.local = this.parseModuleExportName()),
          (t.exported = this.eatContextual("as")
            ? this.parseModuleExportName()
            : t.local),
          this.checkExport(e, t.exported, t.exported.start),
          this.finishNode(t, "ExportSpecifier")
        );
      }),
      (g.parseExportSpecifiers = function (e) {
        var t = [],
          r = !0;
        for (this.expect(o.braceL); !this.eat(o.braceR); ) {
          if (r) r = !1;
          else if ((this.expect(o.comma), this.afterTrailingComma(o.braceR)))
            break;
          t.push(this.parseExportSpecifier(e));
        }
        return t;
      }),
      (g.parseImport = function (e) {
        return (
          this.next(),
          this.type === o.string
            ? ((e.specifiers = jr), (e.source = this.parseExprAtom()))
            : ((e.specifiers = this.parseImportSpecifiers()),
              this.expectContextual("from"),
              (e.source =
                this.type === o.string
                  ? this.parseExprAtom()
                  : this.unexpected())),
          this.options.ecmaVersion >= 16 &&
            (e.attributes = this.parseWithClause()),
          this.semicolon(),
          this.finishNode(e, "ImportDeclaration")
        );
      }),
      (g.parseImportSpecifier = function () {
        var e = this.startNode();
        return (
          (e.imported = this.parseModuleExportName()),
          this.eatContextual("as")
            ? (e.local = this.parseIdent())
            : (this.checkUnreserved(e.imported), (e.local = e.imported)),
          this.checkLValSimple(e.local, ie),
          this.finishNode(e, "ImportSpecifier")
        );
      }),
      (g.parseImportDefaultSpecifier = function () {
        var e = this.startNode();
        return (
          (e.local = this.parseIdent()),
          this.checkLValSimple(e.local, ie),
          this.finishNode(e, "ImportDefaultSpecifier")
        );
      }),
      (g.parseImportNamespaceSpecifier = function () {
        var e = this.startNode();
        return (
          this.next(),
          this.expectContextual("as"),
          (e.local = this.parseIdent()),
          this.checkLValSimple(e.local, ie),
          this.finishNode(e, "ImportNamespaceSpecifier")
        );
      }),
      (g.parseImportSpecifiers = function () {
        var e = [],
          t = !0;
        if (
          this.type === o.name &&
          (e.push(this.parseImportDefaultSpecifier()), !this.eat(o.comma))
        )
          return e;
        if (this.type === o.star)
          return e.push(this.parseImportNamespaceSpecifier()), e;
        for (this.expect(o.braceL); !this.eat(o.braceR); ) {
          if (t) t = !1;
          else if ((this.expect(o.comma), this.afterTrailingComma(o.braceR)))
            break;
          e.push(this.parseImportSpecifier());
        }
        return e;
      }),
      (g.parseWithClause = function () {
        var e = [];
        if (!this.eat(o._with)) return e;
        this.expect(o.braceL);
        for (var t = {}, r = !0; !this.eat(o.braceR); ) {
          if (r) r = !1;
          else if ((this.expect(o.comma), this.afterTrailingComma(o.braceR)))
            break;
          var i = this.parseImportAttribute(),
            a = i.key.type === "Identifier" ? i.key.name : i.key.value;
          ke(t, a) &&
            this.raiseRecoverable(
              i.key.start,
              "Duplicate attribute key '" + a + "'"
            ),
            (t[a] = !0),
            e.push(i);
        }
        return e;
      }),
      (g.parseImportAttribute = function () {
        var e = this.startNode();
        return (
          (e.key =
            this.type === o.string
              ? this.parseExprAtom()
              : this.parseIdent(this.options.allowReserved !== "never")),
          this.expect(o.colon),
          this.type !== o.string && this.unexpected(),
          (e.value = this.parseExprAtom()),
          this.finishNode(e, "ImportAttribute")
        );
      }),
      (g.parseModuleExportName = function () {
        if (this.options.ecmaVersion >= 13 && this.type === o.string) {
          var e = this.parseLiteral(this.value);
          return (
            Br.test(e.value) &&
              this.raise(
                e.start,
                "An export name cannot include a lone surrogate."
              ),
            e
          );
        }
        return this.parseIdent(!0);
      }),
      (g.adaptDirectivePrologue = function (e) {
        for (var t = 0; t < e.length && this.isDirectiveCandidate(e[t]); ++t)
          e[t].directive = e[t].expression.raw.slice(1, -1);
      }),
      (g.isDirectiveCandidate = function (e) {
        return (
          this.options.ecmaVersion >= 5 &&
          e.type === "ExpressionStatement" &&
          e.expression.type === "Literal" &&
          typeof e.expression.value == "string" &&
          (this.input[e.start] === '"' || this.input[e.start] === "'")
        );
      });
    var G = V.prototype;
    (G.toAssignable = function (e, t, r) {
      if (this.options.ecmaVersion >= 6 && e)
        switch (e.type) {
          case "Identifier":
            this.inAsync &&
              e.name === "await" &&
              this.raise(
                e.start,
                "Cannot use 'await' as identifier inside an async function"
              );
            break;
          case "ObjectPattern":
          case "ArrayPattern":
          case "AssignmentPattern":
          case "RestElement":
            break;
          case "ObjectExpression":
            (e.type = "ObjectPattern"), r && this.checkPatternErrors(r, !0);
            for (var i = 0, a = e.properties; i < a.length; i += 1) {
              var s = a[i];
              this.toAssignable(s, t),
                s.type === "RestElement" &&
                  (s.argument.type === "ArrayPattern" ||
                    s.argument.type === "ObjectPattern") &&
                  this.raise(s.argument.start, "Unexpected token");
            }
            break;
          case "Property":
            e.kind !== "init" &&
              this.raise(
                e.key.start,
                "Object pattern can't contain getter or setter"
              ),
              this.toAssignable(e.value, t);
            break;
          case "ArrayExpression":
            (e.type = "ArrayPattern"),
              r && this.checkPatternErrors(r, !0),
              this.toAssignableList(e.elements, t);
            break;
          case "SpreadElement":
            (e.type = "RestElement"),
              this.toAssignable(e.argument, t),
              e.argument.type === "AssignmentPattern" &&
                this.raise(
                  e.argument.start,
                  "Rest elements cannot have a default value"
                );
            break;
          case "AssignmentExpression":
            e.operator !== "=" &&
              this.raise(
                e.left.end,
                "Only '=' operator can be used for specifying default value."
              ),
              (e.type = "AssignmentPattern"),
              delete e.operator,
              this.toAssignable(e.left, t);
            break;
          case "ParenthesizedExpression":
            this.toAssignable(e.expression, t, r);
            break;
          case "ChainExpression":
            this.raiseRecoverable(
              e.start,
              "Optional chaining cannot appear in left-hand side"
            );
            break;
          case "MemberExpression":
            if (!t) break;
          default:
            this.raise(e.start, "Assigning to rvalue");
        }
      else r && this.checkPatternErrors(r, !0);
      return e;
    }),
      (G.toAssignableList = function (e, t) {
        for (var r = e.length, i = 0; i < r; i++) {
          var a = e[i];
          a && this.toAssignable(a, t);
        }
        if (r) {
          var s = e[r - 1];
          this.options.ecmaVersion === 6 &&
            t &&
            s &&
            s.type === "RestElement" &&
            s.argument.type !== "Identifier" &&
            this.unexpected(s.argument.start);
        }
        return e;
      }),
      (G.parseSpread = function (e) {
        var t = this.startNode();
        return (
          this.next(),
          (t.argument = this.parseMaybeAssign(!1, e)),
          this.finishNode(t, "SpreadElement")
        );
      }),
      (G.parseRestBinding = function () {
        var e = this.startNode();
        return (
          this.next(),
          this.options.ecmaVersion === 6 &&
            this.type !== o.name &&
            this.unexpected(),
          (e.argument = this.parseBindingAtom()),
          this.finishNode(e, "RestElement")
        );
      }),
      (G.parseBindingAtom = function () {
        if (this.options.ecmaVersion >= 6)
          switch (this.type) {
            case o.bracketL:
              var e = this.startNode();
              return (
                this.next(),
                (e.elements = this.parseBindingList(o.bracketR, !0, !0)),
                this.finishNode(e, "ArrayPattern")
              );
            case o.braceL:
              return this.parseObj(!0);
          }
        return this.parseIdent();
      }),
      (G.parseBindingList = function (e, t, r, i) {
        for (var a = [], s = !0; !this.eat(e); )
          if ((s ? (s = !1) : this.expect(o.comma), t && this.type === o.comma))
            a.push(null);
          else {
            if (r && this.afterTrailingComma(e)) break;
            if (this.type === o.ellipsis) {
              var n = this.parseRestBinding();
              this.parseBindingListItem(n),
                a.push(n),
                this.type === o.comma &&
                  this.raiseRecoverable(
                    this.start,
                    "Comma is not permitted after the rest element"
                  ),
                this.expect(e);
              break;
            } else a.push(this.parseAssignableListItem(i));
          }
        return a;
      }),
      (G.parseAssignableListItem = function (e) {
        var t = this.parseMaybeDefault(this.start, this.startLoc);
        return this.parseBindingListItem(t), t;
      }),
      (G.parseBindingListItem = function (e) {
        return e;
      }),
      (G.parseMaybeDefault = function (e, t, r) {
        if (
          ((r = r || this.parseBindingAtom()),
          this.options.ecmaVersion < 6 || !this.eat(o.eq))
        )
          return r;
        var i = this.startNodeAt(e, t);
        return (
          (i.left = r),
          (i.right = this.parseMaybeAssign()),
          this.finishNode(i, "AssignmentPattern")
        );
      }),
      (G.checkLValSimple = function (e, t, r) {
        t === void 0 && (t = Ze);
        var i = t !== Ze;
        switch (e.type) {
          case "Identifier":
            this.strict &&
              this.reservedWordsStrictBind.test(e.name) &&
              this.raiseRecoverable(
                e.start,
                (i ? "Binding " : "Assigning to ") + e.name + " in strict mode"
              ),
              i &&
                (t === ie &&
                  e.name === "let" &&
                  this.raiseRecoverable(
                    e.start,
                    "let is disallowed as a lexically bound name"
                  ),
                r &&
                  (ke(r, e.name) &&
                    this.raiseRecoverable(e.start, "Argument name clash"),
                  (r[e.name] = !0)),
                t !== ri && this.declareName(e.name, t, e.start));
            break;
          case "ChainExpression":
            this.raiseRecoverable(
              e.start,
              "Optional chaining cannot appear in left-hand side"
            );
            break;
          case "MemberExpression":
            i && this.raiseRecoverable(e.start, "Binding member expression");
            break;
          case "ParenthesizedExpression":
            return (
              i &&
                this.raiseRecoverable(
                  e.start,
                  "Binding parenthesized expression"
                ),
              this.checkLValSimple(e.expression, t, r)
            );
          default:
            this.raise(e.start, (i ? "Binding" : "Assigning to") + " rvalue");
        }
      }),
      (G.checkLValPattern = function (e, t, r) {
        switch ((t === void 0 && (t = Ze), e.type)) {
          case "ObjectPattern":
            for (var i = 0, a = e.properties; i < a.length; i += 1) {
              var s = a[i];
              this.checkLValInnerPattern(s, t, r);
            }
            break;
          case "ArrayPattern":
            for (var n = 0, u = e.elements; n < u.length; n += 1) {
              var l = u[n];
              l && this.checkLValInnerPattern(l, t, r);
            }
            break;
          default:
            this.checkLValSimple(e, t, r);
        }
      }),
      (G.checkLValInnerPattern = function (e, t, r) {
        switch ((t === void 0 && (t = Ze), e.type)) {
          case "Property":
            this.checkLValInnerPattern(e.value, t, r);
            break;
          case "AssignmentPattern":
            this.checkLValPattern(e.left, t, r);
            break;
          case "RestElement":
            this.checkLValPattern(e.argument, t, r);
            break;
          default:
            this.checkLValPattern(e, t, r);
        }
      });
    var Q = function Q(t, r, i, a, s) {
        (this.token = t),
          (this.isExpr = !!r),
          (this.preserveSpace = !!i),
          (this.override = a),
          (this.generator = !!s);
      },
      A = {
        b_stat: new Q("{", !1),
        b_expr: new Q("{", !0),
        b_tmpl: new Q("${", !1),
        p_stat: new Q("(", !1),
        p_expr: new Q("(", !0),
        q_tmpl: new Q("`", !0, !0, function (e) {
          return e.tryReadTemplateToken();
        }),
        f_stat: new Q("function", !1),
        f_expr: new Q("function", !0),
        f_expr_gen: new Q("function", !0, !1, null, !0),
        f_gen: new Q("function", !1, !1, null, !0),
      },
      Ce = V.prototype;
    (Ce.initialContext = function () {
      return [A.b_stat];
    }),
      (Ce.curContext = function () {
        return this.context[this.context.length - 1];
      }),
      (Ce.braceIsBlock = function (e) {
        var t = this.curContext();
        return t === A.f_expr || t === A.f_stat
          ? !0
          : e === o.colon && (t === A.b_stat || t === A.b_expr)
          ? !t.isExpr
          : e === o._return || (e === o.name && this.exprAllowed)
          ? W.test(this.input.slice(this.lastTokEnd, this.start))
          : e === o._else ||
            e === o.semi ||
            e === o.eof ||
            e === o.parenR ||
            e === o.arrow
          ? !0
          : e === o.braceL
          ? t === A.b_stat
          : e === o._var || e === o._const || e === o.name
          ? !1
          : !this.exprAllowed;
      }),
      (Ce.inGeneratorContext = function () {
        for (var e = this.context.length - 1; e >= 1; e--) {
          var t = this.context[e];
          if (t.token === "function") return t.generator;
        }
        return !1;
      }),
      (Ce.updateContext = function (e) {
        var t,
          r = this.type;
        r.keyword && e === o.dot
          ? (this.exprAllowed = !1)
          : (t = r.updateContext)
          ? t.call(this, e)
          : (this.exprAllowed = r.beforeExpr);
      }),
      (Ce.overrideContext = function (e) {
        this.curContext() !== e && (this.context[this.context.length - 1] = e);
      }),
      (o.parenR.updateContext = o.braceR.updateContext =
        function () {
          if (this.context.length === 1) {
            this.exprAllowed = !0;
            return;
          }
          var e = this.context.pop();
          e === A.b_stat &&
            this.curContext().token === "function" &&
            (e = this.context.pop()),
            (this.exprAllowed = !e.isExpr);
        }),
      (o.braceL.updateContext = function (e) {
        this.context.push(this.braceIsBlock(e) ? A.b_stat : A.b_expr),
          (this.exprAllowed = !0);
      }),
      (o.dollarBraceL.updateContext = function () {
        this.context.push(A.b_tmpl), (this.exprAllowed = !0);
      }),
      (o.parenL.updateContext = function (e) {
        var t = e === o._if || e === o._for || e === o._with || e === o._while;
        this.context.push(t ? A.p_stat : A.p_expr), (this.exprAllowed = !0);
      }),
      (o.incDec.updateContext = function () {}),
      (o._function.updateContext = o._class.updateContext =
        function (e) {
          e.beforeExpr &&
          e !== o._else &&
          !(e === o.semi && this.curContext() !== A.p_stat) &&
          !(
            e === o._return &&
            W.test(this.input.slice(this.lastTokEnd, this.start))
          ) &&
          !((e === o.colon || e === o.braceL) && this.curContext() === A.b_stat)
            ? this.context.push(A.f_expr)
            : this.context.push(A.f_stat),
            (this.exprAllowed = !1);
        }),
      (o.colon.updateContext = function () {
        this.curContext().token === "function" && this.context.pop(),
          (this.exprAllowed = !0);
      }),
      (o.backQuote.updateContext = function () {
        this.curContext() === A.q_tmpl
          ? this.context.pop()
          : this.context.push(A.q_tmpl),
          (this.exprAllowed = !1);
      }),
      (o.star.updateContext = function (e) {
        if (e === o._function) {
          var t = this.context.length - 1;
          this.context[t] === A.f_expr
            ? (this.context[t] = A.f_expr_gen)
            : (this.context[t] = A.f_gen);
        }
        this.exprAllowed = !0;
      }),
      (o.name.updateContext = function (e) {
        var t = !1;
        this.options.ecmaVersion >= 6 &&
          e !== o.dot &&
          ((this.value === "of" && !this.exprAllowed) ||
            (this.value === "yield" && this.inGeneratorContext())) &&
          (t = !0),
          (this.exprAllowed = t);
      });
    var x = V.prototype;
    (x.checkPropClash = function (e, t, r) {
      if (
        !(this.options.ecmaVersion >= 9 && e.type === "SpreadElement") &&
        !(
          this.options.ecmaVersion >= 6 &&
          (e.computed || e.method || e.shorthand)
        )
      ) {
        var i = e.key,
          a;
        switch (i.type) {
          case "Identifier":
            a = i.name;
            break;
          case "Literal":
            a = String(i.value);
            break;
          default:
            return;
        }
        var s = e.kind;
        if (this.options.ecmaVersion >= 6) {
          a === "__proto__" &&
            s === "init" &&
            (t.proto &&
              (r
                ? r.doubleProto < 0 && (r.doubleProto = i.start)
                : this.raiseRecoverable(
                    i.start,
                    "Redefinition of __proto__ property"
                  )),
            (t.proto = !0));
          return;
        }
        a = "$" + a;
        var n = t[a];
        if (n) {
          var u;
          s === "init"
            ? (u = (this.strict && n.init) || n.get || n.set)
            : (u = n.init || n[s]),
            u && this.raiseRecoverable(i.start, "Redefinition of property");
        } else n = t[a] = { init: !1, get: !1, set: !1 };
        n[s] = !0;
      }
    }),
      (x.parseExpression = function (e, t) {
        var r = this.start,
          i = this.startLoc,
          a = this.parseMaybeAssign(e, t);
        if (this.type === o.comma) {
          var s = this.startNodeAt(r, i);
          for (s.expressions = [a]; this.eat(o.comma); )
            s.expressions.push(this.parseMaybeAssign(e, t));
          return this.finishNode(s, "SequenceExpression");
        }
        return a;
      }),
      (x.parseMaybeAssign = function (e, t, r) {
        if (this.isContextual("yield")) {
          if (this.inGenerator) return this.parseYield(e);
          this.exprAllowed = !1;
        }
        var i = !1,
          a = -1,
          s = -1,
          n = -1;
        t
          ? ((a = t.parenthesizedAssign),
            (s = t.trailingComma),
            (n = t.doubleProto),
            (t.parenthesizedAssign = t.trailingComma = -1))
          : ((t = new Je()), (i = !0));
        var u = this.start,
          l = this.startLoc;
        (this.type === o.parenL || this.type === o.name) &&
          ((this.potentialArrowAt = this.start),
          (this.potentialArrowInForAwait = e === "await"));
        var c = this.parseMaybeConditional(e, t);
        if ((r && (c = r.call(this, c, u, l)), this.type.isAssign)) {
          var h = this.startNodeAt(u, l);
          return (
            (h.operator = this.value),
            this.type === o.eq && (c = this.toAssignable(c, !1, t)),
            i || (t.parenthesizedAssign = t.trailingComma = t.doubleProto = -1),
            t.shorthandAssign >= c.start && (t.shorthandAssign = -1),
            this.type === o.eq
              ? this.checkLValPattern(c)
              : this.checkLValSimple(c),
            (h.left = c),
            this.next(),
            (h.right = this.parseMaybeAssign(e)),
            n > -1 && (t.doubleProto = n),
            this.finishNode(h, "AssignmentExpression")
          );
        } else i && this.checkExpressionErrors(t, !0);
        return (
          a > -1 && (t.parenthesizedAssign = a),
          s > -1 && (t.trailingComma = s),
          c
        );
      }),
      (x.parseMaybeConditional = function (e, t) {
        var r = this.start,
          i = this.startLoc,
          a = this.parseExprOps(e, t);
        if (this.checkExpressionErrors(t)) return a;
        if (this.eat(o.question)) {
          var s = this.startNodeAt(r, i);
          return (
            (s.test = a),
            (s.consequent = this.parseMaybeAssign()),
            this.expect(o.colon),
            (s.alternate = this.parseMaybeAssign(e)),
            this.finishNode(s, "ConditionalExpression")
          );
        }
        return a;
      }),
      (x.parseExprOps = function (e, t) {
        var r = this.start,
          i = this.startLoc,
          a = this.parseMaybeUnary(t, !1, !1, e);
        return this.checkExpressionErrors(t) ||
          (a.start === r && a.type === "ArrowFunctionExpression")
          ? a
          : this.parseExprOp(a, r, i, -1, e);
      }),
      (x.parseExprOp = function (e, t, r, i, a) {
        var s = this.type.binop;
        if (s != null && (!a || this.type !== o._in) && s > i) {
          var n = this.type === o.logicalOR || this.type === o.logicalAND,
            u = this.type === o.coalesce;
          u && (s = o.logicalAND.binop);
          var l = this.value;
          this.next();
          var c = this.start,
            h = this.startLoc,
            p = this.parseExprOp(
              this.parseMaybeUnary(null, !1, !1, a),
              c,
              h,
              s,
              a
            ),
            S = this.buildBinary(t, r, e, p, l, n || u);
          return (
            ((n && this.type === o.coalesce) ||
              (u &&
                (this.type === o.logicalOR || this.type === o.logicalAND))) &&
              this.raiseRecoverable(
                this.start,
                "Logical expressions and coalesce expressions cannot be mixed. Wrap either by parentheses"
              ),
            this.parseExprOp(S, t, r, i, a)
          );
        }
        return e;
      }),
      (x.buildBinary = function (e, t, r, i, a, s) {
        i.type === "PrivateIdentifier" &&
          this.raise(
            i.start,
            "Private identifier can only be left side of binary expression"
          );
        var n = this.startNodeAt(e, t);
        return (
          (n.left = r),
          (n.operator = a),
          (n.right = i),
          this.finishNode(n, s ? "LogicalExpression" : "BinaryExpression")
        );
      }),
      (x.parseMaybeUnary = function (e, t, r, i) {
        var a = this.start,
          s = this.startLoc,
          n;
        if (this.isContextual("await") && this.canAwait)
          (n = this.parseAwait(i)), (t = !0);
        else if (this.type.prefix) {
          var u = this.startNode(),
            l = this.type === o.incDec;
          (u.operator = this.value),
            (u.prefix = !0),
            this.next(),
            (u.argument = this.parseMaybeUnary(null, !0, l, i)),
            this.checkExpressionErrors(e, !0),
            l
              ? this.checkLValSimple(u.argument)
              : this.strict && u.operator === "delete" && si(u.argument)
              ? this.raiseRecoverable(
                  u.start,
                  "Deleting local variable in strict mode"
                )
              : u.operator === "delete" && wt(u.argument)
              ? this.raiseRecoverable(
                  u.start,
                  "Private fields can not be deleted"
                )
              : (t = !0),
            (n = this.finishNode(
              u,
              l ? "UpdateExpression" : "UnaryExpression"
            ));
        } else if (!t && this.type === o.privateId)
          (i || this.privateNameStack.length === 0) &&
            this.options.checkPrivateFields &&
            this.unexpected(),
            (n = this.parsePrivateIdent()),
            this.type !== o._in && this.unexpected();
        else {
          if (
            ((n = this.parseExprSubscripts(e, i)),
            this.checkExpressionErrors(e))
          )
            return n;
          for (; this.type.postfix && !this.canInsertSemicolon(); ) {
            var c = this.startNodeAt(a, s);
            (c.operator = this.value),
              (c.prefix = !1),
              (c.argument = n),
              this.checkLValSimple(n),
              this.next(),
              (n = this.finishNode(c, "UpdateExpression"));
          }
        }
        if (!r && this.eat(o.starstar))
          if (t) this.unexpected(this.lastTokStart);
          else
            return this.buildBinary(
              a,
              s,
              n,
              this.parseMaybeUnary(null, !1, !1, i),
              "**",
              !1
            );
        else return n;
      });
    function si(e) {
      return (
        e.type === "Identifier" ||
        (e.type === "ParenthesizedExpression" && si(e.expression))
      );
    }
    function wt(e) {
      return (
        (e.type === "MemberExpression" &&
          e.property.type === "PrivateIdentifier") ||
        (e.type === "ChainExpression" && wt(e.expression)) ||
        (e.type === "ParenthesizedExpression" && wt(e.expression))
      );
    }
    (x.parseExprSubscripts = function (e, t) {
      var r = this.start,
        i = this.startLoc,
        a = this.parseExprAtom(e, t);
      if (
        a.type === "ArrowFunctionExpression" &&
        this.input.slice(this.lastTokStart, this.lastTokEnd) !== ")"
      )
        return a;
      var s = this.parseSubscripts(a, r, i, !1, t);
      return (
        e &&
          s.type === "MemberExpression" &&
          (e.parenthesizedAssign >= s.start && (e.parenthesizedAssign = -1),
          e.parenthesizedBind >= s.start && (e.parenthesizedBind = -1),
          e.trailingComma >= s.start && (e.trailingComma = -1)),
        s
      );
    }),
      (x.parseSubscripts = function (e, t, r, i, a) {
        for (
          var s =
              this.options.ecmaVersion >= 8 &&
              e.type === "Identifier" &&
              e.name === "async" &&
              this.lastTokEnd === e.end &&
              !this.canInsertSemicolon() &&
              e.end - e.start === 5 &&
              this.potentialArrowAt === e.start,
            n = !1;
          ;

        ) {
          var u = this.parseSubscript(e, t, r, i, s, n, a);
          if (
            (u.optional && (n = !0),
            u === e || u.type === "ArrowFunctionExpression")
          ) {
            if (n) {
              var l = this.startNodeAt(t, r);
              (l.expression = u), (u = this.finishNode(l, "ChainExpression"));
            }
            return u;
          }
          e = u;
        }
      }),
      (x.shouldParseAsyncArrow = function () {
        return !this.canInsertSemicolon() && this.eat(o.arrow);
      }),
      (x.parseSubscriptAsyncArrow = function (e, t, r, i) {
        return this.parseArrowExpression(this.startNodeAt(e, t), r, !0, i);
      }),
      (x.parseSubscript = function (e, t, r, i, a, s, n) {
        var u = this.options.ecmaVersion >= 11,
          l = u && this.eat(o.questionDot);
        i &&
          l &&
          this.raise(
            this.lastTokStart,
            "Optional chaining cannot appear in the callee of new expressions"
          );
        var c = this.eat(o.bracketL);
        if (
          c ||
          (l && this.type !== o.parenL && this.type !== o.backQuote) ||
          this.eat(o.dot)
        ) {
          var h = this.startNodeAt(t, r);
          (h.object = e),
            c
              ? ((h.property = this.parseExpression()), this.expect(o.bracketR))
              : this.type === o.privateId && e.type !== "Super"
              ? (h.property = this.parsePrivateIdent())
              : (h.property = this.parseIdent(
                  this.options.allowReserved !== "never"
                )),
            (h.computed = !!c),
            u && (h.optional = l),
            (e = this.finishNode(h, "MemberExpression"));
        } else if (!i && this.eat(o.parenL)) {
          var p = new Je(),
            S = this.yieldPos,
            C = this.awaitPos,
            L = this.awaitIdentPos;
          (this.yieldPos = 0), (this.awaitPos = 0), (this.awaitIdentPos = 0);
          var K = this.parseExprList(
            o.parenR,
            this.options.ecmaVersion >= 8,
            !1,
            p
          );
          if (a && !l && this.shouldParseAsyncArrow())
            return (
              this.checkPatternErrors(p, !1),
              this.checkYieldAwaitInDefaultParams(),
              this.awaitIdentPos > 0 &&
                this.raise(
                  this.awaitIdentPos,
                  "Cannot use 'await' as identifier inside an async function"
                ),
              (this.yieldPos = S),
              (this.awaitPos = C),
              (this.awaitIdentPos = L),
              this.parseSubscriptAsyncArrow(t, r, K, n)
            );
          this.checkExpressionErrors(p, !0),
            (this.yieldPos = S || this.yieldPos),
            (this.awaitPos = C || this.awaitPos),
            (this.awaitIdentPos = L || this.awaitIdentPos);
          var de = this.startNodeAt(t, r);
          (de.callee = e),
            (de.arguments = K),
            u && (de.optional = l),
            (e = this.finishNode(de, "CallExpression"));
        } else if (this.type === o.backQuote) {
          (l || s) &&
            this.raise(
              this.start,
              "Optional chaining cannot appear in the tag of tagged template expressions"
            );
          var Le = this.startNodeAt(t, r);
          (Le.tag = e),
            (Le.quasi = this.parseTemplate({ isTagged: !0 })),
            (e = this.finishNode(Le, "TaggedTemplateExpression"));
        }
        return e;
      }),
      (x.parseExprAtom = function (e, t, r) {
        this.type === o.slash && this.readRegexp();
        var i,
          a = this.potentialArrowAt === this.start;
        switch (this.type) {
          case o._super:
            return (
              this.allowSuper ||
                this.raise(this.start, "'super' keyword outside a method"),
              (i = this.startNode()),
              this.next(),
              this.type === o.parenL &&
                !this.allowDirectSuper &&
                this.raise(
                  i.start,
                  "super() call outside constructor of a subclass"
                ),
              this.type !== o.dot &&
                this.type !== o.bracketL &&
                this.type !== o.parenL &&
                this.unexpected(),
              this.finishNode(i, "Super")
            );
          case o._this:
            return (
              (i = this.startNode()),
              this.next(),
              this.finishNode(i, "ThisExpression")
            );
          case o.name:
            var s = this.start,
              n = this.startLoc,
              u = this.containsEsc,
              l = this.parseIdent(!1);
            if (
              this.options.ecmaVersion >= 8 &&
              !u &&
              l.name === "async" &&
              !this.canInsertSemicolon() &&
              this.eat(o._function)
            )
              return (
                this.overrideContext(A.f_expr),
                this.parseFunction(this.startNodeAt(s, n), 0, !1, !0, t)
              );
            if (a && !this.canInsertSemicolon()) {
              if (this.eat(o.arrow))
                return this.parseArrowExpression(
                  this.startNodeAt(s, n),
                  [l],
                  !1,
                  t
                );
              if (
                this.options.ecmaVersion >= 8 &&
                l.name === "async" &&
                this.type === o.name &&
                !u &&
                (!this.potentialArrowInForAwait ||
                  this.value !== "of" ||
                  this.containsEsc)
              )
                return (
                  (l = this.parseIdent(!1)),
                  (this.canInsertSemicolon() || !this.eat(o.arrow)) &&
                    this.unexpected(),
                  this.parseArrowExpression(this.startNodeAt(s, n), [l], !0, t)
                );
            }
            return l;
          case o.regexp:
            var c = this.value;
            return (
              (i = this.parseLiteral(c.value)),
              (i.regex = { pattern: c.pattern, flags: c.flags }),
              i
            );
          case o.num:
          case o.string:
            return this.parseLiteral(this.value);
          case o._null:
          case o._true:
          case o._false:
            return (
              (i = this.startNode()),
              (i.value = this.type === o._null ? null : this.type === o._true),
              (i.raw = this.type.keyword),
              this.next(),
              this.finishNode(i, "Literal")
            );
          case o.parenL:
            var h = this.start,
              p = this.parseParenAndDistinguishExpression(a, t);
            return (
              e &&
                (e.parenthesizedAssign < 0 &&
                  !this.isSimpleAssignTarget(p) &&
                  (e.parenthesizedAssign = h),
                e.parenthesizedBind < 0 && (e.parenthesizedBind = h)),
              p
            );
          case o.bracketL:
            return (
              (i = this.startNode()),
              this.next(),
              (i.elements = this.parseExprList(o.bracketR, !0, !0, e)),
              this.finishNode(i, "ArrayExpression")
            );
          case o.braceL:
            return this.overrideContext(A.b_expr), this.parseObj(!1, e);
          case o._function:
            return (
              (i = this.startNode()), this.next(), this.parseFunction(i, 0)
            );
          case o._class:
            return this.parseClass(this.startNode(), !1);
          case o._new:
            return this.parseNew();
          case o.backQuote:
            return this.parseTemplate();
          case o._import:
            return this.options.ecmaVersion >= 11
              ? this.parseExprImport(r)
              : this.unexpected();
          default:
            return this.parseExprAtomDefault();
        }
      }),
      (x.parseExprAtomDefault = function () {
        this.unexpected();
      }),
      (x.parseExprImport = function (e) {
        var t = this.startNode();
        if (
          (this.containsEsc &&
            this.raiseRecoverable(
              this.start,
              "Escape sequence in keyword import"
            ),
          this.next(),
          this.type === o.parenL && !e)
        )
          return this.parseDynamicImport(t);
        if (this.type === o.dot) {
          var r = this.startNodeAt(t.start, t.loc && t.loc.start);
          return (
            (r.name = "import"),
            (t.meta = this.finishNode(r, "Identifier")),
            this.parseImportMeta(t)
          );
        } else this.unexpected();
      }),
      (x.parseDynamicImport = function (e) {
        if (
          (this.next(),
          (e.source = this.parseMaybeAssign()),
          this.options.ecmaVersion >= 16)
        )
          this.eat(o.parenR)
            ? (e.options = null)
            : (this.expect(o.comma),
              this.afterTrailingComma(o.parenR)
                ? (e.options = null)
                : ((e.options = this.parseMaybeAssign()),
                  this.eat(o.parenR) ||
                    (this.expect(o.comma),
                    this.afterTrailingComma(o.parenR) || this.unexpected())));
        else if (!this.eat(o.parenR)) {
          var t = this.start;
          this.eat(o.comma) && this.eat(o.parenR)
            ? this.raiseRecoverable(
                t,
                "Trailing comma is not allowed in import()"
              )
            : this.unexpected(t);
        }
        return this.finishNode(e, "ImportExpression");
      }),
      (x.parseImportMeta = function (e) {
        this.next();
        var t = this.containsEsc;
        return (
          (e.property = this.parseIdent(!0)),
          e.property.name !== "meta" &&
            this.raiseRecoverable(
              e.property.start,
              "The only valid meta property for import is 'import.meta'"
            ),
          t &&
            this.raiseRecoverable(
              e.start,
              "'import.meta' must not contain escaped characters"
            ),
          this.options.sourceType !== "module" &&
            !this.options.allowImportExportEverywhere &&
            this.raiseRecoverable(
              e.start,
              "Cannot use 'import.meta' outside a module"
            ),
          this.finishNode(e, "MetaProperty")
        );
      }),
      (x.parseLiteral = function (e) {
        var t = this.startNode();
        return (
          (t.value = e),
          (t.raw = this.input.slice(this.start, this.end)),
          t.raw.charCodeAt(t.raw.length - 1) === 110 &&
            (t.bigint = t.raw.slice(0, -1).replace(/_/g, "")),
          this.next(),
          this.finishNode(t, "Literal")
        );
      }),
      (x.parseParenExpression = function () {
        this.expect(o.parenL);
        var e = this.parseExpression();
        return this.expect(o.parenR), e;
      }),
      (x.shouldParseArrow = function (e) {
        return !this.canInsertSemicolon();
      }),
      (x.parseParenAndDistinguishExpression = function (e, t) {
        var r = this.start,
          i = this.startLoc,
          a,
          s = this.options.ecmaVersion >= 8;
        if (this.options.ecmaVersion >= 6) {
          this.next();
          var n = this.start,
            u = this.startLoc,
            l = [],
            c = !0,
            h = !1,
            p = new Je(),
            S = this.yieldPos,
            C = this.awaitPos,
            L;
          for (this.yieldPos = 0, this.awaitPos = 0; this.type !== o.parenR; )
            if (
              (c ? (c = !1) : this.expect(o.comma),
              s && this.afterTrailingComma(o.parenR, !0))
            ) {
              h = !0;
              break;
            } else if (this.type === o.ellipsis) {
              (L = this.start),
                l.push(this.parseParenItem(this.parseRestBinding())),
                this.type === o.comma &&
                  this.raiseRecoverable(
                    this.start,
                    "Comma is not permitted after the rest element"
                  );
              break;
            } else l.push(this.parseMaybeAssign(!1, p, this.parseParenItem));
          var K = this.lastTokEnd,
            de = this.lastTokEndLoc;
          if (
            (this.expect(o.parenR),
            e && this.shouldParseArrow(l) && this.eat(o.arrow))
          )
            return (
              this.checkPatternErrors(p, !1),
              this.checkYieldAwaitInDefaultParams(),
              (this.yieldPos = S),
              (this.awaitPos = C),
              this.parseParenArrowList(r, i, l, t)
            );
          (!l.length || h) && this.unexpected(this.lastTokStart),
            L && this.unexpected(L),
            this.checkExpressionErrors(p, !0),
            (this.yieldPos = S || this.yieldPos),
            (this.awaitPos = C || this.awaitPos),
            l.length > 1
              ? ((a = this.startNodeAt(n, u)),
                (a.expressions = l),
                this.finishNodeAt(a, "SequenceExpression", K, de))
              : (a = l[0]);
        } else a = this.parseParenExpression();
        if (this.options.preserveParens) {
          var Le = this.startNodeAt(r, i);
          return (
            (Le.expression = a), this.finishNode(Le, "ParenthesizedExpression")
          );
        } else return a;
      }),
      (x.parseParenItem = function (e) {
        return e;
      }),
      (x.parseParenArrowList = function (e, t, r, i) {
        return this.parseArrowExpression(this.startNodeAt(e, t), r, !1, i);
      });
    var $r = [];
    (x.parseNew = function () {
      this.containsEsc &&
        this.raiseRecoverable(this.start, "Escape sequence in keyword new");
      var e = this.startNode();
      if ((this.next(), this.options.ecmaVersion >= 6 && this.type === o.dot)) {
        var t = this.startNodeAt(e.start, e.loc && e.loc.start);
        (t.name = "new"),
          (e.meta = this.finishNode(t, "Identifier")),
          this.next();
        var r = this.containsEsc;
        return (
          (e.property = this.parseIdent(!0)),
          e.property.name !== "target" &&
            this.raiseRecoverable(
              e.property.start,
              "The only valid meta property for new is 'new.target'"
            ),
          r &&
            this.raiseRecoverable(
              e.start,
              "'new.target' must not contain escaped characters"
            ),
          this.allowNewDotTarget ||
            this.raiseRecoverable(
              e.start,
              "'new.target' can only be used in functions and class static block"
            ),
          this.finishNode(e, "MetaProperty")
        );
      }
      var i = this.start,
        a = this.startLoc;
      return (
        (e.callee = this.parseSubscripts(
          this.parseExprAtom(null, !1, !0),
          i,
          a,
          !0,
          !1
        )),
        this.eat(o.parenL)
          ? (e.arguments = this.parseExprList(
              o.parenR,
              this.options.ecmaVersion >= 8,
              !1
            ))
          : (e.arguments = $r),
        this.finishNode(e, "NewExpression")
      );
    }),
      (x.parseTemplateElement = function (e) {
        var t = e.isTagged,
          r = this.startNode();
        return (
          this.type === o.invalidTemplate
            ? (t ||
                this.raiseRecoverable(
                  this.start,
                  "Bad escape sequence in untagged template literal"
                ),
              (r.value = {
                raw: this.value.replace(/\r\n?/g, "\n"),
                cooked: null,
              }))
            : (r.value = {
                raw: this.input
                  .slice(this.start, this.end)
                  .replace(/\r\n?/g, "\n"),
                cooked: this.value,
              }),
          this.next(),
          (r.tail = this.type === o.backQuote),
          this.finishNode(r, "TemplateElement")
        );
      }),
      (x.parseTemplate = function (e) {
        e === void 0 && (e = {});
        var t = e.isTagged;
        t === void 0 && (t = !1);
        var r = this.startNode();
        this.next(), (r.expressions = []);
        var i = this.parseTemplateElement({ isTagged: t });
        for (r.quasis = [i]; !i.tail; )
          this.type === o.eof &&
            this.raise(this.pos, "Unterminated template literal"),
            this.expect(o.dollarBraceL),
            r.expressions.push(this.parseExpression()),
            this.expect(o.braceR),
            r.quasis.push((i = this.parseTemplateElement({ isTagged: t })));
        return this.next(), this.finishNode(r, "TemplateLiteral");
      }),
      (x.isAsyncProp = function (e) {
        return (
          !e.computed &&
          e.key.type === "Identifier" &&
          e.key.name === "async" &&
          (this.type === o.name ||
            this.type === o.num ||
            this.type === o.string ||
            this.type === o.bracketL ||
            this.type.keyword ||
            (this.options.ecmaVersion >= 9 && this.type === o.star)) &&
          !W.test(this.input.slice(this.lastTokEnd, this.start))
        );
      }),
      (x.parseObj = function (e, t) {
        var r = this.startNode(),
          i = !0,
          a = {};
        for (r.properties = [], this.next(); !this.eat(o.braceR); ) {
          if (i) i = !1;
          else if (
            (this.expect(o.comma),
            this.options.ecmaVersion >= 5 && this.afterTrailingComma(o.braceR))
          )
            break;
          var s = this.parseProperty(e, t);
          e || this.checkPropClash(s, a, t), r.properties.push(s);
        }
        return this.finishNode(r, e ? "ObjectPattern" : "ObjectExpression");
      }),
      (x.parseProperty = function (e, t) {
        var r = this.startNode(),
          i,
          a,
          s,
          n;
        if (this.options.ecmaVersion >= 9 && this.eat(o.ellipsis))
          return e
            ? ((r.argument = this.parseIdent(!1)),
              this.type === o.comma &&
                this.raiseRecoverable(
                  this.start,
                  "Comma is not permitted after the rest element"
                ),
              this.finishNode(r, "RestElement"))
            : ((r.argument = this.parseMaybeAssign(!1, t)),
              this.type === o.comma &&
                t &&
                t.trailingComma < 0 &&
                (t.trailingComma = this.start),
              this.finishNode(r, "SpreadElement"));
        this.options.ecmaVersion >= 6 &&
          ((r.method = !1),
          (r.shorthand = !1),
          (e || t) && ((s = this.start), (n = this.startLoc)),
          e || (i = this.eat(o.star)));
        var u = this.containsEsc;
        return (
          this.parsePropertyName(r),
          !e && !u && this.options.ecmaVersion >= 8 && !i && this.isAsyncProp(r)
            ? ((a = !0),
              (i = this.options.ecmaVersion >= 9 && this.eat(o.star)),
              this.parsePropertyName(r))
            : (a = !1),
          this.parsePropertyValue(r, e, i, a, s, n, t, u),
          this.finishNode(r, "Property")
        );
      }),
      (x.parseGetterSetter = function (e) {
        var t = e.key.name;
        this.parsePropertyName(e),
          (e.value = this.parseMethod(!1)),
          (e.kind = t);
        var r = e.kind === "get" ? 0 : 1;
        if (e.value.params.length !== r) {
          var i = e.value.start;
          e.kind === "get"
            ? this.raiseRecoverable(i, "getter should have no params")
            : this.raiseRecoverable(i, "setter should have exactly one param");
        } else
          e.kind === "set" &&
            e.value.params[0].type === "RestElement" &&
            this.raiseRecoverable(
              e.value.params[0].start,
              "Setter cannot use rest params"
            );
      }),
      (x.parsePropertyValue = function (e, t, r, i, a, s, n, u) {
        (r || i) && this.type === o.colon && this.unexpected(),
          this.eat(o.colon)
            ? ((e.value = t
                ? this.parseMaybeDefault(this.start, this.startLoc)
                : this.parseMaybeAssign(!1, n)),
              (e.kind = "init"))
            : this.options.ecmaVersion >= 6 && this.type === o.parenL
            ? (t && this.unexpected(),
              (e.method = !0),
              (e.value = this.parseMethod(r, i)),
              (e.kind = "init"))
            : !t &&
              !u &&
              this.options.ecmaVersion >= 5 &&
              !e.computed &&
              e.key.type === "Identifier" &&
              (e.key.name === "get" || e.key.name === "set") &&
              this.type !== o.comma &&
              this.type !== o.braceR &&
              this.type !== o.eq
            ? ((r || i) && this.unexpected(), this.parseGetterSetter(e))
            : this.options.ecmaVersion >= 6 &&
              !e.computed &&
              e.key.type === "Identifier"
            ? ((r || i) && this.unexpected(),
              this.checkUnreserved(e.key),
              e.key.name === "await" &&
                !this.awaitIdentPos &&
                (this.awaitIdentPos = a),
              t
                ? (e.value = this.parseMaybeDefault(a, s, this.copyNode(e.key)))
                : this.type === o.eq && n
                ? (n.shorthandAssign < 0 && (n.shorthandAssign = this.start),
                  (e.value = this.parseMaybeDefault(
                    a,
                    s,
                    this.copyNode(e.key)
                  )))
                : (e.value = this.copyNode(e.key)),
              (e.kind = "init"),
              (e.shorthand = !0))
            : this.unexpected();
      }),
      (x.parsePropertyName = function (e) {
        if (this.options.ecmaVersion >= 6) {
          if (this.eat(o.bracketL))
            return (
              (e.computed = !0),
              (e.key = this.parseMaybeAssign()),
              this.expect(o.bracketR),
              e.key
            );
          e.computed = !1;
        }
        return (e.key =
          this.type === o.num || this.type === o.string
            ? this.parseExprAtom()
            : this.parseIdent(this.options.allowReserved !== "never"));
      }),
      (x.initFunction = function (e) {
        (e.id = null),
          this.options.ecmaVersion >= 6 && (e.generator = e.expression = !1),
          this.options.ecmaVersion >= 8 && (e.async = !1);
      }),
      (x.parseMethod = function (e, t, r) {
        var i = this.startNode(),
          a = this.yieldPos,
          s = this.awaitPos,
          n = this.awaitIdentPos;
        return (
          this.initFunction(i),
          this.options.ecmaVersion >= 6 && (i.generator = e),
          this.options.ecmaVersion >= 8 && (i.async = !!t),
          (this.yieldPos = 0),
          (this.awaitPos = 0),
          (this.awaitIdentPos = 0),
          this.enterScope(xt(t, i.generator) | Xe | (r ? ei : 0)),
          this.expect(o.parenL),
          (i.params = this.parseBindingList(
            o.parenR,
            !1,
            this.options.ecmaVersion >= 8
          )),
          this.checkYieldAwaitInDefaultParams(),
          this.parseFunctionBody(i, !1, !0, !1),
          (this.yieldPos = a),
          (this.awaitPos = s),
          (this.awaitIdentPos = n),
          this.finishNode(i, "FunctionExpression")
        );
      }),
      (x.parseArrowExpression = function (e, t, r, i) {
        var a = this.yieldPos,
          s = this.awaitPos,
          n = this.awaitIdentPos;
        return (
          this.enterScope(xt(r, !1) | gt),
          this.initFunction(e),
          this.options.ecmaVersion >= 8 && (e.async = !!r),
          (this.yieldPos = 0),
          (this.awaitPos = 0),
          (this.awaitIdentPos = 0),
          (e.params = this.toAssignableList(t, !0)),
          this.parseFunctionBody(e, !0, !1, i),
          (this.yieldPos = a),
          (this.awaitPos = s),
          (this.awaitIdentPos = n),
          this.finishNode(e, "ArrowFunctionExpression")
        );
      }),
      (x.parseFunctionBody = function (e, t, r, i) {
        var a = t && this.type !== o.braceL,
          s = this.strict,
          n = !1;
        if (a)
          (e.body = this.parseMaybeAssign(i)),
            (e.expression = !0),
            this.checkParams(e, !1);
        else {
          var u =
            this.options.ecmaVersion >= 7 && !this.isSimpleParamList(e.params);
          (!s || u) &&
            ((n = this.strictDirective(this.end)),
            n &&
              u &&
              this.raiseRecoverable(
                e.start,
                "Illegal 'use strict' directive in function with non-simple parameter list"
              ));
          var l = this.labels;
          (this.labels = []),
            n && (this.strict = !0),
            this.checkParams(
              e,
              !s && !n && !t && !r && this.isSimpleParamList(e.params)
            ),
            this.strict && e.id && this.checkLValSimple(e.id, ri),
            (e.body = this.parseBlock(!1, void 0, n && !s)),
            (e.expression = !1),
            this.adaptDirectivePrologue(e.body.body),
            (this.labels = l);
        }
        this.exitScope();
      }),
      (x.isSimpleParamList = function (e) {
        for (var t = 0, r = e; t < r.length; t += 1) {
          var i = r[t];
          if (i.type !== "Identifier") return !1;
        }
        return !0;
      }),
      (x.checkParams = function (e, t) {
        for (
          var r = Object.create(null), i = 0, a = e.params;
          i < a.length;
          i += 1
        ) {
          var s = a[i];
          this.checkLValInnerPattern(s, bt, t ? null : r);
        }
      }),
      (x.parseExprList = function (e, t, r, i) {
        for (var a = [], s = !0; !this.eat(e); ) {
          if (s) s = !1;
          else if ((this.expect(o.comma), t && this.afterTrailingComma(e)))
            break;
          var n = void 0;
          r && this.type === o.comma
            ? (n = null)
            : this.type === o.ellipsis
            ? ((n = this.parseSpread(i)),
              i &&
                this.type === o.comma &&
                i.trailingComma < 0 &&
                (i.trailingComma = this.start))
            : (n = this.parseMaybeAssign(!1, i)),
            a.push(n);
        }
        return a;
      }),
      (x.checkUnreserved = function (e) {
        var t = e.start,
          r = e.end,
          i = e.name;
        if (
          (this.inGenerator &&
            i === "yield" &&
            this.raiseRecoverable(
              t,
              "Cannot use 'yield' as identifier inside a generator"
            ),
          this.inAsync &&
            i === "await" &&
            this.raiseRecoverable(
              t,
              "Cannot use 'await' as identifier inside an async function"
            ),
          !(this.currentThisScope().flags & Ye) &&
            i === "arguments" &&
            this.raiseRecoverable(
              t,
              "Cannot use 'arguments' in class field initializer"
            ),
          this.inClassStaticBlock &&
            (i === "arguments" || i === "await") &&
            this.raise(
              t,
              "Cannot use " + i + " in class static initialization block"
            ),
          this.keywords.test(i) &&
            this.raise(t, "Unexpected keyword '" + i + "'"),
          !(
            this.options.ecmaVersion < 6 &&
            this.input.slice(t, r).indexOf("\\") !== -1
          ))
        ) {
          var a = this.strict ? this.reservedWordsStrict : this.reservedWords;
          a.test(i) &&
            (!this.inAsync &&
              i === "await" &&
              this.raiseRecoverable(
                t,
                "Cannot use keyword 'await' outside an async function"
              ),
            this.raiseRecoverable(t, "The keyword '" + i + "' is reserved"));
        }
      }),
      (x.parseIdent = function (e) {
        var t = this.parseIdentNode();
        return (
          this.next(!!e),
          this.finishNode(t, "Identifier"),
          e ||
            (this.checkUnreserved(t),
            t.name === "await" &&
              !this.awaitIdentPos &&
              (this.awaitIdentPos = t.start)),
          t
        );
      }),
      (x.parseIdentNode = function () {
        var e = this.startNode();
        return (
          this.type === o.name
            ? (e.name = this.value)
            : this.type.keyword
            ? ((e.name = this.type.keyword),
              (e.name === "class" || e.name === "function") &&
                (this.lastTokEnd !== this.lastTokStart + 1 ||
                  this.input.charCodeAt(this.lastTokStart) !== 46) &&
                this.context.pop(),
              (this.type = o.name))
            : this.unexpected(),
          e
        );
      }),
      (x.parsePrivateIdent = function () {
        var e = this.startNode();
        return (
          this.type === o.privateId ? (e.name = this.value) : this.unexpected(),
          this.next(),
          this.finishNode(e, "PrivateIdentifier"),
          this.options.checkPrivateFields &&
            (this.privateNameStack.length === 0
              ? this.raise(
                  e.start,
                  "Private field '#" +
                    e.name +
                    "' must be declared in an enclosing class"
                )
              : this.privateNameStack[
                  this.privateNameStack.length - 1
                ].used.push(e)),
          e
        );
      }),
      (x.parseYield = function (e) {
        this.yieldPos || (this.yieldPos = this.start);
        var t = this.startNode();
        return (
          this.next(),
          this.type === o.semi ||
          this.canInsertSemicolon() ||
          (this.type !== o.star && !this.type.startsExpr)
            ? ((t.delegate = !1), (t.argument = null))
            : ((t.delegate = this.eat(o.star)),
              (t.argument = this.parseMaybeAssign(e))),
          this.finishNode(t, "YieldExpression")
        );
      }),
      (x.parseAwait = function (e) {
        this.awaitPos || (this.awaitPos = this.start);
        var t = this.startNode();
        return (
          this.next(),
          (t.argument = this.parseMaybeUnary(null, !0, !1, e)),
          this.finishNode(t, "AwaitExpression")
        );
      });
    var tt = V.prototype;
    (tt.raise = function (e, t) {
      var r = Xt(this.input, e);
      (t += " (" + r.line + ":" + r.column + ")"),
        this.sourceFile && (t += " in " + this.sourceFile);
      var i = new SyntaxError(t);
      throw ((i.pos = e), (i.loc = r), (i.raisedAt = this.pos), i);
    }),
      (tt.raiseRecoverable = tt.raise),
      (tt.curPosition = function () {
        if (this.options.locations)
          return new Re(this.curLine, this.pos - this.lineStart);
      });
    var ce = V.prototype,
      qr = function qr(t) {
        (this.flags = t),
          (this.var = []),
          (this.lexical = []),
          (this.functions = []);
      };
    (ce.enterScope = function (e) {
      this.scopeStack.push(new qr(e));
    }),
      (ce.exitScope = function () {
        this.scopeStack.pop();
      }),
      (ce.treatFunctionsAsVarInScope = function (e) {
        return e.flags & Ee || (!this.inModule && e.flags & Be);
      }),
      (ce.declareName = function (e, t, r) {
        var i = !1;
        if (t === ie) {
          var a = this.currentScope();
          (i =
            a.lexical.indexOf(e) > -1 ||
            a.functions.indexOf(e) > -1 ||
            a.var.indexOf(e) > -1),
            a.lexical.push(e),
            this.inModule && a.flags & Be && delete this.undefinedExports[e];
        } else if (t === ii) {
          var s = this.currentScope();
          s.lexical.push(e);
        } else if (t === ti) {
          var n = this.currentScope();
          this.treatFunctionsAsVar
            ? (i = n.lexical.indexOf(e) > -1)
            : (i = n.lexical.indexOf(e) > -1 || n.var.indexOf(e) > -1),
            n.functions.push(e);
        } else
          for (var u = this.scopeStack.length - 1; u >= 0; --u) {
            var l = this.scopeStack[u];
            if (
              (l.lexical.indexOf(e) > -1 &&
                !(l.flags & Jt && l.lexical[0] === e)) ||
              (!this.treatFunctionsAsVarInScope(l) &&
                l.functions.indexOf(e) > -1)
            ) {
              i = !0;
              break;
            }
            if (
              (l.var.push(e),
              this.inModule && l.flags & Be && delete this.undefinedExports[e],
              l.flags & Ye)
            )
              break;
          }
        i &&
          this.raiseRecoverable(
            r,
            "Identifier '" + e + "' has already been declared"
          );
      }),
      (ce.checkLocalExport = function (e) {
        this.scopeStack[0].lexical.indexOf(e.name) === -1 &&
          this.scopeStack[0].var.indexOf(e.name) === -1 &&
          (this.undefinedExports[e.name] = e);
      }),
      (ce.currentScope = function () {
        return this.scopeStack[this.scopeStack.length - 1];
      }),
      (ce.currentVarScope = function () {
        for (var e = this.scopeStack.length - 1; ; e--) {
          var t = this.scopeStack[e];
          if (t.flags & (Ye | Oe | ye)) return t;
        }
      }),
      (ce.currentThisScope = function () {
        for (var e = this.scopeStack.length - 1; ; e--) {
          var t = this.scopeStack[e];
          if (t.flags & (Ye | Oe | ye) && !(t.flags & gt)) return t;
        }
      });
    var it = function it(t, r, i) {
        (this.type = ""),
          (this.start = r),
          (this.end = 0),
          t.options.locations && (this.loc = new Qe(t, i)),
          t.options.directSourceFile &&
            (this.sourceFile = t.options.directSourceFile),
          t.options.ranges && (this.range = [r, 0]);
      },
      Fe = V.prototype;
    (Fe.startNode = function () {
      return new it(this, this.start, this.startLoc);
    }),
      (Fe.startNodeAt = function (e, t) {
        return new it(this, e, t);
      });
    function ni(e, t, r, i) {
      return (
        (e.type = t),
        (e.end = r),
        this.options.locations && (e.loc.end = i),
        this.options.ranges && (e.range[1] = r),
        e
      );
    }
    (Fe.finishNode = function (e, t) {
      return ni.call(this, e, t, this.lastTokEnd, this.lastTokEndLoc);
    }),
      (Fe.finishNodeAt = function (e, t, r, i) {
        return ni.call(this, e, t, r, i);
      }),
      (Fe.copyNode = function (e) {
        var t = new it(this, e.start, this.startLoc);
        for (var r in e) t[r] = e[r];
        return t;
      });
    var Wr =
        "Gara Garay Gukh Gurung_Khema Hrkt Katakana_Or_Hiragana Kawi Kirat_Rai Krai Nag_Mundari Nagm Ol_Onal Onao Sunu Sunuwar Todhri Todr Tulu_Tigalari Tutg Unknown Zzzz",
      oi =
        "ASCII ASCII_Hex_Digit AHex Alphabetic Alpha Any Assigned Bidi_Control Bidi_C Bidi_Mirrored Bidi_M Case_Ignorable CI Cased Changes_When_Casefolded CWCF Changes_When_Casemapped CWCM Changes_When_Lowercased CWL Changes_When_NFKC_Casefolded CWKCF Changes_When_Titlecased CWT Changes_When_Uppercased CWU Dash Default_Ignorable_Code_Point DI Deprecated Dep Diacritic Dia Emoji Emoji_Component Emoji_Modifier Emoji_Modifier_Base Emoji_Presentation Extender Ext Grapheme_Base Gr_Base Grapheme_Extend Gr_Ext Hex_Digit Hex IDS_Binary_Operator IDSB IDS_Trinary_Operator IDST ID_Continue IDC ID_Start IDS Ideographic Ideo Join_Control Join_C Logical_Order_Exception LOE Lowercase Lower Math Noncharacter_Code_Point NChar Pattern_Syntax Pat_Syn Pattern_White_Space Pat_WS Quotation_Mark QMark Radical Regional_Indicator RI Sentence_Terminal STerm Soft_Dotted SD Terminal_Punctuation Term Unified_Ideograph UIdeo Uppercase Upper Variation_Selector VS White_Space space XID_Continue XIDC XID_Start XIDS",
      ui = oi + " Extended_Pictographic",
      li = ui,
      ci = li + " EBase EComp EMod EPres ExtPict",
      hi = ci,
      zr = hi,
      Gr = { 9: oi, 10: ui, 11: li, 12: ci, 13: hi, 14: zr },
      Hr =
        "Basic_Emoji Emoji_Keycap_Sequence RGI_Emoji_Modifier_Sequence RGI_Emoji_Flag_Sequence RGI_Emoji_Tag_Sequence RGI_Emoji_ZWJ_Sequence RGI_Emoji",
      Kr = { 9: "", 10: "", 11: "", 12: "", 13: "", 14: Hr },
      fi =
        "Cased_Letter LC Close_Punctuation Pe Connector_Punctuation Pc Control Cc cntrl Currency_Symbol Sc Dash_Punctuation Pd Decimal_Number Nd digit Enclosing_Mark Me Final_Punctuation Pf Format Cf Initial_Punctuation Pi Letter L Letter_Number Nl Line_Separator Zl Lowercase_Letter Ll Mark M Combining_Mark Math_Symbol Sm Modifier_Letter Lm Modifier_Symbol Sk Nonspacing_Mark Mn Number N Open_Punctuation Ps Other C Other_Letter Lo Other_Number No Other_Punctuation Po Other_Symbol So Paragraph_Separator Zp Private_Use Co Punctuation P punct Separator Z Space_Separator Zs Spacing_Mark Mc Surrogate Cs Symbol S Titlecase_Letter Lt Unassigned Cn Uppercase_Letter Lu",
      pi =
        "Adlam Adlm Ahom Anatolian_Hieroglyphs Hluw Arabic Arab Armenian Armn Avestan Avst Balinese Bali Bamum Bamu Bassa_Vah Bass Batak Batk Bengali Beng Bhaiksuki Bhks Bopomofo Bopo Brahmi Brah Braille Brai Buginese Bugi Buhid Buhd Canadian_Aboriginal Cans Carian Cari Caucasian_Albanian Aghb Chakma Cakm Cham Cham Cherokee Cher Common Zyyy Coptic Copt Qaac Cuneiform Xsux Cypriot Cprt Cyrillic Cyrl Deseret Dsrt Devanagari Deva Duployan Dupl Egyptian_Hieroglyphs Egyp Elbasan Elba Ethiopic Ethi Georgian Geor Glagolitic Glag Gothic Goth Grantha Gran Greek Grek Gujarati Gujr Gurmukhi Guru Han Hani Hangul Hang Hanunoo Hano Hatran Hatr Hebrew Hebr Hiragana Hira Imperial_Aramaic Armi Inherited Zinh Qaai Inscriptional_Pahlavi Phli Inscriptional_Parthian Prti Javanese Java Kaithi Kthi Kannada Knda Katakana Kana Kayah_Li Kali Kharoshthi Khar Khmer Khmr Khojki Khoj Khudawadi Sind Lao Laoo Latin Latn Lepcha Lepc Limbu Limb Linear_A Lina Linear_B Linb Lisu Lisu Lycian Lyci Lydian Lydi Mahajani Mahj Malayalam Mlym Mandaic Mand Manichaean Mani Marchen Marc Masaram_Gondi Gonm Meetei_Mayek Mtei Mende_Kikakui Mend Meroitic_Cursive Merc Meroitic_Hieroglyphs Mero Miao Plrd Modi Mongolian Mong Mro Mroo Multani Mult Myanmar Mymr Nabataean Nbat New_Tai_Lue Talu Newa Newa Nko Nkoo Nushu Nshu Ogham Ogam Ol_Chiki Olck Old_Hungarian Hung Old_Italic Ital Old_North_Arabian Narb Old_Permic Perm Old_Persian Xpeo Old_South_Arabian Sarb Old_Turkic Orkh Oriya Orya Osage Osge Osmanya Osma Pahawh_Hmong Hmng Palmyrene Palm Pau_Cin_Hau Pauc Phags_Pa Phag Phoenician Phnx Psalter_Pahlavi Phlp Rejang Rjng Runic Runr Samaritan Samr Saurashtra Saur Sharada Shrd Shavian Shaw Siddham Sidd SignWriting Sgnw Sinhala Sinh Sora_Sompeng Sora Soyombo Soyo Sundanese Sund Syloti_Nagri Sylo Syriac Syrc Tagalog Tglg Tagbanwa Tagb Tai_Le Tale Tai_Tham Lana Tai_Viet Tavt Takri Takr Tamil Taml Tangut Tang Telugu Telu Thaana Thaa Thai Thai Tibetan Tibt Tifinagh Tfng Tirhuta Tirh Ugaritic Ugar Vai Vaii Warang_Citi Wara Yi Yiii Zanabazar_Square Zanb",
      di =
        pi +
        " Dogra Dogr Gunjala_Gondi Gong Hanifi_Rohingya Rohg Makasar Maka Medefaidrin Medf Old_Sogdian Sogo Sogdian Sogd",
      yi =
        di +
        " Elymaic Elym Nandinagari Nand Nyiakeng_Puachue_Hmong Hmnp Wancho Wcho",
      mi =
        yi +
        " Chorasmian Chrs Diak Dives_Akuru Khitan_Small_Script Kits Yezi Yezidi",
      gi =
        mi +
        " Cypro_Minoan Cpmn Old_Uyghur Ougr Tangsa Tnsa Toto Vithkuqi Vith",
      Qr = gi + " " + Wr,
      Xr = { 9: pi, 10: di, 11: yi, 12: mi, 13: gi, 14: Qr },
      xi = {};
    function Yr(e) {
      var t = (xi[e] = {
        binary: le(Gr[e] + " " + fi),
        binaryOfStrings: le(Kr[e]),
        nonBinary: { General_Category: le(fi), Script: le(Xr[e]) },
      });
      (t.nonBinary.Script_Extensions = t.nonBinary.Script),
        (t.nonBinary.gc = t.nonBinary.General_Category),
        (t.nonBinary.sc = t.nonBinary.Script),
        (t.nonBinary.scx = t.nonBinary.Script_Extensions);
    }
    for (var kt = 0, bi = [9, 10, 11, 12, 13, 14]; kt < bi.length; kt += 1) {
      var Zr = bi[kt];
      Yr(Zr);
    }
    var m = V.prototype,
      rt = function rt(t, r) {
        (this.parent = t), (this.base = r || this);
      };
    (rt.prototype.separatedFrom = function (t) {
      for (var r = this; r; r = r.parent)
        for (var i = t; i; i = i.parent)
          if (r.base === i.base && r !== i) return !0;
      return !1;
    }),
      (rt.prototype.sibling = function () {
        return new rt(this.parent, this.base);
      });
    var Y = function Y(t) {
      (this.parser = t),
        (this.validFlags =
          "gim" +
          (t.options.ecmaVersion >= 6 ? "uy" : "") +
          (t.options.ecmaVersion >= 9 ? "s" : "") +
          (t.options.ecmaVersion >= 13 ? "d" : "") +
          (t.options.ecmaVersion >= 15 ? "v" : "")),
        (this.unicodeProperties =
          xi[t.options.ecmaVersion >= 14 ? 14 : t.options.ecmaVersion]),
        (this.source = ""),
        (this.flags = ""),
        (this.start = 0),
        (this.switchU = !1),
        (this.switchV = !1),
        (this.switchN = !1),
        (this.pos = 0),
        (this.lastIntValue = 0),
        (this.lastStringValue = ""),
        (this.lastAssertionIsQuantifiable = !1),
        (this.numCapturingParens = 0),
        (this.maxBackReference = 0),
        (this.groupNames = Object.create(null)),
        (this.backReferenceNames = []),
        (this.branchID = null);
    };
    (Y.prototype.reset = function (t, r, i) {
      var a = i.indexOf("v") !== -1,
        s = i.indexOf("u") !== -1;
      (this.start = t | 0),
        (this.source = r + ""),
        (this.flags = i),
        a && this.parser.options.ecmaVersion >= 15
          ? ((this.switchU = !0), (this.switchV = !0), (this.switchN = !0))
          : ((this.switchU = s && this.parser.options.ecmaVersion >= 6),
            (this.switchV = !1),
            (this.switchN = s && this.parser.options.ecmaVersion >= 9));
    }),
      (Y.prototype.raise = function (t) {
        this.parser.raiseRecoverable(
          this.start,
          "Invalid regular expression: /" + this.source + "/: " + t
        );
      }),
      (Y.prototype.at = function (t, r) {
        r === void 0 && (r = !1);
        var i = this.source,
          a = i.length;
        if (t >= a) return -1;
        var s = i.charCodeAt(t);
        if (!(r || this.switchU) || s <= 55295 || s >= 57344 || t + 1 >= a)
          return s;
        var n = i.charCodeAt(t + 1);
        return n >= 56320 && n <= 57343 ? (s << 10) + n - 0x35fdc00 : s;
      }),
      (Y.prototype.nextIndex = function (t, r) {
        r === void 0 && (r = !1);
        var i = this.source,
          a = i.length;
        if (t >= a) return a;
        var s = i.charCodeAt(t),
          n;
        return !(r || this.switchU) ||
          s <= 55295 ||
          s >= 57344 ||
          t + 1 >= a ||
          (n = i.charCodeAt(t + 1)) < 56320 ||
          n > 57343
          ? t + 1
          : t + 2;
      }),
      (Y.prototype.current = function (t) {
        return t === void 0 && (t = !1), this.at(this.pos, t);
      }),
      (Y.prototype.lookahead = function (t) {
        return (
          t === void 0 && (t = !1), this.at(this.nextIndex(this.pos, t), t)
        );
      }),
      (Y.prototype.advance = function (t) {
        t === void 0 && (t = !1), (this.pos = this.nextIndex(this.pos, t));
      }),
      (Y.prototype.eat = function (t, r) {
        return (
          r === void 0 && (r = !1),
          this.current(r) === t ? (this.advance(r), !0) : !1
        );
      }),
      (Y.prototype.eatChars = function (t, r) {
        r === void 0 && (r = !1);
        for (var i = this.pos, a = 0, s = t; a < s.length; a += 1) {
          var n = s[a],
            u = this.at(i, r);
          if (u === -1 || u !== n) return !1;
          i = this.nextIndex(i, r);
        }
        return (this.pos = i), !0;
      }),
      (m.validateRegExpFlags = function (e) {
        for (
          var t = e.validFlags, r = e.flags, i = !1, a = !1, s = 0;
          s < r.length;
          s++
        ) {
          var n = r.charAt(s);
          t.indexOf(n) === -1 &&
            this.raise(e.start, "Invalid regular expression flag"),
            r.indexOf(n, s + 1) > -1 &&
              this.raise(e.start, "Duplicate regular expression flag"),
            n === "u" && (i = !0),
            n === "v" && (a = !0);
        }
        this.options.ecmaVersion >= 15 &&
          i &&
          a &&
          this.raise(e.start, "Invalid regular expression flag");
      });
    function Jr(e) {
      for (var t in e) return !0;
      return !1;
    }
    (m.validateRegExpPattern = function (e) {
      this.regexp_pattern(e),
        !e.switchN &&
          this.options.ecmaVersion >= 9 &&
          Jr(e.groupNames) &&
          ((e.switchN = !0), this.regexp_pattern(e));
    }),
      (m.regexp_pattern = function (e) {
        (e.pos = 0),
          (e.lastIntValue = 0),
          (e.lastStringValue = ""),
          (e.lastAssertionIsQuantifiable = !1),
          (e.numCapturingParens = 0),
          (e.maxBackReference = 0),
          (e.groupNames = Object.create(null)),
          (e.backReferenceNames.length = 0),
          (e.branchID = null),
          this.regexp_disjunction(e),
          e.pos !== e.source.length &&
            (e.eat(41) && e.raise("Unmatched ')'"),
            (e.eat(93) || e.eat(125)) && e.raise("Lone quantifier brackets")),
          e.maxBackReference > e.numCapturingParens &&
            e.raise("Invalid escape");
        for (var t = 0, r = e.backReferenceNames; t < r.length; t += 1) {
          var i = r[t];
          e.groupNames[i] || e.raise("Invalid named capture referenced");
        }
      }),
      (m.regexp_disjunction = function (e) {
        var t = this.options.ecmaVersion >= 16;
        for (
          t && (e.branchID = new rt(e.branchID, null)),
            this.regexp_alternative(e);
          e.eat(124);

        )
          t && (e.branchID = e.branchID.sibling()), this.regexp_alternative(e);
        t && (e.branchID = e.branchID.parent),
          this.regexp_eatQuantifier(e, !0) && e.raise("Nothing to repeat"),
          e.eat(123) && e.raise("Lone quantifier brackets");
      }),
      (m.regexp_alternative = function (e) {
        for (; e.pos < e.source.length && this.regexp_eatTerm(e); );
      }),
      (m.regexp_eatTerm = function (e) {
        return this.regexp_eatAssertion(e)
          ? (e.lastAssertionIsQuantifiable &&
              this.regexp_eatQuantifier(e) &&
              e.switchU &&
              e.raise("Invalid quantifier"),
            !0)
          : (
              e.switchU
                ? this.regexp_eatAtom(e)
                : this.regexp_eatExtendedAtom(e)
            )
          ? (this.regexp_eatQuantifier(e), !0)
          : !1;
      }),
      (m.regexp_eatAssertion = function (e) {
        var t = e.pos;
        if (((e.lastAssertionIsQuantifiable = !1), e.eat(94) || e.eat(36)))
          return !0;
        if (e.eat(92)) {
          if (e.eat(66) || e.eat(98)) return !0;
          e.pos = t;
        }
        if (e.eat(40) && e.eat(63)) {
          var r = !1;
          if (
            (this.options.ecmaVersion >= 9 && (r = e.eat(60)),
            e.eat(61) || e.eat(33))
          )
            return (
              this.regexp_disjunction(e),
              e.eat(41) || e.raise("Unterminated group"),
              (e.lastAssertionIsQuantifiable = !r),
              !0
            );
        }
        return (e.pos = t), !1;
      }),
      (m.regexp_eatQuantifier = function (e, t) {
        return (
          t === void 0 && (t = !1),
          this.regexp_eatQuantifierPrefix(e, t) ? (e.eat(63), !0) : !1
        );
      }),
      (m.regexp_eatQuantifierPrefix = function (e, t) {
        return (
          e.eat(42) ||
          e.eat(43) ||
          e.eat(63) ||
          this.regexp_eatBracedQuantifier(e, t)
        );
      }),
      (m.regexp_eatBracedQuantifier = function (e, t) {
        var r = e.pos;
        if (e.eat(123)) {
          var i = 0,
            a = -1;
          if (
            this.regexp_eatDecimalDigits(e) &&
            ((i = e.lastIntValue),
            e.eat(44) &&
              this.regexp_eatDecimalDigits(e) &&
              (a = e.lastIntValue),
            e.eat(125))
          )
            return (
              a !== -1 &&
                a < i &&
                !t &&
                e.raise("numbers out of order in {} quantifier"),
              !0
            );
          e.switchU && !t && e.raise("Incomplete quantifier"), (e.pos = r);
        }
        return !1;
      }),
      (m.regexp_eatAtom = function (e) {
        return (
          this.regexp_eatPatternCharacters(e) ||
          e.eat(46) ||
          this.regexp_eatReverseSolidusAtomEscape(e) ||
          this.regexp_eatCharacterClass(e) ||
          this.regexp_eatUncapturingGroup(e) ||
          this.regexp_eatCapturingGroup(e)
        );
      }),
      (m.regexp_eatReverseSolidusAtomEscape = function (e) {
        var t = e.pos;
        if (e.eat(92)) {
          if (this.regexp_eatAtomEscape(e)) return !0;
          e.pos = t;
        }
        return !1;
      }),
      (m.regexp_eatUncapturingGroup = function (e) {
        var t = e.pos;
        if (e.eat(40)) {
          if (e.eat(63)) {
            if (this.options.ecmaVersion >= 16) {
              var r = this.regexp_eatModifiers(e),
                i = e.eat(45);
              if (r || i) {
                for (var a = 0; a < r.length; a++) {
                  var s = r.charAt(a);
                  r.indexOf(s, a + 1) > -1 &&
                    e.raise("Duplicate regular expression modifiers");
                }
                if (i) {
                  var n = this.regexp_eatModifiers(e);
                  !r &&
                    !n &&
                    e.current() === 58 &&
                    e.raise("Invalid regular expression modifiers");
                  for (var u = 0; u < n.length; u++) {
                    var l = n.charAt(u);
                    (n.indexOf(l, u + 1) > -1 || r.indexOf(l) > -1) &&
                      e.raise("Duplicate regular expression modifiers");
                  }
                }
              }
            }
            if (e.eat(58)) {
              if ((this.regexp_disjunction(e), e.eat(41))) return !0;
              e.raise("Unterminated group");
            }
          }
          e.pos = t;
        }
        return !1;
      }),
      (m.regexp_eatCapturingGroup = function (e) {
        if (e.eat(40)) {
          if (
            (this.options.ecmaVersion >= 9
              ? this.regexp_groupSpecifier(e)
              : e.current() === 63 && e.raise("Invalid group"),
            this.regexp_disjunction(e),
            e.eat(41))
          )
            return (e.numCapturingParens += 1), !0;
          e.raise("Unterminated group");
        }
        return !1;
      }),
      (m.regexp_eatModifiers = function (e) {
        for (var t = "", r = 0; (r = e.current()) !== -1 && ea(r); )
          (t += te(r)), e.advance();
        return t;
      });
    function ea(e) {
      return e === 105 || e === 109 || e === 115;
    }
    (m.regexp_eatExtendedAtom = function (e) {
      return (
        e.eat(46) ||
        this.regexp_eatReverseSolidusAtomEscape(e) ||
        this.regexp_eatCharacterClass(e) ||
        this.regexp_eatUncapturingGroup(e) ||
        this.regexp_eatCapturingGroup(e) ||
        this.regexp_eatInvalidBracedQuantifier(e) ||
        this.regexp_eatExtendedPatternCharacter(e)
      );
    }),
      (m.regexp_eatInvalidBracedQuantifier = function (e) {
        return (
          this.regexp_eatBracedQuantifier(e, !0) &&
            e.raise("Nothing to repeat"),
          !1
        );
      }),
      (m.regexp_eatSyntaxCharacter = function (e) {
        var t = e.current();
        return vi(t) ? ((e.lastIntValue = t), e.advance(), !0) : !1;
      });
    function vi(e) {
      return (
        e === 36 ||
        (e >= 40 && e <= 43) ||
        e === 46 ||
        e === 63 ||
        (e >= 91 && e <= 94) ||
        (e >= 123 && e <= 125)
      );
    }
    (m.regexp_eatPatternCharacters = function (e) {
      for (var t = e.pos, r = 0; (r = e.current()) !== -1 && !vi(r); )
        e.advance();
      return e.pos !== t;
    }),
      (m.regexp_eatExtendedPatternCharacter = function (e) {
        var t = e.current();
        return t !== -1 &&
          t !== 36 &&
          !(t >= 40 && t <= 43) &&
          t !== 46 &&
          t !== 63 &&
          t !== 91 &&
          t !== 94 &&
          t !== 124
          ? (e.advance(), !0)
          : !1;
      }),
      (m.regexp_groupSpecifier = function (e) {
        if (e.eat(63)) {
          this.regexp_eatGroupName(e) || e.raise("Invalid group");
          var t = this.options.ecmaVersion >= 16,
            r = e.groupNames[e.lastStringValue];
          if (r)
            if (t)
              for (var i = 0, a = r; i < a.length; i += 1) {
                var s = a[i];
                s.separatedFrom(e.branchID) ||
                  e.raise("Duplicate capture group name");
              }
            else e.raise("Duplicate capture group name");
          t
            ? (r || (e.groupNames[e.lastStringValue] = [])).push(e.branchID)
            : (e.groupNames[e.lastStringValue] = !0);
        }
      }),
      (m.regexp_eatGroupName = function (e) {
        if (((e.lastStringValue = ""), e.eat(60))) {
          if (this.regexp_eatRegExpIdentifierName(e) && e.eat(62)) return !0;
          e.raise("Invalid capture group name");
        }
        return !1;
      }),
      (m.regexp_eatRegExpIdentifierName = function (e) {
        if (
          ((e.lastStringValue = ""), this.regexp_eatRegExpIdentifierStart(e))
        ) {
          for (
            e.lastStringValue += te(e.lastIntValue);
            this.regexp_eatRegExpIdentifierPart(e);

          )
            e.lastStringValue += te(e.lastIntValue);
          return !0;
        }
        return !1;
      }),
      (m.regexp_eatRegExpIdentifierStart = function (e) {
        var t = e.pos,
          r = this.options.ecmaVersion >= 11,
          i = e.current(r);
        return (
          e.advance(r),
          i === 92 &&
            this.regexp_eatRegExpUnicodeEscapeSequence(e, r) &&
            (i = e.lastIntValue),
          ta(i) ? ((e.lastIntValue = i), !0) : ((e.pos = t), !1)
        );
      });
    function ta(e) {
      return ee(e, !0) || e === 36 || e === 95;
    }
    m.regexp_eatRegExpIdentifierPart = function (e) {
      var t = e.pos,
        r = this.options.ecmaVersion >= 11,
        i = e.current(r);
      return (
        e.advance(r),
        i === 92 &&
          this.regexp_eatRegExpUnicodeEscapeSequence(e, r) &&
          (i = e.lastIntValue),
        ia(i) ? ((e.lastIntValue = i), !0) : ((e.pos = t), !1)
      );
    };
    function ia(e) {
      return Se(e, !0) || e === 36 || e === 95 || e === 8204 || e === 8205;
    }
    (m.regexp_eatAtomEscape = function (e) {
      return this.regexp_eatBackReference(e) ||
        this.regexp_eatCharacterClassEscape(e) ||
        this.regexp_eatCharacterEscape(e) ||
        (e.switchN && this.regexp_eatKGroupName(e))
        ? !0
        : (e.switchU &&
            (e.current() === 99 && e.raise("Invalid unicode escape"),
            e.raise("Invalid escape")),
          !1);
    }),
      (m.regexp_eatBackReference = function (e) {
        var t = e.pos;
        if (this.regexp_eatDecimalEscape(e)) {
          var r = e.lastIntValue;
          if (e.switchU)
            return r > e.maxBackReference && (e.maxBackReference = r), !0;
          if (r <= e.numCapturingParens) return !0;
          e.pos = t;
        }
        return !1;
      }),
      (m.regexp_eatKGroupName = function (e) {
        if (e.eat(107)) {
          if (this.regexp_eatGroupName(e))
            return e.backReferenceNames.push(e.lastStringValue), !0;
          e.raise("Invalid named reference");
        }
        return !1;
      }),
      (m.regexp_eatCharacterEscape = function (e) {
        return (
          this.regexp_eatControlEscape(e) ||
          this.regexp_eatCControlLetter(e) ||
          this.regexp_eatZero(e) ||
          this.regexp_eatHexEscapeSequence(e) ||
          this.regexp_eatRegExpUnicodeEscapeSequence(e, !1) ||
          (!e.switchU && this.regexp_eatLegacyOctalEscapeSequence(e)) ||
          this.regexp_eatIdentityEscape(e)
        );
      }),
      (m.regexp_eatCControlLetter = function (e) {
        var t = e.pos;
        if (e.eat(99)) {
          if (this.regexp_eatControlLetter(e)) return !0;
          e.pos = t;
        }
        return !1;
      }),
      (m.regexp_eatZero = function (e) {
        return e.current() === 48 && !at(e.lookahead())
          ? ((e.lastIntValue = 0), e.advance(), !0)
          : !1;
      }),
      (m.regexp_eatControlEscape = function (e) {
        var t = e.current();
        return t === 116
          ? ((e.lastIntValue = 9), e.advance(), !0)
          : t === 110
          ? ((e.lastIntValue = 10), e.advance(), !0)
          : t === 118
          ? ((e.lastIntValue = 11), e.advance(), !0)
          : t === 102
          ? ((e.lastIntValue = 12), e.advance(), !0)
          : t === 114
          ? ((e.lastIntValue = 13), e.advance(), !0)
          : !1;
      }),
      (m.regexp_eatControlLetter = function (e) {
        var t = e.current();
        return Si(t) ? ((e.lastIntValue = t % 32), e.advance(), !0) : !1;
      });
    function Si(e) {
      return (e >= 65 && e <= 90) || (e >= 97 && e <= 122);
    }
    m.regexp_eatRegExpUnicodeEscapeSequence = function (e, t) {
      t === void 0 && (t = !1);
      var r = e.pos,
        i = t || e.switchU;
      if (e.eat(117)) {
        if (this.regexp_eatFixedHexDigits(e, 4)) {
          var a = e.lastIntValue;
          if (i && a >= 55296 && a <= 56319) {
            var s = e.pos;
            if (
              e.eat(92) &&
              e.eat(117) &&
              this.regexp_eatFixedHexDigits(e, 4)
            ) {
              var n = e.lastIntValue;
              if (n >= 56320 && n <= 57343)
                return (
                  (e.lastIntValue = (a - 55296) * 1024 + (n - 56320) + 65536),
                  !0
                );
            }
            (e.pos = s), (e.lastIntValue = a);
          }
          return !0;
        }
        if (
          i &&
          e.eat(123) &&
          this.regexp_eatHexDigits(e) &&
          e.eat(125) &&
          ra(e.lastIntValue)
        )
          return !0;
        i && e.raise("Invalid unicode escape"), (e.pos = r);
      }
      return !1;
    };
    function ra(e) {
      return e >= 0 && e <= 1114111;
    }
    (m.regexp_eatIdentityEscape = function (e) {
      if (e.switchU)
        return this.regexp_eatSyntaxCharacter(e)
          ? !0
          : e.eat(47)
          ? ((e.lastIntValue = 47), !0)
          : !1;
      var t = e.current();
      return t !== 99 && (!e.switchN || t !== 107)
        ? ((e.lastIntValue = t), e.advance(), !0)
        : !1;
    }),
      (m.regexp_eatDecimalEscape = function (e) {
        e.lastIntValue = 0;
        var t = e.current();
        if (t >= 49 && t <= 57) {
          do (e.lastIntValue = 10 * e.lastIntValue + (t - 48)), e.advance();
          while ((t = e.current()) >= 48 && t <= 57);
          return !0;
        }
        return !1;
      });
    var wi = 0,
      re = 1,
      H = 2;
    m.regexp_eatCharacterClassEscape = function (e) {
      var t = e.current();
      if (aa(t)) return (e.lastIntValue = -1), e.advance(), re;
      var r = !1;
      if (
        e.switchU &&
        this.options.ecmaVersion >= 9 &&
        ((r = t === 80) || t === 112)
      ) {
        (e.lastIntValue = -1), e.advance();
        var i;
        if (
          e.eat(123) &&
          (i = this.regexp_eatUnicodePropertyValueExpression(e)) &&
          e.eat(125)
        )
          return r && i === H && e.raise("Invalid property name"), i;
        e.raise("Invalid property name");
      }
      return wi;
    };
    function aa(e) {
      return (
        e === 100 || e === 68 || e === 115 || e === 83 || e === 119 || e === 87
      );
    }
    (m.regexp_eatUnicodePropertyValueExpression = function (e) {
      var t = e.pos;
      if (this.regexp_eatUnicodePropertyName(e) && e.eat(61)) {
        var r = e.lastStringValue;
        if (this.regexp_eatUnicodePropertyValue(e)) {
          var i = e.lastStringValue;
          return this.regexp_validateUnicodePropertyNameAndValue(e, r, i), re;
        }
      }
      if (((e.pos = t), this.regexp_eatLoneUnicodePropertyNameOrValue(e))) {
        var a = e.lastStringValue;
        return this.regexp_validateUnicodePropertyNameOrValue(e, a);
      }
      return wi;
    }),
      (m.regexp_validateUnicodePropertyNameAndValue = function (e, t, r) {
        ke(e.unicodeProperties.nonBinary, t) ||
          e.raise("Invalid property name"),
          e.unicodeProperties.nonBinary[t].test(r) ||
            e.raise("Invalid property value");
      }),
      (m.regexp_validateUnicodePropertyNameOrValue = function (e, t) {
        if (e.unicodeProperties.binary.test(t)) return re;
        if (e.switchV && e.unicodeProperties.binaryOfStrings.test(t)) return H;
        e.raise("Invalid property name");
      }),
      (m.regexp_eatUnicodePropertyName = function (e) {
        var t = 0;
        for (e.lastStringValue = ""; ki((t = e.current())); )
          (e.lastStringValue += te(t)), e.advance();
        return e.lastStringValue !== "";
      });
    function ki(e) {
      return Si(e) || e === 95;
    }
    m.regexp_eatUnicodePropertyValue = function (e) {
      var t = 0;
      for (e.lastStringValue = ""; sa((t = e.current())); )
        (e.lastStringValue += te(t)), e.advance();
      return e.lastStringValue !== "";
    };
    function sa(e) {
      return ki(e) || at(e);
    }
    (m.regexp_eatLoneUnicodePropertyNameOrValue = function (e) {
      return this.regexp_eatUnicodePropertyValue(e);
    }),
      (m.regexp_eatCharacterClass = function (e) {
        if (e.eat(91)) {
          var t = e.eat(94),
            r = this.regexp_classContents(e);
          return (
            e.eat(93) || e.raise("Unterminated character class"),
            t &&
              r === H &&
              e.raise("Negated character class may contain strings"),
            !0
          );
        }
        return !1;
      }),
      (m.regexp_classContents = function (e) {
        return e.current() === 93
          ? re
          : e.switchV
          ? this.regexp_classSetExpression(e)
          : (this.regexp_nonEmptyClassRanges(e), re);
      }),
      (m.regexp_nonEmptyClassRanges = function (e) {
        for (; this.regexp_eatClassAtom(e); ) {
          var t = e.lastIntValue;
          if (e.eat(45) && this.regexp_eatClassAtom(e)) {
            var r = e.lastIntValue;
            e.switchU &&
              (t === -1 || r === -1) &&
              e.raise("Invalid character class"),
              t !== -1 &&
                r !== -1 &&
                t > r &&
                e.raise("Range out of order in character class");
          }
        }
      }),
      (m.regexp_eatClassAtom = function (e) {
        var t = e.pos;
        if (e.eat(92)) {
          if (this.regexp_eatClassEscape(e)) return !0;
          if (e.switchU) {
            var r = e.current();
            (r === 99 || _i(r)) && e.raise("Invalid class escape"),
              e.raise("Invalid escape");
          }
          e.pos = t;
        }
        var i = e.current();
        return i !== 93 ? ((e.lastIntValue = i), e.advance(), !0) : !1;
      }),
      (m.regexp_eatClassEscape = function (e) {
        var t = e.pos;
        if (e.eat(98)) return (e.lastIntValue = 8), !0;
        if (e.switchU && e.eat(45)) return (e.lastIntValue = 45), !0;
        if (!e.switchU && e.eat(99)) {
          if (this.regexp_eatClassControlLetter(e)) return !0;
          e.pos = t;
        }
        return (
          this.regexp_eatCharacterClassEscape(e) ||
          this.regexp_eatCharacterEscape(e)
        );
      }),
      (m.regexp_classSetExpression = function (e) {
        var t = re,
          r;
        if (!this.regexp_eatClassSetRange(e))
          if ((r = this.regexp_eatClassSetOperand(e))) {
            r === H && (t = H);
            for (var i = e.pos; e.eatChars([38, 38]); ) {
              if (
                e.current() !== 38 &&
                (r = this.regexp_eatClassSetOperand(e))
              ) {
                r !== H && (t = re);
                continue;
              }
              e.raise("Invalid character in character class");
            }
            if (i !== e.pos) return t;
            for (; e.eatChars([45, 45]); )
              this.regexp_eatClassSetOperand(e) ||
                e.raise("Invalid character in character class");
            if (i !== e.pos) return t;
          } else e.raise("Invalid character in character class");
        for (;;)
          if (!this.regexp_eatClassSetRange(e)) {
            if (((r = this.regexp_eatClassSetOperand(e)), !r)) return t;
            r === H && (t = H);
          }
      }),
      (m.regexp_eatClassSetRange = function (e) {
        var t = e.pos;
        if (this.regexp_eatClassSetCharacter(e)) {
          var r = e.lastIntValue;
          if (e.eat(45) && this.regexp_eatClassSetCharacter(e)) {
            var i = e.lastIntValue;
            return (
              r !== -1 &&
                i !== -1 &&
                r > i &&
                e.raise("Range out of order in character class"),
              !0
            );
          }
          e.pos = t;
        }
        return !1;
      }),
      (m.regexp_eatClassSetOperand = function (e) {
        return this.regexp_eatClassSetCharacter(e)
          ? re
          : this.regexp_eatClassStringDisjunction(e) ||
              this.regexp_eatNestedClass(e);
      }),
      (m.regexp_eatNestedClass = function (e) {
        var t = e.pos;
        if (e.eat(91)) {
          var r = e.eat(94),
            i = this.regexp_classContents(e);
          if (e.eat(93))
            return (
              r &&
                i === H &&
                e.raise("Negated character class may contain strings"),
              i
            );
          e.pos = t;
        }
        if (e.eat(92)) {
          var a = this.regexp_eatCharacterClassEscape(e);
          if (a) return a;
          e.pos = t;
        }
        return null;
      }),
      (m.regexp_eatClassStringDisjunction = function (e) {
        var t = e.pos;
        if (e.eatChars([92, 113])) {
          if (e.eat(123)) {
            var r = this.regexp_classStringDisjunctionContents(e);
            if (e.eat(125)) return r;
          } else e.raise("Invalid escape");
          e.pos = t;
        }
        return null;
      }),
      (m.regexp_classStringDisjunctionContents = function (e) {
        for (var t = this.regexp_classString(e); e.eat(124); )
          this.regexp_classString(e) === H && (t = H);
        return t;
      }),
      (m.regexp_classString = function (e) {
        for (var t = 0; this.regexp_eatClassSetCharacter(e); ) t++;
        return t === 1 ? re : H;
      }),
      (m.regexp_eatClassSetCharacter = function (e) {
        var t = e.pos;
        if (e.eat(92))
          return this.regexp_eatCharacterEscape(e) ||
            this.regexp_eatClassSetReservedPunctuator(e)
            ? !0
            : e.eat(98)
            ? ((e.lastIntValue = 8), !0)
            : ((e.pos = t), !1);
        var r = e.current();
        return r < 0 || (r === e.lookahead() && na(r)) || oa(r)
          ? !1
          : (e.advance(), (e.lastIntValue = r), !0);
      });
    function na(e) {
      return (
        e === 33 ||
        (e >= 35 && e <= 38) ||
        (e >= 42 && e <= 44) ||
        e === 46 ||
        (e >= 58 && e <= 64) ||
        e === 94 ||
        e === 96 ||
        e === 126
      );
    }
    function oa(e) {
      return (
        e === 40 ||
        e === 41 ||
        e === 45 ||
        e === 47 ||
        (e >= 91 && e <= 93) ||
        (e >= 123 && e <= 125)
      );
    }
    m.regexp_eatClassSetReservedPunctuator = function (e) {
      var t = e.current();
      return ua(t) ? ((e.lastIntValue = t), e.advance(), !0) : !1;
    };
    function ua(e) {
      return (
        e === 33 ||
        e === 35 ||
        e === 37 ||
        e === 38 ||
        e === 44 ||
        e === 45 ||
        (e >= 58 && e <= 62) ||
        e === 64 ||
        e === 96 ||
        e === 126
      );
    }
    (m.regexp_eatClassControlLetter = function (e) {
      var t = e.current();
      return at(t) || t === 95
        ? ((e.lastIntValue = t % 32), e.advance(), !0)
        : !1;
    }),
      (m.regexp_eatHexEscapeSequence = function (e) {
        var t = e.pos;
        if (e.eat(120)) {
          if (this.regexp_eatFixedHexDigits(e, 2)) return !0;
          e.switchU && e.raise("Invalid escape"), (e.pos = t);
        }
        return !1;
      }),
      (m.regexp_eatDecimalDigits = function (e) {
        var t = e.pos,
          r = 0;
        for (e.lastIntValue = 0; at((r = e.current())); )
          (e.lastIntValue = 10 * e.lastIntValue + (r - 48)), e.advance();
        return e.pos !== t;
      });
    function at(e) {
      return e >= 48 && e <= 57;
    }
    m.regexp_eatHexDigits = function (e) {
      var t = e.pos,
        r = 0;
      for (e.lastIntValue = 0; Ei((r = e.current())); )
        (e.lastIntValue = 16 * e.lastIntValue + Ci(r)), e.advance();
      return e.pos !== t;
    };
    function Ei(e) {
      return (
        (e >= 48 && e <= 57) || (e >= 65 && e <= 70) || (e >= 97 && e <= 102)
      );
    }
    function Ci(e) {
      return e >= 65 && e <= 70
        ? 10 + (e - 65)
        : e >= 97 && e <= 102
        ? 10 + (e - 97)
        : e - 48;
    }
    (m.regexp_eatLegacyOctalEscapeSequence = function (e) {
      if (this.regexp_eatOctalDigit(e)) {
        var t = e.lastIntValue;
        if (this.regexp_eatOctalDigit(e)) {
          var r = e.lastIntValue;
          t <= 3 && this.regexp_eatOctalDigit(e)
            ? (e.lastIntValue = t * 64 + r * 8 + e.lastIntValue)
            : (e.lastIntValue = t * 8 + r);
        } else e.lastIntValue = t;
        return !0;
      }
      return !1;
    }),
      (m.regexp_eatOctalDigit = function (e) {
        var t = e.current();
        return _i(t)
          ? ((e.lastIntValue = t - 48), e.advance(), !0)
          : ((e.lastIntValue = 0), !1);
      });
    function _i(e) {
      return e >= 48 && e <= 55;
    }
    m.regexp_eatFixedHexDigits = function (e, t) {
      var r = e.pos;
      e.lastIntValue = 0;
      for (var i = 0; i < t; ++i) {
        var a = e.current();
        if (!Ei(a)) return (e.pos = r), !1;
        (e.lastIntValue = 16 * e.lastIntValue + Ci(a)), e.advance();
      }
      return !0;
    };
    var Et = function Et(t) {
        (this.type = t.type),
          (this.value = t.value),
          (this.start = t.start),
          (this.end = t.end),
          t.options.locations && (this.loc = new Qe(t, t.startLoc, t.endLoc)),
          t.options.ranges && (this.range = [t.start, t.end]);
      },
      b = V.prototype;
    (b.next = function (e) {
      !e &&
        this.type.keyword &&
        this.containsEsc &&
        this.raiseRecoverable(
          this.start,
          "Escape sequence in keyword " + this.type.keyword
        ),
        this.options.onToken && this.options.onToken(new Et(this)),
        (this.lastTokEnd = this.end),
        (this.lastTokStart = this.start),
        (this.lastTokEndLoc = this.endLoc),
        (this.lastTokStartLoc = this.startLoc),
        this.nextToken();
    }),
      (b.getToken = function () {
        return this.next(), new Et(this);
      }),
      (typeof Symbol === "undefined" ? "undefined" : _type_of(Symbol)) < "u" &&
        (b[Symbol.iterator] = function () {
          var e = this;
          return {
            next: function next() {
              var t = e.getToken();
              return { done: t.type === o.eof, value: t };
            },
          };
        }),
      (b.nextToken = function () {
        var e = this.curContext();
        if (
          ((!e || !e.preserveSpace) && this.skipSpace(),
          (this.start = this.pos),
          this.options.locations && (this.startLoc = this.curPosition()),
          this.pos >= this.input.length)
        )
          return this.finishToken(o.eof);
        if (e.override) return e.override(this);
        this.readToken(this.fullCharCodeAtPos());
      }),
      (b.readToken = function (e) {
        return ee(e, this.options.ecmaVersion >= 6) || e === 92
          ? this.readWord()
          : this.getTokenFromCode(e);
      }),
      (b.fullCharCodeAtPos = function () {
        var e = this.input.charCodeAt(this.pos);
        if (e <= 55295 || e >= 56320) return e;
        var t = this.input.charCodeAt(this.pos + 1);
        return t <= 56319 || t >= 57344 ? e : (e << 10) + t - 0x35fdc00;
      }),
      (b.skipBlockComment = function () {
        var e = this.options.onComment && this.curPosition(),
          t = this.pos,
          r = this.input.indexOf("*/", (this.pos += 2));
        if (
          (r === -1 && this.raise(this.pos - 2, "Unterminated comment"),
          (this.pos = r + 2),
          this.options.locations)
        )
          for (var i = void 0, a = t; (i = zt(this.input, a, this.pos)) > -1; )
            ++this.curLine, (a = this.lineStart = i);
        this.options.onComment &&
          this.options.onComment(
            !0,
            this.input.slice(t + 2, r),
            t,
            this.pos,
            e,
            this.curPosition()
          );
      }),
      (b.skipLineComment = function (e) {
        for (
          var t = this.pos,
            r = this.options.onComment && this.curPosition(),
            i = this.input.charCodeAt((this.pos += e));
          this.pos < this.input.length && !we(i);

        )
          i = this.input.charCodeAt(++this.pos);
        this.options.onComment &&
          this.options.onComment(
            !1,
            this.input.slice(t + e, this.pos),
            t,
            this.pos,
            r,
            this.curPosition()
          );
      }),
      (b.skipSpace = function () {
        e: for (; this.pos < this.input.length; ) {
          var e = this.input.charCodeAt(this.pos);
          switch (e) {
            case 32:
            case 160:
              ++this.pos;
              break;
            case 13:
              this.input.charCodeAt(this.pos + 1) === 10 && ++this.pos;
            case 10:
            case 8232:
            case 8233:
              ++this.pos,
                this.options.locations &&
                  (++this.curLine, (this.lineStart = this.pos));
              break;
            case 47:
              switch (this.input.charCodeAt(this.pos + 1)) {
                case 42:
                  this.skipBlockComment();
                  break;
                case 47:
                  this.skipLineComment(2);
                  break;
                default:
                  break e;
              }
              break;
            default:
              if (
                (e > 8 && e < 14) ||
                (e >= 5760 && Gt.test(String.fromCharCode(e)))
              )
                ++this.pos;
              else break e;
          }
        }
      }),
      (b.finishToken = function (e, t) {
        (this.end = this.pos),
          this.options.locations && (this.endLoc = this.curPosition());
        var r = this.type;
        (this.type = e), (this.value = t), this.updateContext(r);
      }),
      (b.readToken_dot = function () {
        var e = this.input.charCodeAt(this.pos + 1);
        if (e >= 48 && e <= 57) return this.readNumber(!0);
        var t = this.input.charCodeAt(this.pos + 2);
        return this.options.ecmaVersion >= 6 && e === 46 && t === 46
          ? ((this.pos += 3), this.finishToken(o.ellipsis))
          : (++this.pos, this.finishToken(o.dot));
      }),
      (b.readToken_slash = function () {
        var e = this.input.charCodeAt(this.pos + 1);
        return this.exprAllowed
          ? (++this.pos, this.readRegexp())
          : e === 61
          ? this.finishOp(o.assign, 2)
          : this.finishOp(o.slash, 1);
      }),
      (b.readToken_mult_modulo_exp = function (e) {
        var t = this.input.charCodeAt(this.pos + 1),
          r = 1,
          i = e === 42 ? o.star : o.modulo;
        return (
          this.options.ecmaVersion >= 7 &&
            e === 42 &&
            t === 42 &&
            (++r, (i = o.starstar), (t = this.input.charCodeAt(this.pos + 2))),
          t === 61 ? this.finishOp(o.assign, r + 1) : this.finishOp(i, r)
        );
      }),
      (b.readToken_pipe_amp = function (e) {
        var t = this.input.charCodeAt(this.pos + 1);
        if (t === e) {
          if (this.options.ecmaVersion >= 12) {
            var r = this.input.charCodeAt(this.pos + 2);
            if (r === 61) return this.finishOp(o.assign, 3);
          }
          return this.finishOp(e === 124 ? o.logicalOR : o.logicalAND, 2);
        }
        return t === 61
          ? this.finishOp(o.assign, 2)
          : this.finishOp(e === 124 ? o.bitwiseOR : o.bitwiseAND, 1);
      }),
      (b.readToken_caret = function () {
        var e = this.input.charCodeAt(this.pos + 1);
        return e === 61
          ? this.finishOp(o.assign, 2)
          : this.finishOp(o.bitwiseXOR, 1);
      }),
      (b.readToken_plus_min = function (e) {
        var t = this.input.charCodeAt(this.pos + 1);
        return t === e
          ? t === 45 &&
            !this.inModule &&
            this.input.charCodeAt(this.pos + 2) === 62 &&
            (this.lastTokEnd === 0 ||
              W.test(this.input.slice(this.lastTokEnd, this.pos)))
            ? (this.skipLineComment(3), this.skipSpace(), this.nextToken())
            : this.finishOp(o.incDec, 2)
          : t === 61
          ? this.finishOp(o.assign, 2)
          : this.finishOp(o.plusMin, 1);
      }),
      (b.readToken_lt_gt = function (e) {
        var t = this.input.charCodeAt(this.pos + 1),
          r = 1;
        return t === e
          ? ((r =
              e === 62 && this.input.charCodeAt(this.pos + 2) === 62 ? 3 : 2),
            this.input.charCodeAt(this.pos + r) === 61
              ? this.finishOp(o.assign, r + 1)
              : this.finishOp(o.bitShift, r))
          : t === 33 &&
            e === 60 &&
            !this.inModule &&
            this.input.charCodeAt(this.pos + 2) === 45 &&
            this.input.charCodeAt(this.pos + 3) === 45
          ? (this.skipLineComment(4), this.skipSpace(), this.nextToken())
          : (t === 61 && (r = 2), this.finishOp(o.relational, r));
      }),
      (b.readToken_eq_excl = function (e) {
        var t = this.input.charCodeAt(this.pos + 1);
        return t === 61
          ? this.finishOp(
              o.equality,
              this.input.charCodeAt(this.pos + 2) === 61 ? 3 : 2
            )
          : e === 61 && t === 62 && this.options.ecmaVersion >= 6
          ? ((this.pos += 2), this.finishToken(o.arrow))
          : this.finishOp(e === 61 ? o.eq : o.prefix, 1);
      }),
      (b.readToken_question = function () {
        var e = this.options.ecmaVersion;
        if (e >= 11) {
          var t = this.input.charCodeAt(this.pos + 1);
          if (t === 46) {
            var r = this.input.charCodeAt(this.pos + 2);
            if (r < 48 || r > 57) return this.finishOp(o.questionDot, 2);
          }
          if (t === 63) {
            if (e >= 12) {
              var i = this.input.charCodeAt(this.pos + 2);
              if (i === 61) return this.finishOp(o.assign, 3);
            }
            return this.finishOp(o.coalesce, 2);
          }
        }
        return this.finishOp(o.question, 1);
      }),
      (b.readToken_numberSign = function () {
        var e = this.options.ecmaVersion,
          t = 35;
        if (
          e >= 13 &&
          (++this.pos, (t = this.fullCharCodeAtPos()), ee(t, !0) || t === 92)
        )
          return this.finishToken(o.privateId, this.readWord1());
        this.raise(this.pos, "Unexpected character '" + te(t) + "'");
      }),
      (b.getTokenFromCode = function (e) {
        switch (e) {
          case 46:
            return this.readToken_dot();
          case 40:
            return ++this.pos, this.finishToken(o.parenL);
          case 41:
            return ++this.pos, this.finishToken(o.parenR);
          case 59:
            return ++this.pos, this.finishToken(o.semi);
          case 44:
            return ++this.pos, this.finishToken(o.comma);
          case 91:
            return ++this.pos, this.finishToken(o.bracketL);
          case 93:
            return ++this.pos, this.finishToken(o.bracketR);
          case 123:
            return ++this.pos, this.finishToken(o.braceL);
          case 125:
            return ++this.pos, this.finishToken(o.braceR);
          case 58:
            return ++this.pos, this.finishToken(o.colon);
          case 96:
            if (this.options.ecmaVersion < 6) break;
            return ++this.pos, this.finishToken(o.backQuote);
          case 48:
            var t = this.input.charCodeAt(this.pos + 1);
            if (t === 120 || t === 88) return this.readRadixNumber(16);
            if (this.options.ecmaVersion >= 6) {
              if (t === 111 || t === 79) return this.readRadixNumber(8);
              if (t === 98 || t === 66) return this.readRadixNumber(2);
            }
          case 49:
          case 50:
          case 51:
          case 52:
          case 53:
          case 54:
          case 55:
          case 56:
          case 57:
            return this.readNumber(!1);
          case 34:
          case 39:
            return this.readString(e);
          case 47:
            return this.readToken_slash();
          case 37:
          case 42:
            return this.readToken_mult_modulo_exp(e);
          case 124:
          case 38:
            return this.readToken_pipe_amp(e);
          case 94:
            return this.readToken_caret();
          case 43:
          case 45:
            return this.readToken_plus_min(e);
          case 60:
          case 62:
            return this.readToken_lt_gt(e);
          case 61:
          case 33:
            return this.readToken_eq_excl(e);
          case 63:
            return this.readToken_question();
          case 126:
            return this.finishOp(o.prefix, 1);
          case 35:
            return this.readToken_numberSign();
        }
        this.raise(this.pos, "Unexpected character '" + te(e) + "'");
      }),
      (b.finishOp = function (e, t) {
        var r = this.input.slice(this.pos, this.pos + t);
        return (this.pos += t), this.finishToken(e, r);
      }),
      (b.readRegexp = function () {
        for (var e, t, r = this.pos; ; ) {
          this.pos >= this.input.length &&
            this.raise(r, "Unterminated regular expression");
          var i = this.input.charAt(this.pos);
          if (
            (W.test(i) && this.raise(r, "Unterminated regular expression"), e)
          )
            e = !1;
          else {
            if (i === "[") t = !0;
            else if (i === "]" && t) t = !1;
            else if (i === "/" && !t) break;
            e = i === "\\";
          }
          ++this.pos;
        }
        var a = this.input.slice(r, this.pos);
        ++this.pos;
        var s = this.pos,
          n = this.readWord1();
        this.containsEsc && this.unexpected(s);
        var u = this.regexpState || (this.regexpState = new Y(this));
        u.reset(r, a, n),
          this.validateRegExpFlags(u),
          this.validateRegExpPattern(u);
        var l = null;
        try {
          l = new RegExp(a, n);
        } catch (e) {}
        return this.finishToken(o.regexp, { pattern: a, flags: n, value: l });
      }),
      (b.readInt = function (e, t, r) {
        for (
          var i = this.options.ecmaVersion >= 12 && t === void 0,
            a = r && this.input.charCodeAt(this.pos) === 48,
            s = this.pos,
            n = 0,
            u = 0,
            l = 0,
            c = t !== null && t !== void 0 ? t : 1 / 0;
          l < c;
          ++l, ++this.pos
        ) {
          var h = this.input.charCodeAt(this.pos),
            p = void 0;
          if (i && h === 95) {
            a &&
              this.raiseRecoverable(
                this.pos,
                "Numeric separator is not allowed in legacy octal numeric literals"
              ),
              u === 95 &&
                this.raiseRecoverable(
                  this.pos,
                  "Numeric separator must be exactly one underscore"
                ),
              l === 0 &&
                this.raiseRecoverable(
                  this.pos,
                  "Numeric separator is not allowed at the first of digits"
                ),
              (u = h);
            continue;
          }
          if (
            (h >= 97
              ? (p = h - 97 + 10)
              : h >= 65
              ? (p = h - 65 + 10)
              : h >= 48 && h <= 57
              ? (p = h - 48)
              : (p = 1 / 0),
            p >= e)
          )
            break;
          (u = h), (n = n * e + p);
        }
        return (
          i &&
            u === 95 &&
            this.raiseRecoverable(
              this.pos - 1,
              "Numeric separator is not allowed at the last of digits"
            ),
          this.pos === s || (t != null && this.pos - s !== t) ? null : n
        );
      });
    function la(e, t) {
      return t ? parseInt(e, 8) : parseFloat(e.replace(/_/g, ""));
    }
    function Ii(e) {
      return typeof BigInt != "function" ? null : BigInt(e.replace(/_/g, ""));
    }
    (b.readRadixNumber = function (e) {
      var t = this.pos;
      this.pos += 2;
      var r = this.readInt(e);
      return (
        r == null &&
          this.raise(this.start + 2, "Expected number in radix " + e),
        this.options.ecmaVersion >= 11 &&
        this.input.charCodeAt(this.pos) === 110
          ? ((r = Ii(this.input.slice(t, this.pos))), ++this.pos)
          : ee(this.fullCharCodeAtPos()) &&
            this.raise(this.pos, "Identifier directly after number"),
        this.finishToken(o.num, r)
      );
    }),
      (b.readNumber = function (e) {
        var t = this.pos;
        !e &&
          this.readInt(10, void 0, !0) === null &&
          this.raise(t, "Invalid number");
        var r = this.pos - t >= 2 && this.input.charCodeAt(t) === 48;
        r && this.strict && this.raise(t, "Invalid number");
        var i = this.input.charCodeAt(this.pos);
        if (!r && !e && this.options.ecmaVersion >= 11 && i === 110) {
          var a = Ii(this.input.slice(t, this.pos));
          return (
            ++this.pos,
            ee(this.fullCharCodeAtPos()) &&
              this.raise(this.pos, "Identifier directly after number"),
            this.finishToken(o.num, a)
          );
        }
        r && /[89]/.test(this.input.slice(t, this.pos)) && (r = !1),
          i === 46 &&
            !r &&
            (++this.pos,
            this.readInt(10),
            (i = this.input.charCodeAt(this.pos))),
          (i === 69 || i === 101) &&
            !r &&
            ((i = this.input.charCodeAt(++this.pos)),
            (i === 43 || i === 45) && ++this.pos,
            this.readInt(10) === null && this.raise(t, "Invalid number")),
          ee(this.fullCharCodeAtPos()) &&
            this.raise(this.pos, "Identifier directly after number");
        var s = la(this.input.slice(t, this.pos), r);
        return this.finishToken(o.num, s);
      }),
      (b.readCodePoint = function () {
        var e = this.input.charCodeAt(this.pos),
          t;
        if (e === 123) {
          this.options.ecmaVersion < 6 && this.unexpected();
          var r = ++this.pos;
          (t = this.readHexChar(this.input.indexOf("}", this.pos) - this.pos)),
            ++this.pos,
            t > 1114111 &&
              this.invalidStringToken(r, "Code point out of bounds");
        } else t = this.readHexChar(4);
        return t;
      }),
      (b.readString = function (e) {
        for (var t = "", r = ++this.pos; ; ) {
          this.pos >= this.input.length &&
            this.raise(this.start, "Unterminated string constant");
          var i = this.input.charCodeAt(this.pos);
          if (i === e) break;
          i === 92
            ? ((t += this.input.slice(r, this.pos)),
              (t += this.readEscapedChar(!1)),
              (r = this.pos))
            : i === 8232 || i === 8233
            ? (this.options.ecmaVersion < 10 &&
                this.raise(this.start, "Unterminated string constant"),
              ++this.pos,
              this.options.locations &&
                (this.curLine++, (this.lineStart = this.pos)))
            : (we(i) && this.raise(this.start, "Unterminated string constant"),
              ++this.pos);
        }
        return (
          (t += this.input.slice(r, this.pos++)), this.finishToken(o.string, t)
        );
      });
    var Ai = {};
    (b.tryReadTemplateToken = function () {
      this.inTemplateElement = !0;
      try {
        this.readTmplToken();
      } catch (e) {
        if (e === Ai) this.readInvalidTemplateToken();
        else throw e;
      }
      this.inTemplateElement = !1;
    }),
      (b.invalidStringToken = function (e, t) {
        if (this.inTemplateElement && this.options.ecmaVersion >= 9) throw Ai;
        this.raise(e, t);
      }),
      (b.readTmplToken = function () {
        for (var e = "", t = this.pos; ; ) {
          this.pos >= this.input.length &&
            this.raise(this.start, "Unterminated template");
          var r = this.input.charCodeAt(this.pos);
          if (
            r === 96 ||
            (r === 36 && this.input.charCodeAt(this.pos + 1) === 123)
          )
            return this.pos === this.start &&
              (this.type === o.template || this.type === o.invalidTemplate)
              ? r === 36
                ? ((this.pos += 2), this.finishToken(o.dollarBraceL))
                : (++this.pos, this.finishToken(o.backQuote))
              : ((e += this.input.slice(t, this.pos)),
                this.finishToken(o.template, e));
          if (r === 92)
            (e += this.input.slice(t, this.pos)),
              (e += this.readEscapedChar(!0)),
              (t = this.pos);
          else if (we(r)) {
            switch (((e += this.input.slice(t, this.pos)), ++this.pos, r)) {
              case 13:
                this.input.charCodeAt(this.pos) === 10 && ++this.pos;
              case 10:
                e += "\n";
                break;
              default:
                e += String.fromCharCode(r);
                break;
            }
            this.options.locations &&
              (++this.curLine, (this.lineStart = this.pos)),
              (t = this.pos);
          } else ++this.pos;
        }
      }),
      (b.readInvalidTemplateToken = function () {
        for (; this.pos < this.input.length; this.pos++)
          switch (this.input[this.pos]) {
            case "\\":
              ++this.pos;
              break;
            case "$":
              if (this.input[this.pos + 1] !== "{") break;
            case "`":
              return this.finishToken(
                o.invalidTemplate,
                this.input.slice(this.start, this.pos)
              );
            case "\r":
              this.input[this.pos + 1] === "\n" && ++this.pos;
            case "\n":
            case "\u2028":
            case "\u2029":
              ++this.curLine, (this.lineStart = this.pos + 1);
              break;
          }
        this.raise(this.start, "Unterminated template");
      }),
      (b.readEscapedChar = function (e) {
        var t = this.input.charCodeAt(++this.pos);
        switch ((++this.pos, t)) {
          case 110:
            return "\n";
          case 114:
            return "\r";
          case 120:
            return String.fromCharCode(this.readHexChar(2));
          case 117:
            return te(this.readCodePoint());
          case 116:
            return "	";
          case 98:
            return "\b";
          case 118:
            return "\v";
          case 102:
            return "\f";
          case 13:
            this.input.charCodeAt(this.pos) === 10 && ++this.pos;
          case 10:
            return (
              this.options.locations &&
                ((this.lineStart = this.pos), ++this.curLine),
              ""
            );
          case 56:
          case 57:
            if (
              (this.strict &&
                this.invalidStringToken(
                  this.pos - 1,
                  "Invalid escape sequence"
                ),
              e)
            ) {
              var r = this.pos - 1;
              this.invalidStringToken(
                r,
                "Invalid escape sequence in template string"
              );
            }
          default:
            if (t >= 48 && t <= 55) {
              var i = this.input.substr(this.pos - 1, 3).match(/^[0-7]+/)[0],
                a = parseInt(i, 8);
              return (
                a > 255 && ((i = i.slice(0, -1)), (a = parseInt(i, 8))),
                (this.pos += i.length - 1),
                (t = this.input.charCodeAt(this.pos)),
                (i !== "0" || t === 56 || t === 57) &&
                  (this.strict || e) &&
                  this.invalidStringToken(
                    this.pos - 1 - i.length,
                    e
                      ? "Octal literal in template string"
                      : "Octal literal in strict mode"
                  ),
                String.fromCharCode(a)
              );
            }
            return we(t)
              ? (this.options.locations &&
                  ((this.lineStart = this.pos), ++this.curLine),
                "")
              : String.fromCharCode(t);
        }
      }),
      (b.readHexChar = function (e) {
        var t = this.pos,
          r = this.readInt(16, e);
        return (
          r === null &&
            this.invalidStringToken(t, "Bad character escape sequence"),
          r
        );
      }),
      (b.readWord1 = function () {
        this.containsEsc = !1;
        for (
          var e = "", t = !0, r = this.pos, i = this.options.ecmaVersion >= 6;
          this.pos < this.input.length;

        ) {
          var a = this.fullCharCodeAtPos();
          if (Se(a, i)) this.pos += a <= 65535 ? 1 : 2;
          else if (a === 92) {
            (this.containsEsc = !0), (e += this.input.slice(r, this.pos));
            var s = this.pos;
            this.input.charCodeAt(++this.pos) !== 117 &&
              this.invalidStringToken(
                this.pos,
                "Expecting Unicode escape sequence \\uXXXX"
              ),
              ++this.pos;
            var n = this.readCodePoint();
            (t ? ee : Se)(n, i) ||
              this.invalidStringToken(s, "Invalid Unicode escape"),
              (e += te(n)),
              (r = this.pos);
          } else break;
          t = !1;
        }
        return e + this.input.slice(r, this.pos);
      }),
      (b.readWord = function () {
        var e = this.readWord1(),
          t = o.name;
        return this.keywords.test(e) && (t = dt[e]), this.finishToken(t, e);
      });
    var ca = "8.14.1";
    V.acorn = {
      Parser: V,
      version: ca,
      defaultOptions: yt,
      Position: Re,
      SourceLocation: Qe,
      getLineInfo: Xt,
      Node: it,
      TokenType: k,
      tokTypes: o,
      keywordTypes: dt,
      TokContext: Q,
      tokContexts: A,
      isIdentifierChar: Se,
      isIdentifierStart: ee,
      Token: Et,
      isNewLine: we,
      lineBreak: W,
      lineBreakG: Tr,
      nonASCIIwhitespace: Gt,
    };
    function ha(e, t) {
      return V.parse(e, t);
    }
    var me = { RES: void 0 },
      E = { RES: void 0 },
      _ = { LABEL: void 0 },
      I = { LABEL: void 0 },
      st = R("super"),
      he = R("supercall"),
      nt = R("noctor"),
      _e = R("clsctor"),
      ot = R("newtarget"),
      T = R("private"),
      O = R("noinit"),
      F = R("deadzone"),
      ge = R("import"),
      U = R("exports");
    var ut = /*#__PURE__*/ (function () {
      function ut(t, r) {
        _class_call_check(this, ut);
        (this.kind = t), (this.value = r);
      }
      _create_class(ut, [
        {
          key: "get",
          value: function get() {
            return this.value;
          },
        },
        {
          key: "set",
          value: function set(t) {
            if (this.kind === "const")
              throw new TypeError("Assignment to constant variable");
            return (this.value = t);
          },
        },
      ]);
      return ut;
    })();
    var fe = /*#__PURE__*/ (function () {
      function fe(t, r) {
        _class_call_check(this, fe);
        (this.object = t), (this.property = r);
      }
      _create_class(fe, [
        {
          key: "get",
          value: function get() {
            return this.object[this.property];
          },
        },
        {
          key: "set",
          value: function set(t) {
            return (this.object[this.property] = t), !0;
          },
        },
        {
          key: "del",
          value: function del() {
            return delete this.object[this.property];
          },
        },
      ]);
      return fe;
    })();
    var P = /*#__PURE__*/ (function () {
      function P() {
        var t =
            arguments.length > 0 && arguments[0] !== void 0
              ? arguments[0]
              : null,
          r =
            arguments.length > 1 && arguments[1] !== void 0 ? arguments[1] : !1;
        _class_call_check(this, P);
        (this.context = ve(null)),
          (this.withContext = ve(null)),
          (this.parent = t),
          (this.isolated = r);
      }
      _create_class(P, [
        {
          key: "global",
          value: function global1() {
            var t = this;
            for (; t.parent; ) t = t.parent;
            return t;
          },
        },
        {
          key: "find",
          value: function find(t) {
            if (this.context[t]) return this.context[t];
            if (t in this.withContext) return new fe(this.withContext, t);
            if (this.parent) return this.parent.find(t);
            {
              var r = this.global().find("window").get();
              return t in r ? new fe(r, t) : null;
            }
          },
        },
        {
          key: "var",
          value: function _var(t, r) {
            var i = this;
            for (; i.parent && !i.isolated; ) i = i.parent;
            var a = i.context[t];
            if (!a) i.context[t] = new ut("var", r === O ? void 0 : r);
            else if (a.kind === "var") r !== O && a.set(r);
            else
              throw new SyntaxError(
                "Identifier '".concat(t, "' has already been declared")
              );
            if (!i.parent) {
              var s = i.find("window").get();
              r !== O && w(s, t, { value: r, writable: !0, enumerable: !0 });
            }
          },
        },
        {
          key: "let",
          value: function _let(t, r) {
            var i = this.context[t];
            if (!i || i.get() === F) this.context[t] = new ut("let", r);
            else
              throw new SyntaxError(
                "Identifier '".concat(t, "' has already been declared")
              );
          },
        },
        {
          key: "const",
          value: function _const(t, r) {
            var i = this.context[t];
            if (!i || i.get() === F) this.context[t] = new ut("const", r);
            else
              throw new SyntaxError(
                "Identifier '".concat(t, "' has already been declared")
              );
          },
        },
        {
          key: "func",
          value: function func(t, r) {
            var i = this.context[t];
            if (!i || i.kind === "var") this.context[t] = new ut("var", r);
            else
              throw new SyntaxError(
                "Identifier '".concat(t, "' has already been declared")
              );
          },
        },
        {
          key: "with",
          value: function _with(t) {
            Object.keys(t) && (this.withContext = t);
          },
        },
      ]);
      return P;
    })();
    var fa = { version: "0.6.7" };
    function Ct(e) {
      var t =
        arguments.length > 1 && arguments[1] !== void 0 ? arguments[1] : {};
      var r = t.res,
        i = t.err,
        a = t.ret,
        s = t.fullRet;
      return new Promise(function (n, u) {
        var l = function l(p) {
          var S;
          try {
            S = e.next(p);
          } catch (C) {
            return u(C);
          }
          return h(S), null;
        };
        var c = function c(p) {
          var S;
          try {
            S = e.throw(p);
          } catch (C) {
            return u(C);
          }
          h(S);
        };
        var h = function h(p) {
          if (p.done) return n(s ? p : p.value);
          if (p.value !== me) return n(p);
          var S = p.value.RES;
          return (S && S.then === "function" ? S : Promise.resolve(S)).then(
            l,
            c
          );
        };
        if ("ret" in t) return n(e.return(a));
        "err" in t ? c(i) : l(r);
      });
    }
    function Ie(e, t) {
      var r, tmp, i, tmp1, a, s, n;
      var _arguments = arguments;
      return _ts_generator(this, function (_state) {
        r =
          _arguments.length > 2 && _arguments[2] !== void 0
            ? _arguments[2]
            : {};
        (tmp = r.getVar),
          (i = tmp === void 0 ? !1 : tmp),
          (tmp1 = r.throwErr),
          (a = tmp1 === void 0 ? !0 : tmp1);
        if (e.name === "undefined") return [2];
        s = t.find(e.name);
        if (s) {
          if (i) return [2, s];
          {
            n = s.get();
            if (n === F)
              throw new ReferenceError("".concat(e.name, " is not defined"));
            return [2, n];
          }
        } else {
          if (a) throw new ReferenceError("".concat(e.name, " is not defined"));
          return [2];
        }
        return [2];
      });
    }
    var pa = Object.freeze(
      Object.defineProperty(
        { __proto__: null, Identifier: Ie },
        Symbol.toStringTag,
        { value: "Module" }
      )
    );
    function Pi(e, t) {
      return _ts_generator(this, function (_state) {
        return [2, e.value];
      });
    }
    var da = Object.freeze(
      Object.defineProperty(
        { __proto__: null, Literal: Pi },
        Symbol.toStringTag,
        { value: "Module" }
      )
    );
    function ya(e, t) {
      var r;
      return _ts_generator(this, function (_state) {
        r = t.find(he);
        if (r && r.get() !== !0)
          throw new ReferenceError(
            "Must call super constructor in derived class before accessing 'this' or returning from derived constructor"
          );
        return [2, t.find("this").get()];
      });
    }
    function ma(e, t) {
      var r, i, a, _tmp, _, _1;
      return _ts_generator(this, function (_state) {
        switch (_state.label) {
          case 0:
            r = [];
            i = 0;
            _state.label = 1;
          case 1:
            if (!(i < e.elements.length)) return [3, 7];
            a = e.elements[i];
            if (!(a.type === "SpreadElement")) return [3, 3];
            _ = r.concat;
            return [5, _ts_values(je(a, t))];
          case 2:
            _tmp = r = _.apply(r, [_state.sent()]);
            return [3, 5];
          case 3:
            _1 = r.push;
            return [5, _ts_values(d(a, t))];
          case 4:
            _tmp = _1.apply(r, [_state.sent()]);
            _state.label = 5;
          case 5:
            _tmp;
            _state.label = 6;
          case 6:
            i++;
            return [3, 1];
          case 7:
            return [2, r];
        }
      });
    }
    function ga(e, t) {
      var r, i, a, _tmp, s, n, _tmp1, _tmp2, _, u, l, c, c1;
      return _ts_generator(this, function (_state) {
        switch (_state.label) {
          case 0:
            r = {};
            i = 0;
            _state.label = 1;
          case 1:
            if (!(i < e.properties.length)) return [3, 12];
            a = e.properties[i];
            if (!(a.type === "SpreadElement")) return [3, 3];
            _tmp = [r];
            return [5, _ts_values(je(a, t, { spreadProps: !0 }))];
          case 2:
            N.apply(void 0, _tmp.concat([_state.sent()]));
            return [3, 11];
          case 3:
            s = void 0;
            n = a.key;
            if (!a.computed) return [3, 5];
            return [5, _ts_values(d(n, t))];
          case 4:
            _tmp1 = s = _state.sent();
            return [3, 9];
          case 5:
            if (!(n.type === "Identifier")) return [3, 6];
            _tmp2 = s = n.name;
            return [3, 8];
          case 6:
            _ = "";
            return [5, _ts_values(Pi(n))];
          case 7:
            _tmp2 = s = _ + _state.sent();
            _state.label = 8;
          case 8:
            _tmp1 = _tmp2;
            _state.label = 9;
          case 9:
            _tmp1;
            return [5, _ts_values(d(a.value, t))];
          case 10:
            (u = _state.sent()), (l = a.kind);
            if (l === "init") r[s] = u;
            else if (l === "get") {
              c = ue(r, s);
              w(r, s, {
                get: u,
                set: c && c.set,
                enumerable: !0,
                configurable: !0,
              });
            } else {
              c1 = ue(r, s);
              w(r, s, {
                get: c1 && c1.get,
                set: u,
                enumerable: !0,
                configurable: !0,
              });
            }
            _state.label = 11;
          case 11:
            i++;
            return [3, 1];
          case 12:
            return [2, r];
        }
      });
    }
    function xa(e, t) {
      var r, i;
      return _ts_generator(this, function (_state) {
        if (e.id && e.id.name) {
          (r = new P(t)), (i = J(e, r));
          return [2, (r.const(e.id.name, i), i)];
        } else return [2, J(e, t)];
        return [2];
      });
    }
    function ba(e, t) {
      var r, _, _tmp;
      return _ts_generator(this, function (_state) {
        switch (_state.label) {
          case 0:
            r = e.argument;
            _ = e.operator;
            switch (_) {
              case "+":
                return [3, 1];
              case "-":
                return [3, 3];
              case "!":
                return [3, 5];
              case "~":
                return [3, 7];
              case "void":
                return [3, 9];
              case "typeof":
                return [3, 11];
              case "delete":
                return [3, 16];
            }
            return [3, 20];
          case 1:
            return [5, _ts_values(d(r, t))];
          case 2:
            return [2, +_state.sent()];
          case 3:
            return [5, _ts_values(d(r, t))];
          case 4:
            return [2, -_state.sent()];
          case 5:
            return [5, _ts_values(d(r, t))];
          case 6:
            return [2, !_state.sent()];
          case 7:
            return [5, _ts_values(d(r, t))];
          case 8:
            return [2, ~_state.sent()];
          case 9:
            return [5, _ts_values(d(r, t))];
          case 10:
            return [2, void _state.sent()];
          case 11:
            if (!(r.type === "Identifier")) return [3, 13];
            return [5, _ts_values(Ie(r, t, { throwErr: !1 }))];
          case 12:
            _tmp = _type_of.apply(void 0, [_state.sent()]);
            return [3, 15];
          case 13:
            return [5, _ts_values(d(r, t))];
          case 14:
            _tmp = _type_of.apply(void 0, [_state.sent()]);
            _state.label = 15;
          case 15:
            return [2, _tmp];
          case 16:
            if (!(r.type === "MemberExpression")) return [3, 18];
            return [5, _ts_values(Me(r, t, { getVar: !0 }))];
          case 17:
            return [2, _state.sent().del()];
          case 18:
            if (r.type === "Identifier")
              throw new SyntaxError(
                "Delete of an unqualified identifier in strict mode"
              );
            return [5, _ts_values(d(r, t))];
          case 19:
            return [2, (_state.sent(), !0)];
          case 20:
            throw new SyntaxError("Unexpected token ".concat(e.operator));
          case 21:
            return [2];
        }
      });
    }
    function va(e, t) {
      var r, i, a;
      return _ts_generator(this, function (_state) {
        switch (_state.label) {
          case 0:
            r = e.argument;
            if (!(r.type === "Identifier")) return [3, 2];
            return [5, _ts_values(Ie(r, t, { getVar: !0 }))];
          case 1:
            i = _state.sent();
            return [3, 5];
          case 2:
            if (!(r.type === "MemberExpression")) return [3, 4];
            return [5, _ts_values(Me(r, t, { getVar: !0 }))];
          case 3:
            i = _state.sent();
            return [3, 5];
          case 4:
            throw new SyntaxError("Unexpected token");
          case 5:
            a = i.get();
            if (e.operator === "++")
              return [2, (i.set(a + 1), e.prefix ? i.get() : a)];
            if (e.operator === "--")
              return [2, (i.set(a - 1), e.prefix ? i.get() : a)];
            throw new SyntaxError("Unexpected token ".concat(e.operator));
        }
      });
    }
    function Sa(e, t) {
      var r, i, _tmp;
      return _ts_generator(this, function (_state) {
        switch (_state.label) {
          case 0:
            if (!(e.left.type === "PrivateIdentifier")) return [3, 2];
            r = e.left.name;
            return [5, _ts_values(d(e.right, t))];
          case 1:
            _tmp = ((i = _state.sent()), (i = i[T] || {}));
            return [3, 5];
          case 2:
            return [5, _ts_values(d(e.left, t))];
          case 3:
            r = _state.sent();
            return [5, _ts_values(d(e.right, t))];
          case 4:
            _tmp = i = _state.sent();
            _state.label = 5;
          case 5:
            switch ((_tmp, e.operator)) {
              case "==":
                return [2, r == i];
              case "!=":
                return [2, r != i];
              case "===":
                return [2, r === i];
              case "!==":
                return [2, r !== i];
              case "<":
                return [2, r < i];
              case "<=":
                return [2, r <= i];
              case ">":
                return [2, r > i];
              case ">=":
                return [2, r >= i];
              case "<<":
                return [2, r << i];
              case ">>":
                return [2, r >> i];
              case ">>>":
                return [2, r >>> i];
              case "+":
                return [2, r + i];
              case "-":
                return [2, r - i];
              case "*":
                return [2, r * i];
              case "**":
                return [2, Math.pow(r, i)];
              case "/":
                return [2, r / i];
              case "%":
                return [2, r % i];
              case "|":
                return [2, r | i];
              case "^":
                return [2, r ^ i];
              case "&":
                return [2, r & i];
              case "in":
                return [2, r in i];
              case "instanceof":
                return [2, _instanceof(r, i)];
              default:
                throw new SyntaxError("Unexpected token ".concat(e.operator));
            }
            return [2];
        }
      });
    }
    function wa(e, t) {
      var r, i, s, s1, a, _i_get;
      return _ts_generator(this, function (_state) {
        switch (_state.label) {
          case 0:
            r = e.left;
            if (!(r.type === "Identifier")) return [3, 2];
            return [5, _ts_values(Ie(r, t, { getVar: !0, throwErr: !1 }))];
          case 1:
            if (((i = _state.sent()), !i)) {
              s = t.global().find("window").get();
              i = new fe(s, r.name);
            }
            return [3, 7];
          case 2:
            if (!(r.type === "MemberExpression")) return [3, 4];
            return [5, _ts_values(Me(r, t, { getVar: !0 }))];
          case 3:
            i = _state.sent();
            return [3, 7];
          case 4:
            return [5, _ts_values(d(e.right, t))];
          case 5:
            s1 = _state.sent();
            return [5, _ts_values(j(r, t, { feed: s1 }))];
          case 6:
            return [2, _state.sent()];
          case 7:
            return [5, _ts_values(d(e.right, t))];
          case 8:
            a = _state.sent();
            switch (e.operator) {
              case "=":
                return [2, (i.set(a), i.get())];
              case "+=":
                return [2, (i.set(i.get() + a), i.get())];
              case "-=":
                return [2, (i.set(i.get() - a), i.get())];
              case "*=":
                return [2, (i.set(i.get() * a), i.get())];
              case "/=":
                return [2, (i.set(i.get() / a), i.get())];
              case "%=":
                return [2, (i.set(i.get() % a), i.get())];
              case "**=":
                return [2, (i.set(Math.pow(i.get(), a)), i.get())];
              case "<<=":
                return [2, (i.set(i.get() << a), i.get())];
              case ">>=":
                return [2, (i.set(i.get() >> a), i.get())];
              case ">>>=":
                return [2, (i.set(i.get() >>> a), i.get())];
              case "|=":
                return [2, (i.set(i.get() | a), i.get())];
              case "^=":
                return [2, (i.set(i.get() ^ a), i.get())];
              case "&=":
                return [2, (i.set(i.get() & a), i.get())];
              case "??=":
                return [
                  2,
                  (i.set(
                    (_i_get = i.get()) !== null && _i_get !== void 0
                      ? _i_get
                      : a
                  ),
                  i.get()),
                ];
              case "&&=":
                return [2, (i.set(i.get() && a), i.get())];
              case "||=":
                return [2, (i.set(i.get() || a), i.get())];
              default:
                throw new SyntaxError("Unexpected token ".concat(e.operator));
            }
            return [2];
        }
      });
    }
    function ka(e, t) {
      var _, _tmp, _tmp1, _ref, _tmp2;
      return _ts_generator(this, function (_state) {
        switch (_state.label) {
          case 0:
            _ = e.operator;
            switch (_) {
              case "||":
                return [3, 1];
              case "&&":
                return [3, 5];
              case "??":
                return [3, 9];
            }
            return [3, 14];
          case 1:
            return [5, _ts_values(d(e.left, t))];
          case 2:
            _tmp = _state.sent();
            if (_tmp) return [3, 4];
            return [5, _ts_values(d(e.right, t))];
          case 3:
            _tmp = _state.sent();
            _state.label = 4;
          case 4:
            return [2, _tmp];
          case 5:
            return [5, _ts_values(d(e.left, t))];
          case 6:
            _tmp1 = _state.sent();
            if (!_tmp1) return [3, 8];
            return [5, _ts_values(d(e.right, t))];
          case 7:
            _tmp1 = _state.sent();
            _state.label = 8;
          case 8:
            return [2, _tmp1];
          case 9:
            return [5, _ts_values(d(e.left, t))];
          case 10:
            if (!((_ref = _state.sent()) !== null && _ref !== void 0))
              return [3, 11];
            _tmp2 = _ref;
            return [3, 13];
          case 11:
            return [5, _ts_values(d(e.right, t))];
          case 12:
            _tmp2 = _state.sent();
            _state.label = 13;
          case 13:
            return [2, _tmp2];
          case 14:
            throw new SyntaxError("Unexpected token ".concat(e.operator));
          case 15:
            return [2];
        }
      });
    }
    function Me(e, t) {
      var r, tmp, i, tmp1, a, s, _tmp, n, u, _tmp1, l, c, h, l1, c1;
      var _arguments = arguments;
      return _ts_generator(this, function (_state) {
        switch (_state.label) {
          case 0:
            r =
              _arguments.length > 2 && _arguments[2] !== void 0
                ? _arguments[2]
                : {};
            (tmp = r.getObj),
              (i = tmp === void 0 ? !1 : tmp),
              (tmp1 = r.getVar),
              (a = tmp1 === void 0 ? !1 : tmp1);
            if (!(e.object.type === "Super")) return [3, 2];
            return [5, _ts_values(Vi(e.object, t, { getProto: !0 }))];
          case 1:
            _tmp = s = _state.sent();
            return [3, 4];
          case 2:
            return [5, _ts_values(d(e.object, t))];
          case 3:
            _tmp = s = _state.sent();
            _state.label = 4;
          case 4:
            if ((_tmp, i)) return [2, s];
            u = !1;
            if (!e.computed) return [3, 6];
            return [5, _ts_values(d(e.property, t))];
          case 5:
            _tmp1 = n = _state.sent();
            return [3, 7];
          case 6:
            _tmp1 =
              e.property.type === "PrivateIdentifier"
                ? ((n = e.property.name), (u = !0))
                : (n = e.property.name);
            _state.label = 7;
          case 7:
            if ((_tmp1, u && (s = s[T]), a)) {
              l = jt(s, n);
              if (e.object.type === "Super" && l) {
                (c = t.find("this").get()), (h = R(n));
                return [2, (w(c, h, { set: l }), new fe(c, h))];
              } else return [2, new fe(s, n)];
            } else {
              l1 = Mt(s, n);
              if (e.object.type === "Super" && l1) {
                c1 = t.find("this").get();
                return [2, e.optional && c1 == null ? void 0 : l1.call(c1)];
              } else return [2, e.optional && s == null ? void 0 : s[n]];
            }
            return [2];
        }
      });
    }
    function Ea(e, t) {
      var _tmp;
      return _ts_generator(this, function (_state) {
        switch (_state.label) {
          case 0:
            return [5, _ts_values(d(e.test, t))];
          case 1:
            if (!_state.sent()) return [3, 3];
            return [5, _ts_values(d(e.consequent, t))];
          case 2:
            _tmp = _state.sent();
            return [3, 5];
          case 3:
            return [5, _ts_values(d(e.alternate, t))];
          case 4:
            _tmp = _state.sent();
            _state.label = 5;
          case 5:
            return [2, _tmp];
        }
      });
    }
    function Ca(e, t) {
      var r, i, _$s, n, _tmp, u, l, _$s1, a, _$s2, n1, _tmp1, _, _1, n2, u1, n3;
      return _ts_generator(this, function (_state) {
        switch (_state.label) {
          case 0:
            if (!(e.callee.type === "MemberExpression")) return [3, 5];
            return [5, _ts_values(Me(e.callee, t, { getObj: !0 }))];
          case 1:
            if (((i = _state.sent()), e.callee.optional && i == null))
              return [2];
            n = !1;
            if (!e.callee.computed) return [3, 3];
            return [5, _ts_values(d(e.callee.property, t))];
          case 2:
            _tmp = _$s = _state.sent();
            return [3, 4];
          case 3:
            _tmp =
              e.callee.property.type === "PrivateIdentifier"
                ? ((_$s = e.callee.property.name), (n = !0))
                : (_$s = e.callee.property.name);
            _state.label = 4;
          case 4:
            _tmp;
            u = i;
            if ((n && (u = u[T]), e.callee.object.type === "Super")) {
              l = t.find("this").get();
              r = u[_$s].bind(l);
            } else r = u[_$s];
            if (e.optional && r == null) return [2];
            if (typeof r != "function")
              throw new TypeError("".concat(_$s, " is not a function"));
            if (_e in r)
              throw new TypeError(
                "Class constructor ".concat(
                  _$s,
                  " cannot be invoked without 'new'"
                )
              );
            return [3, 7];
          case 5:
            i = t.find("this").get();
            return [5, _ts_values(d(e.callee, t))];
          case 6:
            if (((r = _state.sent()), e.optional && r == null)) return [2];
            if (
              typeof r != "function" ||
              (e.callee.type !== "Super" && _e in r)
            ) {
              if (e.callee.type === "Identifier") _$s1 = e.callee.name;
              else
                try {
                  _$s1 = JSON.stringify(r);
                } catch (e) {
                  _$s1 = "" + r;
                }
              throw typeof r != "function"
                ? new TypeError("".concat(_$s1, " is not a function"))
                : new TypeError(
                    "Class constructor ".concat(
                      _$s1,
                      " cannot be invoked without 'new'"
                    )
                  );
            }
            _state.label = 7;
          case 7:
            a = [];
            _$s2 = 0;
            _state.label = 8;
          case 8:
            if (!(_$s2 < e.arguments.length)) return [3, 14];
            n1 = e.arguments[_$s2];
            if (!(n1.type === "SpreadElement")) return [3, 10];
            _ = a.concat;
            return [5, _ts_values(je(n1, t))];
          case 9:
            _tmp1 = a = _.apply(a, [_state.sent()]);
            return [3, 12];
          case 10:
            _1 = a.push;
            return [5, _ts_values(d(n1, t))];
          case 11:
            _tmp1 = _1.apply(a, [_state.sent()]);
            _state.label = 12;
          case 12:
            _tmp1;
            _state.label = 13;
          case 13:
            _$s2++;
            return [3, 8];
          case 14:
            if (!(e.callee.type === "Super")) return [3, 16];
            n2 = t.find(he).get();
            if (n2 === !0)
              throw new ReferenceError(
                "Super constructor may only be called once"
              );
            u1 = Ge(i, r, a);
            return [5, _ts_values(n2(u1))];
          case 15:
            return [
              2,
              (_state.sent(), t.find("this").set(u1), t.find(he).set(!0), u1),
            ];
          case 16:
            try {
              return [2, r.apply(i, a)];
            } catch (s) {
              if (
                _instanceof(s, TypeError) &&
                s.message === "Illegal invocation" &&
                r.toString().indexOf("[native code]") !== -1
              ) {
                n3 = t.global().find("window").get();
                if (n3 && n3[Ne]) return [2, r.apply(n3[Ne], a)];
              }
              throw s;
            }
            return [2];
        }
      });
    }
    function _a(e, t) {
      var r, a, i, a1, s, _tmp, _, _1;
      return _ts_generator(this, function (_state) {
        switch (_state.label) {
          case 0:
            return [5, _ts_values(d(e.callee, t))];
          case 1:
            r = _state.sent();
            if (typeof r != "function") {
              if (e.callee.type === "Identifier") a = e.callee.name;
              else
                try {
                  a = JSON.stringify(r);
                } catch (e) {
                  a = "" + r;
                }
              throw new TypeError("".concat(a, " is not a constructor"));
            } else if (r[nt]) throw new TypeError("".concat(r.name || "(intermediate value)", " is not a constructor"));
            i = [];
            a1 = 0;
            _state.label = 2;
          case 2:
            if (!(a1 < e.arguments.length)) return [3, 8];
            s = e.arguments[a1];
            if (!(s.type === "SpreadElement")) return [3, 4];
            _ = i.concat;
            return [5, _ts_values(je(s, t))];
          case 3:
            _tmp = i = _.apply(i, [_state.sent()]);
            return [3, 6];
          case 4:
            _1 = i.push;
            return [5, _ts_values(d(s, t))];
          case 5:
            _tmp = _1.apply(i, [_state.sent()]);
            _state.label = 6;
          case 6:
            _tmp;
            _state.label = 7;
          case 7:
            a1++;
            return [3, 2];
          case 8:
            return [2, _construct(r, _to_consumable_array(i))];
        }
      });
    }
    function Ia(e, t) {
      return _ts_generator(this, function (_state) {
        if (e.meta.name === "new" && e.property.name === "target")
          return [2, t.find(ot).get()];
        if (e.meta.name === "import" && e.property.name === "meta")
          return [2, { url: "" }];
        return [2];
      });
    }
    function Aa(e, t) {
      var r, i;
      return _ts_generator(this, function (_state) {
        switch (_state.label) {
          case 0:
            i = 0;
            _state.label = 1;
          case 1:
            if (!(i < e.expressions.length)) return [3, 4];
            return [5, _ts_values(d(e.expressions[i], t))];
          case 2:
            r = _state.sent();
            _state.label = 3;
          case 3:
            i++;
            return [3, 1];
          case 4:
            return [2, r];
        }
      });
    }
    function Pa(e, t) {
      return _ts_generator(this, function (_state) {
        return [2, J(e, t)];
      });
    }
    function La(e, t) {
      var r, i, a, s, n, _tmp;
      return _ts_generator(this, function (_state) {
        switch (_state.label) {
          case 0:
            (r = e.quasis.slice()), (i = e.expressions.slice());
            a = "";
            _state.label = 1;
          case 1:
            if (!(s = r.shift())) return [3, 6];
            return [5, _ts_values(Li(s))];
          case 2:
            (a += _state.sent()), (n = i.shift());
            _tmp = n;
            if (!_tmp) return [3, 4];
            return [5, _ts_values(d(n, t))];
          case 3:
            _tmp = a += _state.sent();
            _state.label = 4;
          case 4:
            _tmp;
            _state.label = 5;
          case 5:
            return [3, 1];
          case 6:
            return [2, a];
        }
      });
    }
    function Va(e, t) {
      var r, i, a, s, n, u, l, _;
      return _ts_generator(this, function (_state) {
        switch (_state.label) {
          case 0:
            return [5, _ts_values(d(e.tag, t))];
          case 1:
            (r = _state.sent()),
              (i = e.quasi.quasis),
              (a = i.map(function (l) {
                return l.value.cooked;
              })),
              (s = i.map(function (l) {
                return l.value.raw;
              }));
            w(a, "raw", { value: ze(s) });
            (n = e.quasi.expressions), (u = []);
            if (!n) return [3, 5];
            l = 0;
            _state.label = 2;
          case 2:
            if (!(l < n.length)) return [3, 5];
            _ = u.push;
            return [5, _ts_values(d(n[l], t))];
          case 3:
            _.apply(u, [_state.sent()]);
            _state.label = 4;
          case 4:
            l++;
            return [3, 2];
          case 5:
            return [
              2,
              r.apply(void 0, [ze(a)].concat(_to_consumable_array(u))),
            ];
        }
      });
    }
    function Li(e, t) {
      return _ts_generator(this, function (_state) {
        return [2, e.value.raw];
      });
    }
    function Ta(e, t) {
      var r, i;
      return _ts_generator(this, function (_state) {
        switch (_state.label) {
          case 0:
            if (!(e.id && e.id.name)) return [3, 2];
            r = new P(t);
            return [5, _ts_values(We(e, r))];
          case 1:
            i = _state.sent();
            return [2, (r.const(e.id.name, i), i)];
          case 2:
            return [5, _ts_values(We(e, t))];
          case 3:
            return [2, _state.sent()];
          case 4:
            return [2];
        }
      });
    }
    function Vi(e, t) {
      var r, tmp, i, a;
      var _arguments = arguments;
      return _ts_generator(this, function (_state) {
        r =
          _arguments.length > 2 && _arguments[2] !== void 0
            ? _arguments[2]
            : {};
        (tmp = r.getProto),
          (i = tmp === void 0 ? !1 : tmp),
          (a = t.find(st).get());
        return [2, i ? a.prototype : a];
      });
    }
    function je(e, t) {
      var r, i;
      var _arguments = arguments;
      return _ts_generator(this, function (_state) {
        switch (_state.label) {
          case 0:
            r =
              _arguments.length > 2 && _arguments[2] !== void 0
                ? _arguments[2]
                : {};
            return [5, _ts_values(d(e.argument, t))];
          case 1:
            i = _state.sent();
            if (r.spreadProps) return [2, i];
            if (
              typeof Symbol == "function" &&
              typeof i[Symbol.iterator] != "function"
            )
              throw new TypeError(
                "Spread syntax requires ...iterable[Symbol.iterator] to be a function"
              );
            return [2, _to_consumable_array(i)];
        }
      });
    }
    function Na(e, t) {
      return _ts_generator(this, function (_state) {
        switch (_state.label) {
          case 0:
            return [5, _ts_values(d(e.expression, t))];
          case 1:
            return [2, _state.sent()];
        }
      });
    }
    function Ra(e, t) {
      var r, i, a, s, n;
      return _ts_generator(this, function (_state) {
        switch (_state.label) {
          case 0:
            r = t.global();
            return [5, _ts_values(d(e.source, t))];
          case 1:
            (i = _state.sent()), (a = r.find(ge + i));
            if (a) {
              n = a.get();
              n &&
                (typeof n == "function"
                  ? (s = n())
                  : (typeof n === "undefined" ? "undefined" : _type_of(n)) ==
                      "object" && (s = n));
            }
            return [
              2,
              !s ||
              (typeof s === "undefined" ? "undefined" : _type_of(s)) != "object"
                ? Promise.reject(
                    new TypeError(
                      'Failed to resolve module specifier "'.concat(i, '"')
                    )
                  )
                : Promise.resolve(s),
            ];
        }
      });
    }
    function Ba(e, t) {
      var r, _tmp;
      return _ts_generator(this, function (_state) {
        switch (_state.label) {
          case 0:
            return [5, _ts_values(d(e.argument, t))];
          case 1:
            r = _state.sent();
            if (!e.delegate) return [3, 3];
            return [5, _ts_values(r)];
          case 2:
            _tmp = _state.sent();
            return [3, 5];
          case 3:
            return [4, r];
          case 4:
            _tmp = _state.sent();
            _state.label = 5;
          case 5:
            return [2, _tmp];
        }
      });
    }
    function Oa(e, t) {
      return _ts_generator(this, function (_state) {
        switch (_state.label) {
          case 0:
            return [5, _ts_values(d(e.argument, t))];
          case 1:
            me.RES = _state.sent();
            return [4, me];
          case 2:
            return [2, _state.sent()];
        }
      });
    }
    var Da = Object.freeze(
      Object.defineProperty(
        {
          __proto__: null,
          ArrayExpression: ma,
          ArrowFunctionExpression: Pa,
          AssignmentExpression: wa,
          AwaitExpression: Oa,
          BinaryExpression: Sa,
          CallExpression: Ca,
          ChainExpression: Na,
          ClassExpression: Ta,
          ConditionalExpression: Ea,
          FunctionExpression: xa,
          ImportExpression: Ra,
          LogicalExpression: ka,
          MemberExpression: Me,
          MetaProperty: Ia,
          NewExpression: _a,
          ObjectExpression: ga,
          SequenceExpression: Aa,
          SpreadElement: je,
          Super: Vi,
          TaggedTemplateExpression: Va,
          TemplateElement: Li,
          TemplateLiteral: La,
          ThisExpression: ya,
          UnaryExpression: ba,
          UpdateExpression: va,
          YieldExpression: Ba,
        },
        Symbol.toStringTag,
        { value: "Module" }
      )
    );
    function Ti(e, t) {
      var r,
        tmp,
        i,
        tmp1,
        a,
        tmp2,
        s,
        tmp3,
        n,
        u,
        l,
        c,
        h,
        _tmp,
        h1,
        _tmp1,
        p,
        _tmp2,
        h2,
        p1;
      var _arguments = arguments;
      return _ts_generator(this, function (_state) {
        switch (_state.label) {
          case 0:
            r =
              _arguments.length > 2 && _arguments[2] !== void 0
                ? _arguments[2]
                : {};
            (tmp = r.kind),
              (i = tmp === void 0 ? "var" : tmp),
              (tmp1 = r.hoist),
              (a = tmp1 === void 0 ? !1 : tmp1),
              (tmp2 = r.onlyBlock),
              (s = tmp2 === void 0 ? !1 : tmp2),
              (tmp3 = r.feed),
              (n = tmp3 === void 0 ? {} : tmp3),
              (u = []);
            l = 0;
            _state.label = 1;
          case 1:
            if (!(l < e.properties.length)) return [3, 18];
            c = e.properties[l];
            if (!a) return [3, 8];
            if (!(s || i === "var")) return [3, 7];
            if (!(c.type === "Property")) return [3, 5];
            h = c.value;
            if (!(h.type === "Identifier")) return [3, 2];
            _tmp = t[i](h.name, s ? F : i === "var" ? O : void 0);
            return [3, 4];
          case 2:
            return [
              5,
              _ts_values(j(h, t, { kind: i, hoist: a, onlyBlock: s })),
            ];
          case 3:
            _tmp = _state.sent();
            _state.label = 4;
          case 4:
            _tmp;
            return [3, 7];
          case 5:
            return [
              5,
              _ts_values(Ae(c, t, { kind: i, hoist: a, onlyBlock: s })),
            ];
          case 6:
            _state.sent();
            _state.label = 7;
          case 7:
            return [3, 17];
          case 8:
            if (!(c.type === "Property")) return [3, 15];
            h1 = void 0;
            if (!c.computed) return [3, 10];
            return [5, _ts_values(d(c.key, t))];
          case 9:
            _tmp1 = h1 = _state.sent();
            return [3, 11];
          case 10:
            _tmp1 = h1 = c.key.name;
            _state.label = 11;
          case 11:
            _tmp1, u.push(h1);
            p = c.value;
            if (!(p.type === "Identifier")) return [3, 12];
            _tmp2 = t[i](p.name, n[h1]);
            return [3, 14];
          case 12:
            return [5, _ts_values(j(p, t, { kind: i, feed: n[h1] }))];
          case 13:
            _tmp2 = _state.sent();
            _state.label = 14;
          case 14:
            _tmp2;
            return [3, 17];
          case 15:
            h2 = N({}, n);
            for (p1 = 0; p1 < u.length; p1++) delete h2[u[p1]];
            return [5, _ts_values(Ae(c, t, { kind: i, feed: h2 }))];
          case 16:
            _state.sent();
            _state.label = 17;
          case 17:
            l++;
            return [3, 1];
          case 18:
            return [2];
        }
      });
    }
    function Ni(e, t) {
      var r, i, tmp, a, tmp1, s, tmp2, n, u, l, c, _tmp, _tmp1, h, _tmp2;
      var _arguments = arguments;
      return _ts_generator(this, function (_state) {
        switch (_state.label) {
          case 0:
            r =
              _arguments.length > 2 && _arguments[2] !== void 0
                ? _arguments[2]
                : {};
            (i = r.kind),
              (tmp = r.hoist),
              (a = tmp === void 0 ? !1 : tmp),
              (tmp1 = r.onlyBlock),
              (s = tmp1 === void 0 ? !1 : tmp1),
              (tmp2 = r.feed),
              (n = tmp2 === void 0 ? [] : tmp2),
              (u = []);
            l = 0;
            _state.label = 1;
          case 1:
            if (!(l < e.elements.length)) return [3, 16];
            c = e.elements[l];
            if (!c) return [3, 15];
            if (!a) return [3, 6];
            _tmp = s || i === "var";
            if (!_tmp) return [3, 5];
            if (!(c.type === "Identifier")) return [3, 2];
            _tmp1 = t[i](c.name, s ? F : i === "var" ? O : void 0);
            return [3, 4];
          case 2:
            return [
              5,
              _ts_values(j(c, t, { kind: i, hoist: a, onlyBlock: s })),
            ];
          case 3:
            _tmp1 = _state.sent();
            _state.label = 4;
          case 4:
            _tmp = _tmp1;
            _state.label = 5;
          case 5:
            _tmp;
            return [3, 15];
          case 6:
            if (!(c.type === "Identifier")) return [3, 10];
            if (!i) return [3, 7];
            t[i](c.name, n[l]);
            return [3, 9];
          case 7:
            return [5, _ts_values(Ie(c, t, { getVar: !0 }))];
          case 8:
            h = _state.sent();
            h.set(n[l]), u.push(h.get());
            _state.label = 9;
          case 9:
            return [3, 15];
          case 10:
            if (!(c.type === "RestElement")) return [3, 12];
            return [5, _ts_values(Ae(c, t, { kind: i, feed: n.slice(l) }))];
          case 11:
            _tmp2 = _state.sent();
            return [3, 14];
          case 12:
            return [5, _ts_values(j(c, t, { kind: i, feed: n[l] }))];
          case 13:
            _tmp2 = _state.sent();
            _state.label = 14;
          case 14:
            _tmp2;
            _state.label = 15;
          case 15:
            l++;
            return [3, 1];
          case 16:
            if (u.length) return [2, u];
            return [2];
        }
      });
    }
    function Ae(e, t) {
      var r, i, tmp, a, tmp1, s, tmp2, n, u, _tmp, _tmp1, _tmp2, _tmp3, _tmp4;
      var _arguments = arguments;
      return _ts_generator(this, function (_state) {
        switch (_state.label) {
          case 0:
            r =
              _arguments.length > 2 && _arguments[2] !== void 0
                ? _arguments[2]
                : {};
            (i = r.kind),
              (tmp = r.hoist),
              (a = tmp === void 0 ? !1 : tmp),
              (tmp1 = r.onlyBlock),
              (s = tmp1 === void 0 ? !1 : tmp1),
              (tmp2 = r.feed),
              (n = tmp2 === void 0 ? [] : tmp2),
              (u = e.argument);
            if (!a) return [3, 5];
            _tmp1 = s || i === "var";
            if (!_tmp1) return [3, 4];
            if (!(u.type === "Identifier")) return [3, 1];
            _tmp2 = t[i](u.name, s ? F : i === "var" ? O : void 0);
            return [3, 3];
          case 1:
            return [
              5,
              _ts_values(j(u, t, { kind: i, hoist: a, onlyBlock: s })),
            ];
          case 2:
            _tmp2 = _state.sent();
            _state.label = 3;
          case 3:
            _tmp1 = _tmp2;
            _state.label = 4;
          case 4:
            _tmp = _tmp1;
            return [3, 12];
          case 5:
            if (!(u.type === "Identifier")) return [3, 9];
            if (!i) return [3, 6];
            _tmp4 = t[i](u.name, n);
            return [3, 8];
          case 6:
            return [5, _ts_values(Ie(u, t, { getVar: !0 }))];
          case 7:
            _tmp4 = _state.sent().set(n);
            _state.label = 8;
          case 8:
            _tmp3 = _tmp4;
            return [3, 11];
          case 9:
            return [5, _ts_values(j(u, t, { kind: i, feed: n }))];
          case 10:
            _tmp3 = _state.sent();
            _state.label = 11;
          case 11:
            _tmp = _tmp3;
            _state.label = 12;
          case 12:
            _tmp;
            return [2];
        }
      });
    }
    function Ri(e, t) {
      var r,
        tmp,
        i,
        tmp1,
        a,
        tmp2,
        s,
        tmp3,
        n,
        u,
        _tmp,
        _tmp1,
        _tmp2,
        _tmp3,
        _tmp4;
      var _arguments = arguments;
      return _ts_generator(this, function (_state) {
        switch (_state.label) {
          case 0:
            r =
              _arguments.length > 2 && _arguments[2] !== void 0
                ? _arguments[2]
                : {};
            (tmp = r.kind),
              (i = tmp === void 0 ? "var" : tmp),
              (tmp1 = r.hoist),
              (a = tmp1 === void 0 ? !1 : tmp1),
              (tmp2 = r.onlyBlock),
              (s = tmp2 === void 0 ? !1 : tmp2),
              (tmp3 = r.feed);
            if (!(tmp3 === void 0)) return [3, 2];
            return [5, _ts_values(d(e.right, t))];
          case 1:
            _tmp = _state.sent();
            return [3, 3];
          case 2:
            _tmp = tmp3;
            _state.label = 3;
          case 3:
            (n = _tmp), (u = e.left);
            if (!a) return [3, 8];
            _tmp2 = s || i === "var";
            if (!_tmp2) return [3, 7];
            if (!(u.type === "Identifier")) return [3, 4];
            _tmp3 = t[i](u.name, s ? F : i === "var" ? O : void 0);
            return [3, 6];
          case 4:
            return [
              5,
              _ts_values(j(u, t, { kind: i, hoist: a, onlyBlock: s })),
            ];
          case 5:
            _tmp3 = _state.sent();
            _state.label = 6;
          case 6:
            _tmp2 = _tmp3;
            _state.label = 7;
          case 7:
            _tmp1 = _tmp2;
            return [3, 12];
          case 8:
            if (!(u.type === "Identifier")) return [3, 9];
            _tmp4 = t[i](u.name, n);
            return [3, 11];
          case 9:
            return [5, _ts_values(j(u, t, { kind: i, feed: n }))];
          case 10:
            _tmp4 = _state.sent();
            _state.label = 11;
          case 11:
            _tmp1 = _tmp4;
            _state.label = 12;
          case 12:
            _tmp1;
            return [2];
        }
      });
    }
    var Fa = Object.freeze(
      Object.defineProperty(
        {
          __proto__: null,
          ArrayPattern: Ni,
          AssignmentPattern: Ri,
          ObjectPattern: Ti,
          RestElement: Ae,
        },
        Symbol.toStringTag,
        { value: "Module" }
      )
    );
    function Ma(e, t) {
      var r;
      return _ts_generator(this, function (_state) {
        switch (_state.label) {
          case 0:
            r = 0;
            _state.label = 1;
          case 1:
            if (!(r < e.body.length)) return [3, 4];
            return [5, _ts_values(d(e.body[r], t))];
          case 2:
            _state.sent();
            _state.label = 3;
          case 3:
            r++;
            return [3, 1];
          case 4:
            return [2];
        }
      });
    }
    var ja = Object.freeze(
      Object.defineProperty(
        { __proto__: null, Program: Ma },
        Symbol.toStringTag,
        { value: "Module" }
      )
    );
    var _t;
    function d(e, t) {
      var r;
      return _ts_generator(this, function (_state) {
        switch (_state.label) {
          case 0:
            if (!e) return [2];
            _t || (_t = N({}, Te, Da, pa, Ve, da, Fa, ja));
            r = _t[e.type];
            if (!r) return [3, 2];
            return [5, _ts_values(r(e, t))];
          case 1:
            return [2, _state.sent()];
          case 2:
            throw new Error("".concat(e.type, " isn't implemented"));
        }
      });
    }
    function Ua(e, t) {
      return _ts_generator(this, function (_state) {
        switch (_state.label) {
          case 0:
            return [5, _ts_values(d(e.expression, t))];
          case 1:
            _state.sent();
            return [2];
        }
      });
    }
    function ae(e, t) {
      var r, tmp, i, tmp1, a, s, _tmp, n, u;
      var _arguments = arguments;
      return _ts_generator(this, function (_state) {
        switch (_state.label) {
          case 0:
            r =
              _arguments.length > 2 && _arguments[2] !== void 0
                ? _arguments[2]
                : {};
            (tmp = r.invasived),
              (i = tmp === void 0 ? !1 : tmp),
              (tmp1 = r.hoisted),
              (a = tmp1 === void 0 ? !1 : tmp1),
              (s = i ? t : new P(t));
            _tmp = a;
            if (_tmp) return [3, 2];
            return [5, _ts_values(Vt(e, s, { onlyBlock: !0 }))];
          case 1:
            _tmp = _state.sent();
            _state.label = 2;
          case 2:
            _tmp;
            n = 0;
            _state.label = 3;
          case 3:
            if (!(n < e.body.length)) return [3, 6];
            return [5, _ts_values(d(e.body[n], s))];
          case 4:
            u = _state.sent();
            if (u === I) {
              if (u.LABEL && u.LABEL === r.label) return [3, 6];
              return [2, u];
            }
            if (u === _ || u === E) return [2, u];
            _state.label = 5;
          case 5:
            n++;
            return [3, 3];
          case 6:
            return [2];
        }
      });
    }
    function $a() {
      return _ts_generator(this, function (_state) {
        return [2];
      });
    }
    function qa() {
      return _ts_generator(this, function (_state) {
        debugger;
        return [2];
      });
    }
    function Wa(e, t) {
      var _tmp;
      return _ts_generator(this, function (_state) {
        switch (_state.label) {
          case 0:
            if (!e.argument) return [3, 2];
            return [5, _ts_values(d(e.argument, t))];
          case 1:
            _tmp = _state.sent();
            return [3, 3];
          case 2:
            _tmp = void 0;
            _state.label = 3;
          case 3:
            return [2, ((E.RES = _tmp), E)];
        }
      });
    }
    function za(e) {
      var t;
      return _ts_generator(this, function (_state) {
        return [2, ((I.LABEL = (t = e.label) == null ? void 0 : t.name), I)];
      });
    }
    function Ga(e) {
      var t;
      return _ts_generator(this, function (_state) {
        return [2, ((_.LABEL = (t = e.label) == null ? void 0 : t.name), _)];
      });
    }
    function Ha(e, t) {
      var r;
      return _ts_generator(this, function (_state) {
        switch (_state.label) {
          case 0:
            r = e.label.name;
            if (!(e.body.type === "WhileStatement")) return [3, 2];
            return [5, _ts_values(Ui(e.body, t, { label: r }))];
          case 1:
            return [2, _state.sent()];
          case 2:
            if (!(e.body.type === "DoWhileStatement")) return [3, 4];
            return [5, _ts_values($i(e.body, t, { label: r }))];
          case 3:
            return [2, _state.sent()];
          case 4:
            if (!(e.body.type === "ForStatement")) return [3, 6];
            return [5, _ts_values(qi(e.body, t, { label: r }))];
          case 5:
            return [2, _state.sent()];
          case 6:
            if (!(e.body.type === "ForInStatement")) return [3, 8];
            return [5, _ts_values(Wi(e.body, t, { label: r }))];
          case 7:
            return [2, _state.sent()];
          case 8:
            if (!(e.body.type === "ForOfStatement")) return [3, 10];
            return [5, _ts_values(zi(e.body, t, { label: r }))];
          case 9:
            return [2, _state.sent()];
          case 10:
            if (!(e.body.type === "BlockStatement")) return [3, 12];
            return [5, _ts_values(ae(e.body, t, { label: r }))];
          case 11:
            return [2, _state.sent()];
          case 12:
            if (!(e.body.type === "WithStatement")) return [3, 14];
            return [5, _ts_values(Bi(e.body, t, { label: r }))];
          case 13:
            return [2, _state.sent()];
          case 14:
            if (!(e.body.type === "IfStatement")) return [3, 16];
            return [5, _ts_values(Oi(e.body, t, { label: r }))];
          case 15:
            return [2, _state.sent()];
          case 16:
            if (!(e.body.type === "SwitchStatement")) return [3, 18];
            return [5, _ts_values(Di(e.body, t, { label: r }))];
          case 17:
            return [2, _state.sent()];
          case 18:
            if (!(e.body.type === "TryStatement")) return [3, 20];
            return [5, _ts_values(Mi(e.body, t, { label: r }))];
          case 19:
            return [2, _state.sent()];
          case 20:
            throw new SyntaxError("".concat(e.body.type, " cannot be labeled"));
        }
      });
    }
    function Bi(e, t) {
      var r, i, _1, a;
      var _arguments = arguments;
      return _ts_generator(this, function (_state) {
        switch (_state.label) {
          case 0:
            r =
              _arguments.length > 2 && _arguments[2] !== void 0
                ? _arguments[2]
                : {};
            i = new P(t);
            _1 = i.with;
            return [5, _ts_values(d(e.object, t))];
          case 1:
            _1.apply(i, [_state.sent()]);
            return [5, _ts_values(d(e.body, i))];
          case 2:
            a = _state.sent();
            if (a === I)
              return [2, a.LABEL && a.LABEL === r.label ? void 0 : a];
            if (a === _ || a === E) return [2, a];
            return [2];
        }
      });
    }
    function Oi(e, t) {
      var r, i, _tmp;
      var _arguments = arguments;
      return _ts_generator(this, function (_state) {
        switch (_state.label) {
          case 0:
            r =
              _arguments.length > 2 && _arguments[2] !== void 0
                ? _arguments[2]
                : {};
            return [5, _ts_values(d(e.test, t))];
          case 1:
            if (!_state.sent()) return [3, 3];
            return [5, _ts_values(d(e.consequent, t))];
          case 2:
            _tmp = i = _state.sent();
            return [3, 5];
          case 3:
            return [5, _ts_values(d(e.alternate, t))];
          case 4:
            _tmp = i = _state.sent();
            _state.label = 5;
          case 5:
            if ((_tmp, i === I))
              return [2, i.LABEL && i.LABEL === r.label ? void 0 : i];
            if (i === _ || i === E) return [2, i];
            return [2];
        }
      });
    }
    function Di(e, t) {
      var r, i, a, s, n, _tmp, _tmp1, u;
      var _arguments = arguments;
      return _ts_generator(this, function (_state) {
        switch (_state.label) {
          case 0:
            r =
              _arguments.length > 2 && _arguments[2] !== void 0
                ? _arguments[2]
                : {};
            return [5, _ts_values(d(e.discriminant, t))];
          case 1:
            i = _state.sent();
            a = !1;
            s = 0;
            _state.label = 2;
          case 2:
            if (!(s < e.cases.length)) return [3, 8];
            n = e.cases[s];
            _tmp = !a;
            if (!_tmp) return [3, 5];
            _tmp1 = !n.test;
            if (_tmp1) return [3, 4];
            return [5, _ts_values(d(n.test, t))];
          case 3:
            _tmp1 = _state.sent() === i;
            _state.label = 4;
          case 4:
            _tmp = _tmp1;
            _state.label = 5;
          case 5:
            if (!(_tmp && (a = !0), a)) return [3, 7];
            return [5, _ts_values(Fi(n, t))];
          case 6:
            u = _state.sent();
            if (u === I) {
              if (u.LABEL === r.label) return [3, 8];
              return [2, u];
            }
            if (u === _ || u === E) return [2, u];
            _state.label = 7;
          case 7:
            s++;
            return [3, 2];
          case 8:
            return [2];
        }
      });
    }
    function Fi(e, t) {
      var r, i;
      return _ts_generator(this, function (_state) {
        switch (_state.label) {
          case 0:
            r = 0;
            _state.label = 1;
          case 1:
            if (!(r < e.consequent.length)) return [3, 4];
            return [5, _ts_values(d(e.consequent[r], t))];
          case 2:
            i = _state.sent();
            if (i === I || i === _ || i === E) return [2, i];
            _state.label = 3;
          case 3:
            r++;
            return [3, 1];
          case 4:
            return [2];
        }
      });
    }
    function Ka(e, t) {
      return _ts_generator(this, function (_state) {
        switch (_state.label) {
          case 0:
            return [5, _ts_values(d(e.argument, t))];
          case 1:
            throw _state.sent();
        }
      });
    }
    function Mi(e, t) {
      var r, i, a, s, n, u, _tmp;
      var _arguments = arguments;
      return _ts_generator(this, function (_state) {
        switch (_state.label) {
          case 0:
            r =
              _arguments.length > 2 && _arguments[2] !== void 0
                ? _arguments[2]
                : {};
            _state.label = 1;
          case 1:
            _state.trys.push([1, 3, 10, 13]);
            return [5, _ts_values(ae(e.block, t))];
          case 2:
            i = _state.sent();
            return [3, 13];
          case 3:
            a = _state.sent();
            if (!e.handler) return [3, 8];
            (s = new P(t)), (n = e.handler.param);
            if (!n) return [3, 6];
            if (!(n.type === "Identifier")) return [3, 4];
            u = n.name;
            s.var(u, a);
            return [3, 6];
          case 4:
            return [5, _ts_values(j(n, t, { feed: a }))];
          case 5:
            _state.sent();
            _state.label = 6;
          case 6:
            return [5, _ts_values(ji(e.handler, s))];
          case 7:
            i = _state.sent();
            return [3, 9];
          case 8:
            throw a;
          case 9:
            return [3, 13];
          case 10:
            _tmp = e.finalizer;
            if (!_tmp) return [3, 12];
            return [5, _ts_values(ae(e.finalizer, t))];
          case 11:
            _tmp = i = _state.sent();
            _state.label = 12;
          case 12:
            _tmp;
            return [7];
          case 13:
            if (i === I)
              return [2, i.LABEL && i.LABEL === r.label ? void 0 : i];
            if (i === _ || i === E) return [2, i];
            return [2];
        }
      });
    }
    function ji(e, t) {
      return _ts_generator(this, function (_state) {
        switch (_state.label) {
          case 0:
            return [5, _ts_values(ae(e.body, t, { invasived: !0 }))];
          case 1:
            return [2, _state.sent()];
        }
      });
    }
    function Ui(e, t) {
      var r, i;
      var _arguments = arguments;
      return _ts_generator(this, function (_state) {
        switch (_state.label) {
          case 0:
            r =
              _arguments.length > 2 && _arguments[2] !== void 0
                ? _arguments[2]
                : {};
            _state.label = 1;
          case 1:
            return [5, _ts_values(d(e.test, t))];
          case 2:
            if (!_state.sent()) return [3, 5];
            return [5, _ts_values(d(e.body, t))];
          case 3:
            i = _state.sent();
            if (i === I) {
              if (i.LABEL === r.label) return [3, 5];
              return [2, i];
            } else if (i === _) {
              if (i.LABEL === r.label) return [3, 4];
              return [2, i];
            } else if (i === E) return [2, i];
            _state.label = 4;
          case 4:
            return [3, 1];
          case 5:
            return [2];
        }
      });
    }
    function $i(e, t) {
      var r, i;
      var _arguments = arguments;
      return _ts_generator(this, function (_state) {
        switch (_state.label) {
          case 0:
            r =
              _arguments.length > 2 && _arguments[2] !== void 0
                ? _arguments[2]
                : {};
            _state.label = 1;
          case 1:
            return [5, _ts_values(d(e.body, t))];
          case 2:
            i = _state.sent();
            if (i === I) {
              if (i.LABEL === r.label) return [3, 5];
              return [2, i];
            } else if (i === _) {
              if (i.LABEL === r.label) return [3, 3];
              return [2, i];
            } else if (i === E) return [2, i];
            _state.label = 3;
          case 3:
            return [5, _ts_values(d(e.test, t))];
          case 4:
            if (_state.sent()) return [3, 1];
            _state.label = 5;
          case 5:
            return [2];
        }
      });
    }
    function qi(e, t) {
      var r, i, _tmp, a, s, _tmp1;
      var _arguments = arguments;
      return _ts_generator(this, function (_state) {
        switch (_state.label) {
          case 0:
            r =
              _arguments.length > 2 && _arguments[2] !== void 0
                ? _arguments[2]
                : {};
            i = new P(t);
            return [5, _ts_values(d(e.init, i))];
          case 1:
            _state.sent();
            _state.label = 2;
          case 2:
            _tmp = !e.test;
            if (_tmp) return [3, 4];
            return [5, _ts_values(d(e.test, i))];
          case 3:
            _tmp = _state.sent();
            _state.label = 4;
          case 4:
            if (!_tmp) return [3, 11];
            a = new P(i);
            s = void 0;
            if (!(e.body.type === "BlockStatement")) return [3, 6];
            return [5, _ts_values(ae(e.body, a, { invasived: !0 }))];
          case 5:
            _tmp1 = s = _state.sent();
            return [3, 8];
          case 6:
            return [5, _ts_values(d(e.body, a))];
          case 7:
            _tmp1 = s = _state.sent();
            _state.label = 8;
          case 8:
            if ((_tmp1, s === I)) {
              if (s.LABEL === r.label) return [3, 11];
              return [2, s];
            } else if (s === _) {
              if (s.LABEL === r.label) return [3, 9];
              return [2, s];
            } else if (s === E) return [2, s];
            _state.label = 9;
          case 9:
            return [5, _ts_values(d(e.update, i))];
          case 10:
            _state.sent();
            return [3, 2];
          case 11:
            return [2];
        }
      });
    }
    function Wi(e, t) {
      var r, _tmp, _tmp1, _i, i, a;
      var _arguments = arguments;
      return _ts_generator(this, function (_state) {
        switch (_state.label) {
          case 0:
            r =
              _arguments.length > 2 && _arguments[2] !== void 0
                ? _arguments[2]
                : {};
            _tmp = [];
            return [5, _ts_values(d(e.right, t))];
          case 1:
            for (_tmp1 in _state.sent()) _tmp.push(_tmp1);
            _i = 0;
            _state.label = 2;
          case 2:
            if (!(_i < _tmp.length)) return [3, 5];
            i = _tmp[_i];
            return [5, _ts_values(Tt(e, t, { value: i }))];
          case 3:
            a = _state.sent();
            if (a === I) {
              if (a.LABEL === r.label) return [3, 5];
              return [2, a];
            } else if (a === _) {
              if (a.LABEL === r.label) return [3, 4];
              return [2, a];
            } else if (a === E) return [2, a];
            _state.label = 4;
          case 4:
            _i++;
            return [3, 2];
          case 5:
            return [2];
        }
      });
    }
    function zi(e, t) {
      var r,
        i,
        _iteratorNormalCompletion,
        _didIteratorError,
        _iteratorError,
        a,
        s,
        n,
        _iterator,
        _step,
        a1,
        s1,
        err;
      var _arguments = arguments;
      return _ts_generator(this, function (_state) {
        switch (_state.label) {
          case 0:
            r =
              _arguments.length > 2 && _arguments[2] !== void 0
                ? _arguments[2]
                : {};
            return [5, _ts_values(d(e.right, t))];
          case 1:
            i = _state.sent();
            (_iteratorNormalCompletion = true),
              (_didIteratorError = false),
              (_iteratorError = undefined);
            if (!e.await) return [3, 8];
            a = Cr(i);
            me.RES = a.next();
            return [4, me];
          case 2:
            s = _state.sent();
            _state.label = 3;
          case 3:
            if (!!s.done) return [3, 7];
            return [5, _ts_values(Tt(e, t, { value: s.value }))];
          case 4:
            n = _state.sent();
            if (n === I) {
              if (n.LABEL === r.label) return [3, 7];
              return [2, n];
            } else if (n === _) {
              if (n.LABEL === r.label) return [3, 5];
              return [2, n];
            } else if (n === E) return [2, n];
            _state.label = 5;
          case 5:
            me.RES = a.next();
            return [4, me];
          case 6:
            s = _state.sent();
            return [3, 3];
          case 7:
            return [3, 15];
          case 8:
            _state.trys.push([8, 13, 14, 15]);
            _iterator = i[Symbol.iterator]();
            _state.label = 9;
          case 9:
            if (!!(_iteratorNormalCompletion = (_step = _iterator.next()).done))
              return [3, 12];
            a1 = _step.value;
            return [5, _ts_values(Tt(e, t, { value: a1 }))];
          case 10:
            s1 = _state.sent();
            if (s1 === I) {
              if (s1.LABEL === r.label) return [3, 12];
              return [2, s1];
            } else if (s1 === _) {
              if (s1.LABEL === r.label) return [3, 11];
              return [2, s1];
            } else if (s1 === E) return [2, s1];
            _state.label = 11;
          case 11:
            _iteratorNormalCompletion = true;
            return [3, 9];
          case 12:
            return [3, 15];
          case 13:
            err = _state.sent();
            _didIteratorError = true;
            _iteratorError = err;
            return [3, 15];
          case 14:
            try {
              if (!_iteratorNormalCompletion && _iterator.return != null) {
                _iterator.return();
              }
            } finally {
              if (_didIteratorError) {
                throw _iteratorError;
              }
            }
            return [7];
          case 15:
            return [2];
        }
      });
    }
    function Qa(e, t) {
      return _ts_generator(this, function (_state) {
        t.func(e.id.name, J(e, t));
        return [2];
      });
    }
    function xe(e, t) {
      var r, i;
      var _arguments = arguments;
      return _ts_generator(this, function (_state) {
        switch (_state.label) {
          case 0:
            r =
              _arguments.length > 2 && _arguments[2] !== void 0
                ? _arguments[2]
                : {};
            i = 0;
            _state.label = 1;
          case 1:
            if (!(i < e.declarations.length)) return [3, 4];
            return [
              5,
              _ts_values(Gi(e.declarations[i], t, N({ kind: e.kind }, r))),
            ];
          case 2:
            _state.sent();
            _state.label = 3;
          case 3:
            i++;
            return [3, 1];
          case 4:
            return [2];
        }
      });
    }
    function Gi(e, t) {
      var r, tmp, i, tmp1, a, tmp2, s, n, _tmp, _tmp1, u, l, _tmp2, c;
      var _arguments = arguments;
      return _ts_generator(this, function (_state) {
        switch (_state.label) {
          case 0:
            r =
              _arguments.length > 2 && _arguments[2] !== void 0
                ? _arguments[2]
                : {};
            (tmp = r.kind),
              (i = tmp === void 0 ? "var" : tmp),
              (tmp1 = r.hoist),
              (a = tmp1 === void 0 ? !1 : tmp1),
              (tmp2 = r.onlyBlock),
              (s = tmp2 === void 0 ? !1 : tmp2),
              (n = r.feed);
            if (!a) return [3, 5];
            _tmp = s || i === "var";
            if (!_tmp) return [3, 4];
            if (!(e.id.type === "Identifier")) return [3, 1];
            _tmp1 = t[i](e.id.name, s ? F : i === "var" ? O : void 0);
            return [3, 3];
          case 1:
            return [
              5,
              _ts_values(j(e.id, t, { kind: i, hoist: a, onlyBlock: s })),
            ];
          case 2:
            _tmp1 = _state.sent();
            _state.label = 3;
          case 3:
            _tmp = _tmp1;
            _state.label = 4;
          case 4:
            _tmp;
            return [3, 11];
          case 5:
            u = "feed" in r;
            if (!u) return [3, 6];
            _tmp2 = n;
            return [3, 8];
          case 6:
            return [5, _ts_values(d(e.init, t))];
          case 7:
            _tmp2 = _state.sent();
            _state.label = 8;
          case 8:
            l = _tmp2;
            if (!(e.id.type === "Identifier")) return [3, 9];
            c = e.id.name;
            i === "var" && !e.init && !u ? t.var(c, O) : t[i](c, l),
              e.init &&
                [
                  "ClassExpression",
                  "FunctionExpression",
                  "ArrowFunctionExpression",
                ].indexOf(e.init.type) !== -1 &&
                !l.name &&
                w(l, "name", { value: c, configurable: !0 });
            return [3, 11];
          case 9:
            return [5, _ts_values(j(e.id, t, { kind: i, feed: l }))];
          case 10:
            _state.sent();
            _state.label = 11;
          case 11:
            return [2];
        }
      });
    }
    function Xa(e, t) {
      var _, _tmp;
      return _ts_generator(this, function (_state) {
        switch (_state.label) {
          case 0:
            _ = t.func;
            _tmp = [e.id.name];
            return [5, _ts_values(We(e, t))];
          case 1:
            _.apply(t, _tmp.concat([_state.sent()]));
            return [2];
        }
      });
    }
    function Hi(e, t) {
      var r, i, a, s, n, _tmp, _tmp1, _tmp2;
      var _arguments = arguments;
      return _ts_generator(this, function (_state) {
        switch (_state.label) {
          case 0:
            r =
              _arguments.length > 2 && _arguments[2] !== void 0
                ? _arguments[2]
                : {};
            (i = r.klass), (a = r.superClass);
            s = 0;
            _state.label = 1;
          case 1:
            if (!(s < e.body.length)) return [3, 11];
            n = e.body[s];
            if (!(n.type === "MethodDefinition")) return [3, 3];
            return [5, _ts_values(Ki(n, t, { klass: i, superClass: a }))];
          case 2:
            _tmp = _state.sent();
            return [3, 9];
          case 3:
            if (!(n.type === "PropertyDefinition" && n.static)) return [3, 5];
            return [5, _ts_values(It(n, t, { klass: i, superClass: a }))];
          case 4:
            _tmp1 = _state.sent();
            return [3, 8];
          case 5:
            _tmp2 = n.type === "StaticBlock";
            if (!_tmp2) return [3, 7];
            return [5, _ts_values(Qi(n, t, { klass: i }))];
          case 6:
            _tmp2 = _state.sent();
            _state.label = 7;
          case 7:
            _tmp1 = _tmp2;
            _state.label = 8;
          case 8:
            _tmp = _tmp1;
            _state.label = 9;
          case 9:
            _tmp;
            _state.label = 10;
          case 10:
            s++;
            return [3, 1];
          case 11:
            return [2];
        }
      });
    }
    function Ki(e, t) {
      var r, i, a, s, n, u, l, c, c1;
      var _arguments = arguments;
      return _ts_generator(this, function (_state) {
        switch (_state.label) {
          case 0:
            r =
              _arguments.length > 2 && _arguments[2] !== void 0
                ? _arguments[2]
                : {};
            (i = r.klass), (a = r.superClass);
            n = !1;
            if (!e.computed) return [3, 2];
            return [5, _ts_values(d(e.key, t))];
          case 1:
            s = _state.sent();
            return [3, 3];
          case 2:
            if (e.key.type === "Identifier") s = e.key.name;
            else if (e.key.type === "PrivateIdentifier")
              (s = e.key.name), (n = !0);
            else throw new SyntaxError("Unexpected token");
            _state.label = 3;
          case 3:
            u = e.static ? i : i.prototype;
            n && (u[T] || w(u, T, { value: {} }), (u = u[T]));
            l = J(e.value, t, { superClass: a });
            switch (e.kind) {
              case "constructor":
                break;
              case "method":
                w(u, s, { value: l, writable: !0, configurable: !0 });
                break;
              case "get": {
                c = ue(u, s);
                w(u, s, { get: l, set: c && c.set, configurable: !0 });
                break;
              }
              case "set": {
                c1 = ue(u, s);
                w(u, s, { get: c1 && c1.get, set: l, configurable: !0 });
                break;
              }
              default:
                throw new SyntaxError("Unexpected token");
            }
            return [2];
        }
      });
    }
    function It(e, t) {
      var r, i, a, s, n, u, l, _tmp, _tmp1;
      var _arguments = arguments;
      return _ts_generator(this, function (_state) {
        switch (_state.label) {
          case 0:
            r =
              _arguments.length > 2 && _arguments[2] !== void 0
                ? _arguments[2]
                : {};
            (i = r.klass), (a = r.superClass);
            n = !1;
            if (!e.computed) return [3, 2];
            return [5, _ts_values(d(e.key, t))];
          case 1:
            s = _state.sent();
            return [3, 3];
          case 2:
            if (e.key.type === "Identifier") s = e.key.name;
            else if (e.key.type === "PrivateIdentifier")
              (s = e.key.name), (n = !0);
            else throw new SyntaxError("Unexpected token");
            _state.label = 3;
          case 3:
            u = new P(t, !0);
            u.const("this", i);
            l = i;
            n && (l[T] || w(l, T, { value: {} }), (l = l[T]));
            if (!e.value) return [3, 7];
            if (
              !(
                e.value.type === "FunctionExpression" ||
                e.value.type === "ArrowFunctionExpression"
              )
            )
              return [3, 4];
            _tmp1 = l[s] = J(e.value, u, { superClass: a });
            return [3, 6];
          case 4:
            return [5, _ts_values(d(e.value, u))];
          case 5:
            _tmp1 = l[s] = _state.sent();
            _state.label = 6;
          case 6:
            _tmp = _tmp1;
            return [3, 8];
          case 7:
            _tmp = l[s] = void 0;
            _state.label = 8;
          case 8:
            _tmp;
            return [2];
        }
      });
    }
    function Qi(e, t) {
      var r, i, a;
      var _arguments = arguments;
      return _ts_generator(this, function (_state) {
        switch (_state.label) {
          case 0:
            r =
              _arguments.length > 2 && _arguments[2] !== void 0
                ? _arguments[2]
                : {};
            (i = r.klass), (a = new P(t, !0));
            a.const("this", i);
            return [5, _ts_values(ae(e, a, { invasived: !0 }))];
          case 1:
            return [2, _state.sent()];
        }
      });
    }
    function Ya(e, t) {
      var i, a, s, s1, n, u;
      return _ts_generator(this, function (_state) {
        i = t.global().find(ge + e.source.value);
        if (i) {
          s = i.get();
          s &&
            (typeof s == "function"
              ? (a = s())
              : (typeof s === "undefined" ? "undefined" : _type_of(s)) ==
                  "object" && (a = s));
        }
        if (
          !a ||
          (typeof a === "undefined" ? "undefined" : _type_of(a)) != "object"
        )
          throw new TypeError(
            'Failed to resolve module specifier "'.concat(e.source.value, '"')
          );
        for (s1 = 0; s1 < e.specifiers.length; s1++) {
          n = e.specifiers[s1];
          u = void 0;
          if (
            (n.type === "ImportSpecifier"
              ? (u =
                  n.imported.type === "Identifier"
                    ? n.imported.name
                    : n.imported.value)
              : n.type === "ImportDefaultSpecifier"
              ? (u = "default")
              : n.type === "ImportNamespaceSpecifier" && (u = "*"),
            u !== "*" && !lt(a, u))
          )
            throw new SyntaxError(
              'The requested module "'
                .concat(e.source.value, '" does not provide an export named "')
                .concat(u, '"')
            );
          t.var(n.local.name, u === "*" ? N({}, a) : a[u]);
        }
        return [2];
      });
    }
    function Za(e, t) {
      var r, i, _tmp, _tmp1, a, s;
      return _ts_generator(this, function (_state) {
        switch (_state.label) {
          case 0:
            r = t.global();
            if (!(e.declaration.type === "FunctionDeclaration")) return [3, 1];
            _tmp =
              ((i = J(e.declaration, t)), t.func(e.declaration.id.name, i));
            return [3, 6];
          case 1:
            if (!(e.declaration.type === "ClassDeclaration")) return [3, 3];
            return [5, _ts_values(We(e.declaration, t))];
          case 2:
            _tmp1 = ((i = _state.sent()), t.func(e.declaration.id.name, i));
            return [3, 5];
          case 3:
            return [5, _ts_values(d(e.declaration, t))];
          case 4:
            _tmp1 = i = _state.sent();
            _state.label = 5;
          case 5:
            _tmp = _tmp1;
            _state.label = 6;
          case 6:
            _tmp;
            a = r.find(U);
            if (a) {
              s = a.get();
              s &&
                (typeof s === "undefined" ? "undefined" : _type_of(s)) ==
                  "object" &&
                (s.default = i);
            }
            return [2];
        }
      });
    }
    function Ja(e, t) {
      var r, i, a, s, i1, a1, s1, i2, a2, s2, n, u, i3, a3, s3, n1, u1, l;
      return _ts_generator(this, function (_state) {
        switch (_state.label) {
          case 0:
            r = t.global();
            if (!e.declaration) return [3, 6];
            if (!(e.declaration.type === "FunctionDeclaration")) return [3, 1];
            i = J(e.declaration, t);
            t.func(e.declaration.id.name, i);
            a = r.find(U);
            if (a) {
              s = a.get();
              s &&
                (typeof s === "undefined" ? "undefined" : _type_of(s)) ==
                  "object" &&
                (s[e.declaration.id.name] = i);
            }
            return [3, 5];
          case 1:
            if (!(e.declaration.type === "ClassDeclaration")) return [3, 3];
            return [5, _ts_values(We(e.declaration, t))];
          case 2:
            i1 = _state.sent();
            t.func(e.declaration.id.name, i1);
            a1 = r.find(U);
            if (a1) {
              s1 = a1.get();
              s1 &&
                (typeof s1 === "undefined" ? "undefined" : _type_of(s1)) ==
                  "object" &&
                (s1[e.declaration.id.name] = i1);
            }
            return [3, 5];
          case 3:
            if (!(e.declaration.type === "VariableDeclaration")) return [3, 5];
            return [5, _ts_values(xe(e.declaration, t))];
          case 4:
            _state.sent();
            i2 = r.find(U);
            if (i2) {
              a2 = i2.get();
              if (
                a2 &&
                (typeof a2 === "undefined" ? "undefined" : _type_of(a2)) ==
                  "object"
              )
                for (s2 = 0; s2 < e.declaration.declarations.length; s2++) {
                  (n = e.declaration.declarations[s2].id.name), (u = t.find(n));
                  u && (a2[n] = u.get());
                }
            }
            _state.label = 5;
          case 5:
            return [3, 7];
          case 6:
            if (e.specifiers) {
              i3 = r.find(U);
              if (i3) {
                a3 = i3.get();
                if (
                  a3 &&
                  (typeof a3 === "undefined" ? "undefined" : _type_of(a3)) ==
                    "object"
                )
                  for (s3 = 0; s3 < e.specifiers.length; s3++) {
                    (n1 = e.specifiers[s3]),
                      (u1 =
                        n1.local.type === "Identifier"
                          ? n1.local.name
                          : n1.local.value),
                      (l = t.find(u1));
                    l &&
                      (a3[
                        n1.exported.type === "Identifier"
                          ? n1.exported.name
                          : n1.exported.value
                      ] = l.get());
                  }
              }
            }
            _state.label = 7;
          case 7:
            return [2];
        }
      });
    }
    function es(e, t) {
      var r, i, a, n, s, n1;
      return _ts_generator(this, function (_state) {
        (r = t.global()), (i = r.find(ge + e.source.value));
        if (i) {
          n = i.get();
          n &&
            (typeof n == "function"
              ? (a = n())
              : (typeof n === "undefined" ? "undefined" : _type_of(n)) ==
                  "object" && (a = n));
        }
        if (
          !a ||
          (typeof a === "undefined" ? "undefined" : _type_of(a)) != "object"
        )
          throw new TypeError(
            'Failed to resolve module specifier "'.concat(e.source.value, '"')
          );
        s = r.find(U);
        if (s) {
          n1 = s.get();
          n1 &&
            (typeof n1 === "undefined" ? "undefined" : _type_of(n1)) ==
              "object" &&
            N(n1, a);
        }
        return [2];
      });
    }
    function pe(e, t) {
      var r =
        arguments.length > 2 && arguments[2] !== void 0 ? arguments[2] : {};
      var tmp = r.getVar,
        i = tmp === void 0 ? !1 : tmp,
        tmp1 = r.throwErr,
        a = tmp1 === void 0 ? !0 : tmp1;
      if (e.name === "undefined") return;
      var s = t.find(e.name);
      if (s) {
        if (i) return s;
        {
          var n = s.get();
          if (n === F)
            throw new ReferenceError("".concat(e.name, " is not defined"));
          return n;
        }
      } else {
        if (a) throw new ReferenceError("".concat(e.name, " is not defined"));
        return;
      }
    }
    var ts = Object.freeze(
      Object.defineProperty(
        { __proto__: null, Identifier: pe },
        Symbol.toStringTag,
        { value: "Module" }
      )
    );
    function Xi(e, t) {
      return e.value;
    }
    var is = Object.freeze(
      Object.defineProperty(
        { __proto__: null, Literal: Xi },
        Symbol.toStringTag,
        { value: "Module" }
      )
    );
    function rs(e, t) {
      var r = t.find(he);
      if (r && r.get() !== !0)
        throw new ReferenceError(
          "Must call super constructor in derived class before accessing 'this' or returning from derived constructor"
        );
      return t.find("this").get();
    }
    function as(e, t) {
      var r = [];
      for (var i = 0; i < e.elements.length; i++) {
        var a = e.elements[i];
        a.type === "SpreadElement" ? (r = r.concat($e(a, t))) : r.push(y(a, t));
      }
      return r;
    }
    function ss(e, t) {
      var r = {};
      for (var i = 0; i < e.properties.length; i++) {
        var a = e.properties[i];
        if (a.type === "SpreadElement") N(r, $e(a, t, { spreadProps: !0 }));
        else {
          var s = void 0;
          var n = a.key;
          a.computed
            ? (s = y(n, t))
            : n.type === "Identifier"
            ? (s = n.name)
            : (s = "" + Xi(n));
          var u = y(a.value, t),
            l = a.kind;
          if (l === "init") r[s] = u;
          else if (l === "get") {
            var c = ue(r, s);
            w(r, s, {
              get: u,
              set: c && c.set,
              enumerable: !0,
              configurable: !0,
            });
          } else {
            var c1 = ue(r, s);
            w(r, s, {
              get: c1 && c1.get,
              set: u,
              enumerable: !0,
              configurable: !0,
            });
          }
        }
      }
      return r;
    }
    function ns(e, t) {
      if (e.id && e.id.name) {
        var r = new P(t),
          i = Z(e, r);
        return r.const(e.id.name, i), i;
      } else return Z(e, t);
    }
    function os(e, t) {
      var r = e.argument;
      switch (e.operator) {
        case "+":
          return +y(r, t);
        case "-":
          return -y(r, t);
        case "!":
          return !y(r, t);
        case "~":
          return ~y(r, t);
        case "void":
          return void y(r, t);
        case "typeof":
          return r.type === "Identifier"
            ? _type_of(pe(r, t, { throwErr: !1 }))
            : _type_of(y(r, t));
        case "delete":
          if (r.type === "MemberExpression")
            return Ue(r, t, { getVar: !0 }).del();
          if (r.type === "Identifier")
            throw new SyntaxError(
              "Delete of an unqualified identifier in strict mode"
            );
          return y(r, t), !0;
        default:
          throw new SyntaxError("Unexpected token ".concat(e.operator));
      }
    }
    function us(e, t) {
      var r = e.argument;
      var i;
      if (r.type === "Identifier") i = pe(r, t, { getVar: !0 });
      else if (r.type === "MemberExpression") i = Ue(r, t, { getVar: !0 });
      else throw new SyntaxError("Unexpected token");
      var a = i.get();
      if (e.operator === "++") return i.set(a + 1), e.prefix ? i.get() : a;
      if (e.operator === "--") return i.set(a - 1), e.prefix ? i.get() : a;
      throw new SyntaxError("Unexpected token ".concat(e.operator));
    }
    function ls(e, t) {
      var r, i;
      switch (
        (e.left.type === "PrivateIdentifier"
          ? ((r = e.left.name), (i = y(e.right, t)), (i = i[T] || {}))
          : ((r = y(e.left, t)), (i = y(e.right, t))),
        e.operator)
      ) {
        case "==":
          return r == i;
        case "!=":
          return r != i;
        case "===":
          return r === i;
        case "!==":
          return r !== i;
        case "<":
          return r < i;
        case "<=":
          return r <= i;
        case ">":
          return r > i;
        case ">=":
          return r >= i;
        case "<<":
          return r << i;
        case ">>":
          return r >> i;
        case ">>>":
          return r >>> i;
        case "+":
          return r + i;
        case "-":
          return r - i;
        case "*":
          return r * i;
        case "**":
          return Math.pow(r, i);
        case "/":
          return r / i;
        case "%":
          return r % i;
        case "|":
          return r | i;
        case "^":
          return r ^ i;
        case "&":
          return r & i;
        case "in":
          return r in i;
        case "instanceof":
          return _instanceof(r, i);
        default:
          throw new SyntaxError("Unexpected token ".concat(e.operator));
      }
    }
    function cs(e, t) {
      var r = e.left;
      var i;
      if (r.type === "Identifier") {
        if (((i = pe(r, t, { getVar: !0, throwErr: !1 })), !i)) {
          var s = t.global().find("window").get();
          i = new fe(s, r.name);
        }
      } else if (r.type === "MemberExpression") i = Ue(r, t, { getVar: !0 });
      else {
        var s1 = y(e.right, t);
        return M(r, t, { feed: s1 });
      }
      var a = y(e.right, t);
      switch (e.operator) {
        case "=":
          return i.set(a), i.get();
        case "+=":
          return i.set(i.get() + a), i.get();
        case "-=":
          return i.set(i.get() - a), i.get();
        case "*=":
          return i.set(i.get() * a), i.get();
        case "/=":
          return i.set(i.get() / a), i.get();
        case "%=":
          return i.set(i.get() % a), i.get();
        case "**=":
          return i.set(Math.pow(i.get(), a)), i.get();
        case "<<=":
          return i.set(i.get() << a), i.get();
        case ">>=":
          return i.set(i.get() >> a), i.get();
        case ">>>=":
          return i.set(i.get() >>> a), i.get();
        case "|=":
          return i.set(i.get() | a), i.get();
        case "^=":
          return i.set(i.get() ^ a), i.get();
        case "&=":
          return i.set(i.get() & a), i.get();
        case "??=":
          var _i_get;
          return (
            i.set(
              (_i_get = i.get()) !== null && _i_get !== void 0 ? _i_get : a
            ),
            i.get()
          );
        case "&&=":
          return i.set(i.get() && a), i.get();
        case "||=":
          return i.set(i.get() || a), i.get();
        default:
          throw new SyntaxError("Unexpected token ".concat(e.operator));
      }
    }
    function hs(e, t) {
      switch (e.operator) {
        case "||":
          return y(e.left, t) || y(e.right, t);
        case "&&":
          return y(e.left, t) && y(e.right, t);
        case "??":
          var _y;
          return (_y = y(e.left, t)) !== null && _y !== void 0
            ? _y
            : y(e.right, t);
        default:
          throw new SyntaxError("Unexpected token ".concat(e.operator));
      }
    }
    function Ue(e, t) {
      var r =
        arguments.length > 2 && arguments[2] !== void 0 ? arguments[2] : {};
      var tmp = r.getObj,
        i = tmp === void 0 ? !1 : tmp,
        tmp1 = r.getVar,
        a = tmp1 === void 0 ? !1 : tmp1;
      var s;
      if (
        (e.object.type === "Super"
          ? (s = Zi(e.object, t, { getProto: !0 }))
          : (s = y(e.object, t)),
        i)
      )
        return s;
      var n,
        u = !1;
      if (
        (e.computed
          ? (n = y(e.property, t))
          : e.property.type === "PrivateIdentifier"
          ? ((n = e.property.name), (u = !0))
          : (n = e.property.name),
        u && (s = s[T]),
        a)
      ) {
        var l = jt(s, n);
        if (e.object.type === "Super" && l) {
          var c = t.find("this").get(),
            h = R(n);
          return w(c, h, { set: l }), new fe(c, h);
        } else return new fe(s, n);
      } else {
        var l1 = Mt(s, n);
        if (e.object.type === "Super" && l1) {
          var c1 = t.find("this").get();
          return e.optional && c1 == null ? void 0 : l1.call(c1);
        } else return e.optional && s == null ? void 0 : s[n];
      }
    }
    function fs(e, t) {
      return y(e.test, t) ? y(e.consequent, t) : y(e.alternate, t);
    }
    function ps(e, t) {
      var r, i;
      if (e.callee.type === "MemberExpression") {
        if (
          ((i = Ue(e.callee, t, { getObj: !0 })),
          e.callee.optional && i == null)
        )
          return;
        var _$s,
          n = !1;
        e.callee.computed
          ? (_$s = y(e.callee.property, t))
          : e.callee.property.type === "PrivateIdentifier"
          ? ((_$s = e.callee.property.name), (n = !0))
          : (_$s = e.callee.property.name);
        var u = i;
        if ((n && (u = u[T]), e.callee.object.type === "Super")) {
          var l = t.find("this").get();
          r = u[_$s].bind(l);
        } else r = u[_$s];
        if (e.optional && r == null) return;
        if (typeof r != "function")
          throw new TypeError("".concat(_$s, " is not a function"));
        if (_e in r)
          throw new TypeError(
            "Class constructor ".concat(_$s, " cannot be invoked without 'new'")
          );
      } else {
        if (
          ((i = t.find("this").get()),
          (r = y(e.callee, t)),
          e.optional && r == null)
        )
          return;
        if (typeof r != "function" || (e.callee.type !== "Super" && _e in r)) {
          var _$s1;
          if (e.callee.type === "Identifier") _$s1 = e.callee.name;
          else
            try {
              _$s1 = JSON.stringify(r);
            } catch (e) {
              _$s1 = "" + r;
            }
          throw typeof r != "function"
            ? new TypeError("".concat(_$s1, " is not a function"))
            : new TypeError(
                "Class constructor ".concat(
                  _$s1,
                  " cannot be invoked without 'new'"
                )
              );
        }
      }
      var a = [];
      for (var _$s2 = 0; _$s2 < e.arguments.length; _$s2++) {
        var n1 = e.arguments[_$s2];
        n1.type === "SpreadElement"
          ? (a = a.concat($e(n1, t)))
          : a.push(y(n1, t));
      }
      if (e.callee.type === "Super") {
        var n2 = t.find(he).get();
        if (n2 === !0)
          throw new ReferenceError("Super constructor may only be called once");
        var u1 = Ge(i, r, a);
        return n2(u1), t.find("this").set(u1), t.find(he).set(!0), u1;
      }
      try {
        return r.apply(i, a);
      } catch (s) {
        if (
          _instanceof(s, TypeError) &&
          s.message === "Illegal invocation" &&
          r.toString().indexOf("[native code]") !== -1
        ) {
          var n3 = t.global().find("window").get();
          if (n3 && n3[Ne]) return r.apply(n3[Ne], a);
        }
        throw s;
      }
    }
    function ds(e, t) {
      var r = y(e.callee, t);
      if (typeof r != "function") {
        var a;
        if (e.callee.type === "Identifier") a = e.callee.name;
        else
          try {
            a = JSON.stringify(r);
          } catch (e) {
            a = "" + r;
          }
        throw new TypeError("".concat(a, " is not a constructor"));
      } else if (r[nt]) throw new TypeError("".concat(r.name || "(intermediate value)", " is not a constructor"));
      var i = [];
      for (var a1 = 0; a1 < e.arguments.length; a1++) {
        var s = e.arguments[a1];
        s.type === "SpreadElement" ? (i = i.concat($e(s, t))) : i.push(y(s, t));
      }
      return _construct(r, _to_consumable_array(i));
    }
    function ys(e, t) {
      if (e.meta.name === "new" && e.property.name === "target")
        return t.find(ot).get();
      if (e.meta.name === "import" && e.property.name === "meta")
        return { url: "" };
    }
    function ms(e, t) {
      var r;
      for (var i = 0; i < e.expressions.length; i++) r = y(e.expressions[i], t);
      return r;
    }
    function gs(e, t) {
      return Z(e, t);
    }
    function xs(e, t) {
      var r = e.quasis.slice(),
        i = e.expressions.slice();
      var a = "",
        s,
        n;
      for (; (s = r.shift()); )
        (a += Yi(s)), (n = i.shift()), n && (a += y(n, t));
      return a;
    }
    function bs(e, t) {
      var r = y(e.tag, t),
        i = e.quasi.quasis,
        a = i.map(function (l) {
          return l.value.cooked;
        }),
        s = i.map(function (l) {
          return l.value.raw;
        });
      w(a, "raw", { value: ze(s) });
      var n = e.quasi.expressions,
        u = [];
      if (n) for (var l = 0; l < n.length; l++) u.push(y(n[l], t));
      return r.apply(void 0, [ze(a)].concat(_to_consumable_array(u)));
    }
    function Yi(e, t) {
      return e.value.raw;
    }
    function vs(e, t) {
      if (e.id && e.id.name) {
        var r = new P(t),
          i = qe(e, r);
        return r.const(e.id.name, i), i;
      } else return qe(e, t);
    }
    function Zi(e, t) {
      var r =
        arguments.length > 2 && arguments[2] !== void 0 ? arguments[2] : {};
      var tmp = r.getProto,
        i = tmp === void 0 ? !1 : tmp,
        a = t.find(st).get();
      return i ? a.prototype : a;
    }
    function $e(e, t) {
      var r =
        arguments.length > 2 && arguments[2] !== void 0 ? arguments[2] : {};
      var i = y(e.argument, t);
      if (r.spreadProps) return i;
      if (
        typeof Symbol == "function" &&
        typeof i[Symbol.iterator] != "function"
      )
        throw new TypeError(
          "Spread syntax requires ...iterable[Symbol.iterator] to be a function"
        );
      return _to_consumable_array(i);
    }
    function Ss(e, t) {
      return y(e.expression, t);
    }
    function ws(e, t) {
      var r = t.global(),
        i = y(e.source, t),
        a = r.find(ge + i);
      var s;
      if (a) {
        var n = a.get();
        n &&
          (typeof n == "function"
            ? (s = n())
            : (typeof n === "undefined" ? "undefined" : _type_of(n)) ==
                "object" && (s = n));
      }
      return !s ||
        (typeof s === "undefined" ? "undefined" : _type_of(s)) != "object"
        ? Promise.reject(
            new TypeError('Failed to resolve module specifier "'.concat(i, '"'))
          )
        : Promise.resolve(s);
    }
    var ks = Object.freeze(
      Object.defineProperty(
        {
          __proto__: null,
          ArrayExpression: as,
          ArrowFunctionExpression: gs,
          AssignmentExpression: cs,
          BinaryExpression: ls,
          CallExpression: ps,
          ChainExpression: Ss,
          ClassExpression: vs,
          ConditionalExpression: fs,
          FunctionExpression: ns,
          ImportExpression: ws,
          LogicalExpression: hs,
          MemberExpression: Ue,
          MetaProperty: ys,
          NewExpression: ds,
          ObjectExpression: ss,
          SequenceExpression: ms,
          SpreadElement: $e,
          Super: Zi,
          TaggedTemplateExpression: bs,
          TemplateElement: Yi,
          TemplateLiteral: xs,
          ThisExpression: rs,
          UnaryExpression: os,
          UpdateExpression: us,
        },
        Symbol.toStringTag,
        { value: "Module" }
      )
    );
    function Ji(e, t) {
      var r =
        arguments.length > 2 && arguments[2] !== void 0 ? arguments[2] : {};
      var tmp = r.kind,
        i = tmp === void 0 ? "var" : tmp,
        tmp1 = r.hoist,
        a = tmp1 === void 0 ? !1 : tmp1,
        tmp2 = r.onlyBlock,
        s = tmp2 === void 0 ? !1 : tmp2,
        tmp3 = r.feed,
        n = tmp3 === void 0 ? {} : tmp3,
        u = [];
      for (var l = 0; l < e.properties.length; l++) {
        var c = e.properties[l];
        if (a) {
          if (s || i === "var")
            if (c.type === "Property") {
              var h = c.value;
              h.type === "Identifier"
                ? t[i](h.name, s ? F : i === "var" ? O : void 0)
                : M(h, t, { kind: i, hoist: a, onlyBlock: s });
            } else Pe(c, t, { kind: i, hoist: a, onlyBlock: s });
        } else if (c.type === "Property") {
          var h1 = void 0;
          c.computed ? (h1 = y(c.key, t)) : (h1 = c.key.name), u.push(h1);
          var p = c.value;
          p.type === "Identifier"
            ? t[i](p.name, n[h1])
            : M(p, t, { kind: i, feed: n[h1] });
        } else {
          var h2 = N({}, n);
          for (var p1 = 0; p1 < u.length; p1++) delete h2[u[p1]];
          Pe(c, t, { kind: i, feed: h2 });
        }
      }
    }
    function er(e, t) {
      var r =
        arguments.length > 2 && arguments[2] !== void 0 ? arguments[2] : {};
      var i = r.kind,
        tmp = r.hoist,
        a = tmp === void 0 ? !1 : tmp,
        tmp1 = r.onlyBlock,
        s = tmp1 === void 0 ? !1 : tmp1,
        tmp2 = r.feed,
        n = tmp2 === void 0 ? [] : tmp2,
        u = [];
      for (var l = 0; l < e.elements.length; l++) {
        var c = e.elements[l];
        if (c)
          if (a)
            (s || i === "var") &&
              (c.type === "Identifier"
                ? t[i](c.name, s ? F : i === "var" ? O : void 0)
                : M(c, t, { kind: i, hoist: a, onlyBlock: s }));
          else if (c.type === "Identifier")
            if (i) t[i](c.name, n[l]);
            else {
              var h = pe(c, t, { getVar: !0 });
              h.set(n[l]), u.push(h.get());
            }
          else
            c.type === "RestElement"
              ? Pe(c, t, { kind: i, feed: n.slice(l) })
              : M(c, t, { kind: i, feed: n[l] });
      }
      if (u.length) return u;
    }
    function Pe(e, t) {
      var r =
        arguments.length > 2 && arguments[2] !== void 0 ? arguments[2] : {};
      var i = r.kind,
        tmp = r.hoist,
        a = tmp === void 0 ? !1 : tmp,
        tmp1 = r.onlyBlock,
        s = tmp1 === void 0 ? !1 : tmp1,
        tmp2 = r.feed,
        n = tmp2 === void 0 ? [] : tmp2,
        u = e.argument;
      a
        ? (s || i === "var") &&
          (u.type === "Identifier"
            ? t[i](u.name, s ? F : i === "var" ? O : void 0)
            : M(u, t, { kind: i, hoist: a, onlyBlock: s }))
        : u.type === "Identifier"
        ? i
          ? t[i](u.name, n)
          : pe(u, t, { getVar: !0 }).set(n)
        : M(u, t, { kind: i, feed: n });
    }
    function tr(e, t) {
      var r =
        arguments.length > 2 && arguments[2] !== void 0 ? arguments[2] : {};
      var tmp = r.kind,
        i = tmp === void 0 ? "var" : tmp,
        tmp1 = r.hoist,
        a = tmp1 === void 0 ? !1 : tmp1,
        tmp2 = r.onlyBlock,
        s = tmp2 === void 0 ? !1 : tmp2,
        tmp3 = r.feed,
        n = tmp3 === void 0 ? y(e.right, t) : tmp3,
        u = e.left;
      a
        ? (s || i === "var") &&
          (u.type === "Identifier"
            ? t[i](u.name, s ? F : i === "var" ? O : void 0)
            : M(u, t, { kind: i, hoist: a, onlyBlock: s }))
        : u.type === "Identifier"
        ? t[i](u.name, n)
        : M(u, t, { kind: i, feed: n });
    }
    var Es = Object.freeze(
      Object.defineProperty(
        {
          __proto__: null,
          ArrayPattern: er,
          AssignmentPattern: tr,
          ObjectPattern: Ji,
          RestElement: Pe,
        },
        Symbol.toStringTag,
        { value: "Module" }
      )
    );
    function Cs(e, t) {
      for (var r = 0; r < e.body.length; r++) y(e.body[r], t);
    }
    var _s = Object.freeze(
      Object.defineProperty(
        { __proto__: null, Program: Cs },
        Symbol.toStringTag,
        { value: "Module" }
      )
    );
    var At;
    function y(e, t) {
      if (!e) return;
      At || (At = N({}, br, ks, ts, xr, is, Es, _s));
      var r = At[e.type];
      if (r) return r(e, t);
      throw new Error("".concat(e.type, " isn't implemented"));
    }
    function Is(e, t) {
      y(e.expression, t);
    }
    function se(e, t) {
      var r =
        arguments.length > 2 && arguments[2] !== void 0 ? arguments[2] : {};
      var tmp = r.invasived,
        i = tmp === void 0 ? !1 : tmp,
        tmp1 = r.hoisted,
        a = tmp1 === void 0 ? !1 : tmp1,
        s = i ? t : new P(t);
      a || Lt(e, s, { onlyBlock: !0 });
      for (var n = 0; n < e.body.length; n++) {
        var u = y(e.body[n], s);
        if (u === I) {
          if (u.LABEL && u.LABEL === r.label) break;
          return u;
        }
        if (u === _ || u === E) return u;
      }
    }
    function As() {}
    function Ps() {
      debugger;
    }
    function Ls(e, t) {
      return (E.RES = e.argument ? y(e.argument, t) : void 0), E;
    }
    function Vs(e) {
      var t;
      return (I.LABEL = (t = e.label) == null ? void 0 : t.name), I;
    }
    function Ts(e) {
      var t;
      return (_.LABEL = (t = e.label) == null ? void 0 : t.name), _;
    }
    function Ns(e, t) {
      var r = e.label.name;
      if (e.body.type === "WhileStatement") return ur(e.body, t, { label: r });
      if (e.body.type === "DoWhileStatement")
        return lr(e.body, t, { label: r });
      if (e.body.type === "ForStatement") return cr(e.body, t, { label: r });
      if (e.body.type === "ForInStatement") return hr(e.body, t, { label: r });
      if (e.body.type === "ForOfStatement") return fr(e.body, t, { label: r });
      if (e.body.type === "BlockStatement") return se(e.body, t, { label: r });
      if (e.body.type === "WithStatement") return ir(e.body, t, { label: r });
      if (e.body.type === "IfStatement") return rr(e.body, t, { label: r });
      if (e.body.type === "SwitchStatement") return ar(e.body, t, { label: r });
      if (e.body.type === "TryStatement") return nr(e.body, t, { label: r });
      throw new SyntaxError("".concat(e.body.type, " cannot be labeled"));
    }
    function ir(e, t) {
      var r =
        arguments.length > 2 && arguments[2] !== void 0 ? arguments[2] : {};
      var i = new P(t);
      i.with(y(e.object, t));
      var a = y(e.body, i);
      if (a === I) return a.LABEL && a.LABEL === r.label ? void 0 : a;
      if (a === _ || a === E) return a;
    }
    function rr(e, t) {
      var r =
        arguments.length > 2 && arguments[2] !== void 0 ? arguments[2] : {};
      var i;
      if (
        (y(e.test, t) ? (i = y(e.consequent, t)) : (i = y(e.alternate, t)),
        i === I)
      )
        return i.LABEL && i.LABEL === r.label ? void 0 : i;
      if (i === _ || i === E) return i;
    }
    function ar(e, t) {
      var r =
        arguments.length > 2 && arguments[2] !== void 0 ? arguments[2] : {};
      var i = y(e.discriminant, t);
      var a = !1;
      for (var s = 0; s < e.cases.length; s++) {
        var n = e.cases[s];
        if ((!a && (!n.test || y(n.test, t) === i) && (a = !0), a)) {
          var u = sr(n, t);
          if (u === I) {
            if (u.LABEL === r.label) break;
            return u;
          }
          if (u === _ || u === E) return u;
        }
      }
    }
    function sr(e, t) {
      for (var r = 0; r < e.consequent.length; r++) {
        var i = y(e.consequent[r], t);
        if (i === I || i === _ || i === E) return i;
      }
    }
    function Rs(e, t) {
      throw y(e.argument, t);
    }
    function nr(e, t) {
      var r =
        arguments.length > 2 && arguments[2] !== void 0 ? arguments[2] : {};
      var i;
      try {
        i = se(e.block, t);
      } catch (a) {
        if (e.handler) {
          var s = new P(t),
            n = e.handler.param;
          if (n)
            if (n.type === "Identifier") {
              var u = n.name;
              s.var(u, a);
            } else M(n, t, { feed: a });
          i = or(e.handler, s);
        } else throw a;
      } finally {
        e.finalizer && (i = se(e.finalizer, t));
      }
      if (i === I) return i.LABEL && i.LABEL === r.label ? void 0 : i;
      if (i === _ || i === E) return i;
    }
    function or(e, t) {
      return se(e.body, t, { invasived: !0 });
    }
    function ur(e, t) {
      var r =
        arguments.length > 2 && arguments[2] !== void 0 ? arguments[2] : {};
      for (; y(e.test, t); ) {
        var i = y(e.body, t);
        if (i === I) {
          if (i.LABEL === r.label) break;
          return i;
        } else if (i === _) {
          if (i.LABEL === r.label) continue;
          return i;
        } else if (i === E) return i;
      }
    }
    function lr(e, t) {
      var r =
        arguments.length > 2 && arguments[2] !== void 0 ? arguments[2] : {};
      do {
        var i = y(e.body, t);
        if (i === I) {
          if (i.LABEL === r.label) break;
          return i;
        } else if (i === _) {
          if (i.LABEL === r.label) continue;
          return i;
        } else if (i === E) return i;
      } while (y(e.test, t));
    }
    function cr(e, t) {
      var r =
        arguments.length > 2 && arguments[2] !== void 0 ? arguments[2] : {};
      var i = new P(t);
      for (y(e.init, i); !e.test || y(e.test, i); y(e.update, i)) {
        var a = new P(i);
        var s = void 0;
        if (
          (e.body.type === "BlockStatement"
            ? (s = se(e.body, a, { invasived: !0 }))
            : (s = y(e.body, a)),
          s === I)
        ) {
          if (s.LABEL === r.label) break;
          return s;
        } else if (s === _) {
          if (s.LABEL === r.label) continue;
          return s;
        } else if (s === E) return s;
      }
    }
    function hr(e, t) {
      var r =
        arguments.length > 2 && arguments[2] !== void 0 ? arguments[2] : {};
      for (var i in y(e.right, t)) {
        var a = gr(e, t, { value: i });
        if (a === I) {
          if (a.LABEL === r.label) break;
          return a;
        } else if (a === _) {
          if (a.LABEL === r.label) continue;
          return a;
        } else if (a === E) return a;
      }
    }
    function fr(e, t) {
      var r =
        arguments.length > 2 && arguments[2] !== void 0 ? arguments[2] : {};
      var i = y(e.right, t);
      var _iteratorNormalCompletion = true,
        _didIteratorError = false,
        _iteratorError = undefined;
      try {
        for (
          var _iterator = i[Symbol.iterator](), _step;
          !(_iteratorNormalCompletion = (_step = _iterator.next()).done);
          _iteratorNormalCompletion = true
        ) {
          var a = _step.value;
          var s = gr(e, t, { value: a });
          if (s === I) {
            if (s.LABEL === r.label) break;
            return s;
          } else if (s === _) {
            if (s.LABEL === r.label) continue;
            return s;
          } else if (s === E) return s;
        }
      } catch (err) {
        _didIteratorError = true;
        _iteratorError = err;
      } finally {
        try {
          if (!_iteratorNormalCompletion && _iterator.return != null) {
            _iterator.return();
          }
        } finally {
          if (_didIteratorError) {
            throw _iteratorError;
          }
        }
      }
    }
    function Bs(e, t) {
      t.func(e.id.name, Z(e, t));
    }
    function be(e, t) {
      var r =
        arguments.length > 2 && arguments[2] !== void 0 ? arguments[2] : {};
      for (var i = 0; i < e.declarations.length; i++)
        pr(e.declarations[i], t, N({ kind: e.kind }, r));
    }
    function pr(e, t) {
      var r =
        arguments.length > 2 && arguments[2] !== void 0 ? arguments[2] : {};
      var tmp = r.kind,
        i = tmp === void 0 ? "var" : tmp,
        tmp1 = r.hoist,
        a = tmp1 === void 0 ? !1 : tmp1,
        tmp2 = r.onlyBlock,
        s = tmp2 === void 0 ? !1 : tmp2,
        n = r.feed;
      if (a)
        (s || i === "var") &&
          (e.id.type === "Identifier"
            ? t[i](e.id.name, s ? F : i === "var" ? O : void 0)
            : M(e.id, t, { kind: i, hoist: a, onlyBlock: s }));
      else {
        var u = "feed" in r,
          l = u ? n : y(e.init, t);
        if (e.id.type === "Identifier") {
          var c = e.id.name;
          i === "var" && !e.init && !u ? t.var(c, O) : t[i](c, l),
            e.init &&
              [
                "ClassExpression",
                "FunctionExpression",
                "ArrowFunctionExpression",
              ].indexOf(e.init.type) !== -1 &&
              !l.name &&
              w(l, "name", { value: c, configurable: !0 });
        } else M(e.id, t, { kind: i, feed: l });
      }
    }
    function Os(e, t) {
      t.func(e.id.name, qe(e, t));
    }
    function dr(e, t) {
      var r =
        arguments.length > 2 && arguments[2] !== void 0 ? arguments[2] : {};
      var i = r.klass,
        a = r.superClass;
      for (var s = 0; s < e.body.length; s++) {
        var n = e.body[s];
        n.type === "MethodDefinition"
          ? yr(n, t, { klass: i, superClass: a })
          : n.type === "PropertyDefinition" && n.static
          ? Pt(n, t, { klass: i, superClass: a })
          : n.type === "StaticBlock" && mr(n, t, { klass: i });
      }
    }
    function yr(e, t) {
      var r =
        arguments.length > 2 && arguments[2] !== void 0 ? arguments[2] : {};
      var i = r.klass,
        a = r.superClass;
      var s,
        n = !1;
      if (e.computed) s = y(e.key, t);
      else if (e.key.type === "Identifier") s = e.key.name;
      else if (e.key.type === "PrivateIdentifier") (s = e.key.name), (n = !0);
      else throw new SyntaxError("Unexpected token");
      var u = e.static ? i : i.prototype;
      n && (u[T] || w(u, T, { value: {} }), (u = u[T]));
      var l = Z(e.value, t, { superClass: a });
      switch (e.kind) {
        case "constructor":
          break;
        case "method":
          w(u, s, { value: l, writable: !0, configurable: !0 });
          break;
        case "get": {
          var c = ue(u, s);
          w(u, s, { get: l, set: c && c.set, configurable: !0 });
          break;
        }
        case "set": {
          var c1 = ue(u, s);
          w(u, s, { get: c1 && c1.get, set: l, configurable: !0 });
          break;
        }
        default:
          throw new SyntaxError("Unexpected token");
      }
    }
    function Pt(e, t) {
      var r =
        arguments.length > 2 && arguments[2] !== void 0 ? arguments[2] : {};
      var i = r.klass,
        a = r.superClass;
      var s,
        n = !1;
      if (e.computed) s = y(e.key, t);
      else if (e.key.type === "Identifier") s = e.key.name;
      else if (e.key.type === "PrivateIdentifier") (s = e.key.name), (n = !0);
      else throw new SyntaxError("Unexpected token");
      var u = new P(t, !0);
      u.const("this", i);
      var l = i;
      n && (l[T] || w(l, T, { value: {} }), (l = l[T])),
        e.value
          ? e.value.type === "FunctionExpression" ||
            e.value.type === "ArrowFunctionExpression"
            ? (l[s] = Z(e.value, u, { superClass: a }))
            : (l[s] = y(e.value, u))
          : (l[s] = void 0);
    }
    function mr(e, t) {
      var r =
        arguments.length > 2 && arguments[2] !== void 0 ? arguments[2] : {};
      var i = r.klass,
        a = new P(t, !0);
      return a.const("this", i), se(e, a, { invasived: !0 });
    }
    function Ds(e, t) {
      var i = t.global().find(ge + e.source.value);
      var a;
      if (i) {
        var s = i.get();
        s &&
          (typeof s == "function"
            ? (a = s())
            : (typeof s === "undefined" ? "undefined" : _type_of(s)) ==
                "object" && (a = s));
      }
      if (
        !a ||
        (typeof a === "undefined" ? "undefined" : _type_of(a)) != "object"
      )
        throw new TypeError(
          'Failed to resolve module specifier "'.concat(e.source.value, '"')
        );
      for (var s1 = 0; s1 < e.specifiers.length; s1++) {
        var n = e.specifiers[s1];
        var u = void 0;
        if (
          (n.type === "ImportSpecifier"
            ? (u =
                n.imported.type === "Identifier"
                  ? n.imported.name
                  : n.imported.value)
            : n.type === "ImportDefaultSpecifier"
            ? (u = "default")
            : n.type === "ImportNamespaceSpecifier" && (u = "*"),
          u !== "*" && !lt(a, u))
        )
          throw new SyntaxError(
            'The requested module "'
              .concat(e.source.value, '" does not provide an export named "')
              .concat(u, '"')
          );
        t.var(n.local.name, u === "*" ? N({}, a) : a[u]);
      }
    }
    function Fs(e, t) {
      var r = t.global();
      var i;
      e.declaration.type === "FunctionDeclaration"
        ? ((i = Z(e.declaration, t)), t.func(e.declaration.id.name, i))
        : e.declaration.type === "ClassDeclaration"
        ? ((i = qe(e.declaration, t)), t.func(e.declaration.id.name, i))
        : (i = y(e.declaration, t));
      var a = r.find(U);
      if (a) {
        var s = a.get();
        s &&
          (typeof s === "undefined" ? "undefined" : _type_of(s)) == "object" &&
          (s.default = i);
      }
    }
    function Ms(e, t) {
      var r = t.global();
      if (e.declaration) {
        if (e.declaration.type === "FunctionDeclaration") {
          var i = Z(e.declaration, t);
          t.func(e.declaration.id.name, i);
          var a = r.find(U);
          if (a) {
            var s = a.get();
            s &&
              (typeof s === "undefined" ? "undefined" : _type_of(s)) ==
                "object" &&
              (s[e.declaration.id.name] = i);
          }
        } else if (e.declaration.type === "ClassDeclaration") {
          var i1 = qe(e.declaration, t);
          t.func(e.declaration.id.name, i1);
          var a1 = r.find(U);
          if (a1) {
            var s1 = a1.get();
            s1 &&
              (typeof s1 === "undefined" ? "undefined" : _type_of(s1)) ==
                "object" &&
              (s1[e.declaration.id.name] = i1);
          }
        } else if (e.declaration.type === "VariableDeclaration") {
          be(e.declaration, t);
          var i2 = r.find(U);
          if (i2) {
            var a2 = i2.get();
            if (
              a2 &&
              (typeof a2 === "undefined" ? "undefined" : _type_of(a2)) ==
                "object"
            )
              for (var s2 = 0; s2 < e.declaration.declarations.length; s2++) {
                var n = e.declaration.declarations[s2].id.name,
                  u = t.find(n);
                u && (a2[n] = u.get());
              }
          }
        }
      } else if (e.specifiers) {
        var i3 = r.find(U);
        if (i3) {
          var a3 = i3.get();
          if (
            a3 &&
            (typeof a3 === "undefined" ? "undefined" : _type_of(a3)) == "object"
          )
            for (var s3 = 0; s3 < e.specifiers.length; s3++) {
              var n1 = e.specifiers[s3],
                u1 =
                  n1.local.type === "Identifier"
                    ? n1.local.name
                    : n1.local.value,
                l = t.find(u1);
              l &&
                (a3[
                  n1.exported.type === "Identifier"
                    ? n1.exported.name
                    : n1.exported.value
                ] = l.get());
            }
        }
      }
    }
    function js(e, t) {
      var r = t.global(),
        i = r.find(ge + e.source.value);
      var a;
      if (i) {
        var n = i.get();
        n &&
          (typeof n == "function"
            ? (a = n())
            : (typeof n === "undefined" ? "undefined" : _type_of(n)) ==
                "object" && (a = n));
      }
      if (
        !a ||
        (typeof a === "undefined" ? "undefined" : _type_of(a)) != "object"
      )
        throw new TypeError(
          'Failed to resolve module specifier "'.concat(e.source.value, '"')
        );
      var s = r.find(U);
      if (s) {
        var n1 = s.get();
        n1 &&
          (typeof n1 === "undefined" ? "undefined" : _type_of(n1)) ==
            "object" &&
          N(n1, a);
      }
    }
    function Lt(e, t) {
      var r =
        arguments.length > 2 && arguments[2] !== void 0 ? arguments[2] : {};
      var tmp = r.onlyBlock,
        i = tmp === void 0 ? !1 : tmp,
        a = [],
        s = [];
      for (var n = 0; n < e.body.length; n++) {
        var u = e.body[n];
        u.type === "FunctionDeclaration"
          ? (a.push(u), s.push(n))
          : u.type === "VariableDeclaration" &&
            ["const", "let"].indexOf(u.kind) !== -1
          ? be(u, t, { hoist: !0, onlyBlock: !0 })
          : i || ne(u, t);
      }
      if (s.length) {
        for (var n1 = s.length - 1; n1 > -1; n1--) e.body.splice(s[n1], 1);
        e.body = a.concat(e.body);
      }
    }
    function ne(e, t) {
      switch (e.type) {
        case "VariableDeclaration":
          be(e, t, { hoist: !0 });
          break;
        case "ForInStatement":
        case "ForOfStatement":
          e.left.type === "VariableDeclaration" && be(e.left, t, { hoist: !0 });
        case "ForStatement":
          e.type === "ForStatement" &&
            e.init.type === "VariableDeclaration" &&
            be(e.init, t, { hoist: !0 });
        case "WhileStatement":
        case "DoWhileStatement":
          ne(e.body, t);
          break;
        case "IfStatement":
          ne(e.consequent, t), e.alternate && ne(e.alternate, t);
          break;
        case "BlockStatement":
          for (var r = 0; r < e.body.length; r++) ne(e.body[r], t);
          break;
        case "SwitchStatement":
          for (var r1 = 0; r1 < e.cases.length; r1++)
            for (var i = 0; i < e.cases[r1].consequent.length; i++)
              ne(e.cases[r1].consequent[i], t);
          break;
        case "TryStatement": {
          var r2 = e.block.body;
          for (var s = 0; s < r2.length; s++) ne(r2[s], t);
          var i1 = e.handler && e.handler.body.body;
          if (i1) for (var s1 = 0; s1 < i1.length; s1++) ne(i1[s1], t);
          var a = e.finalizer && e.finalizer.body;
          if (a) for (var s2 = 0; s2 < a.length; s2++) ne(a[s2], t);
          break;
        }
      }
    }
    function M(e, t) {
      var r =
        arguments.length > 2 && arguments[2] !== void 0 ? arguments[2] : {};
      switch (e.type) {
        case "ObjectPattern":
          return Ji(e, t, r);
        case "ArrayPattern":
          return er(e, t, r);
        case "RestElement":
          return Pe(e, t, r);
        case "AssignmentPattern":
          return tr(e, t, r);
        default:
          throw new SyntaxError("Unexpected token");
      }
    }
    function Z(e, t) {
      var r =
        arguments.length > 2 && arguments[2] !== void 0 ? arguments[2] : {};
      var c;
      if (e.generator || e.async) return J(e, t, r);
      var i = r.superClass,
        a = r.construct,
        s = e.params;
      var u = function _target() {
        for (
          var _len = arguments.length, h = new Array(_len), _key = 0;
          _key < _len;
          _key++
        ) {
          h[_key] = arguments[_key];
        }
        var p = new P(t, !0);
        e.type !== "ArrowFunctionExpression" &&
          (p.let("this", this),
          p.let("arguments", arguments),
          p.const(ot, _instanceof(this, _target) ? this.constructor : void 0),
          i ? (p.const(st, i), a && p.let(he, a)) : a && a(this));
        for (var C = 0; C < s.length; C++) {
          var L = s[C];
          L.type === "Identifier"
            ? p.var(L.name, h[C])
            : L.type === "RestElement"
            ? Pe(L, p, { kind: "var", feed: h.slice(C) })
            : M(L, p, { kind: "var", feed: h[C] });
        }
        var S;
        if (
          (e.body.type === "BlockStatement"
            ? (Lt(e.body, p),
              (S = se(e.body, p, { invasived: !0, hoisted: !0 })))
            : ((S = y(e.body, p)),
              e.type === "ArrowFunctionExpression" && ((E.RES = S), (S = E))),
          S === E)
        )
          return S.RES;
        if (_instanceof(this, _target) ? this.constructor : void 0)
          return p.find("this").get();
      };
      e.type === "ArrowFunctionExpression" && w(u, nt, { value: !0 }),
        w(u, "name", { value: (e.id && e.id.name) || "", configurable: !0 }),
        w(u, "length", { value: s.length, configurable: !0 });
      var l = (c = e.loc) == null ? void 0 : c.source;
      return (
        l &&
          w(u, "toString", {
            value: function () {
              return l.substring(e.start, e.end);
            },
            configurable: !0,
          }),
        u
      );
    }
    function qe(e, t) {
      var r = y(e.superClass, t),
        i = e.body.body,
        a = function a(n) {
          for (var u = 0; u < i.length; u++) {
            var l = i[u];
            l.type === "PropertyDefinition" &&
              !l.static &&
              Pt(l, t, { klass: n, superClass: r });
          }
        };
      var s = function s() {
        var n = r ? Ge(this, r) : this;
        return a(n), n;
      };
      for (var n = 0; n < i.length; n++) {
        var u = i[n];
        if (u.type === "MethodDefinition" && u.kind === "constructor") {
          s = Z(u.value, t, { superClass: r, construct: a });
          break;
        }
      }
      return (
        r && Ut(s, r),
        dr(e.body, t, { klass: s, superClass: r }),
        w(s, _e, { value: !0 }),
        w(s, "name", { value: (e.id && e.id.name) || "", configurable: !0 }),
        s
      );
    }
    function gr(e, t, r) {
      var i = r.value,
        a = e.left,
        s = new P(t);
      a.type === "VariableDeclaration"
        ? be(a, s, { feed: i })
        : a.type === "Identifier"
        ? pe(a, t, { getVar: !0 }).set(i)
        : M(a, t, { feed: i });
      var n;
      return (
        e.body.type === "BlockStatement"
          ? (n = se(e.body, s, { invasived: !0 }))
          : (n = y(e.body, s)),
        n
      );
    }
    function Vt(e, t) {
      var r, tmp, i, a, s, n, u, _tmp, _tmp1, _tmp2, n1;
      var _arguments = arguments;
      return _ts_generator(this, function (_state) {
        switch (_state.label) {
          case 0:
            r =
              _arguments.length > 2 && _arguments[2] !== void 0
                ? _arguments[2]
                : {};
            (tmp = r.onlyBlock),
              (i = tmp === void 0 ? !1 : tmp),
              (a = []),
              (s = []);
            n = 0;
            _state.label = 1;
          case 1:
            if (!(n < e.body.length)) return [3, 10];
            u = e.body[n];
            if (!(u.type === "FunctionDeclaration")) return [3, 2];
            _tmp = (a.push(u), s.push(n));
            return [3, 8];
          case 2:
            if (
              !(
                u.type === "VariableDeclaration" &&
                ["const", "let"].indexOf(u.kind) !== -1
              )
            )
              return [3, 4];
            return [5, _ts_values(xe(u, t, { hoist: !0, onlyBlock: !0 }))];
          case 3:
            _tmp1 = _state.sent();
            return [3, 7];
          case 4:
            _tmp2 = i;
            if (_tmp2) return [3, 6];
            return [5, _ts_values(oe(u, t))];
          case 5:
            _tmp2 = _state.sent();
            _state.label = 6;
          case 6:
            _tmp1 = _tmp2;
            _state.label = 7;
          case 7:
            _tmp = _tmp1;
            _state.label = 8;
          case 8:
            _tmp;
            _state.label = 9;
          case 9:
            n++;
            return [3, 1];
          case 10:
            if (s.length) {
              for (n1 = s.length - 1; n1 > -1; n1--) e.body.splice(s[n1], 1);
              e.body = a.concat(e.body);
            }
            return [2];
        }
      });
    }
    function oe(e, t) {
      var _, _tmp, _tmp1, _tmp2, r, r1, i, r2, s, i1, s1, a, s2;
      return _ts_generator(this, function (_state) {
        switch (_state.label) {
          case 0:
            _ = e.type;
            switch (_) {
              case "VariableDeclaration":
                return [3, 1];
              case "ForInStatement":
                return [3, 3];
              case "ForOfStatement":
                return [3, 3];
              case "ForStatement":
                return [3, 6];
              case "WhileStatement":
                return [3, 9];
              case "DoWhileStatement":
                return [3, 9];
              case "IfStatement":
                return [3, 11];
              case "BlockStatement":
                return [3, 15];
              case "SwitchStatement":
                return [3, 20];
              case "TryStatement":
                return [3, 27];
            }
            return [3, 40];
          case 1:
            return [5, _ts_values(xe(e, t, { hoist: !0 }))];
          case 2:
            _state.sent();
            return [3, 40];
          case 3:
            _tmp = e.left.type === "VariableDeclaration";
            if (!_tmp) return [3, 5];
            return [5, _ts_values(xe(e.left, t, { hoist: !0 }))];
          case 4:
            _tmp = _state.sent();
            _state.label = 5;
          case 5:
            _tmp;
            _state.label = 6;
          case 6:
            _tmp1 =
              e.type === "ForStatement" &&
              e.init.type === "VariableDeclaration";
            if (!_tmp1) return [3, 8];
            return [5, _ts_values(xe(e.init, t, { hoist: !0 }))];
          case 7:
            _tmp1 = _state.sent();
            _state.label = 8;
          case 8:
            _tmp1;
            _state.label = 9;
          case 9:
            return [5, _ts_values(oe(e.body, t))];
          case 10:
            _state.sent();
            return [3, 40];
          case 11:
            return [5, _ts_values(oe(e.consequent, t))];
          case 12:
            _state.sent();
            _tmp2 = e.alternate;
            if (!_tmp2) return [3, 14];
            return [5, _ts_values(oe(e.alternate, t))];
          case 13:
            _tmp2 = _state.sent();
            _state.label = 14;
          case 14:
            _tmp2;
            return [3, 40];
          case 15:
            r = 0;
            _state.label = 16;
          case 16:
            if (!(r < e.body.length)) return [3, 19];
            return [5, _ts_values(oe(e.body[r], t))];
          case 17:
            _state.sent();
            _state.label = 18;
          case 18:
            r++;
            return [3, 16];
          case 19:
            return [3, 40];
          case 20:
            r1 = 0;
            _state.label = 21;
          case 21:
            if (!(r1 < e.cases.length)) return [3, 26];
            i = 0;
            _state.label = 22;
          case 22:
            if (!(i < e.cases[r1].consequent.length)) return [3, 25];
            return [5, _ts_values(oe(e.cases[r1].consequent[i], t))];
          case 23:
            _state.sent();
            _state.label = 24;
          case 24:
            i++;
            return [3, 22];
          case 25:
            r1++;
            return [3, 21];
          case 26:
            return [3, 40];
          case 27:
            r2 = e.block.body;
            s = 0;
            _state.label = 28;
          case 28:
            if (!(s < r2.length)) return [3, 31];
            return [5, _ts_values(oe(r2[s], t))];
          case 29:
            _state.sent();
            _state.label = 30;
          case 30:
            s++;
            return [3, 28];
          case 31:
            i1 = e.handler && e.handler.body.body;
            if (!i1) return [3, 35];
            s1 = 0;
            _state.label = 32;
          case 32:
            if (!(s1 < i1.length)) return [3, 35];
            return [5, _ts_values(oe(i1[s1], t))];
          case 33:
            _state.sent();
            _state.label = 34;
          case 34:
            s1++;
            return [3, 32];
          case 35:
            a = e.finalizer && e.finalizer.body;
            if (!a) return [3, 39];
            s2 = 0;
            _state.label = 36;
          case 36:
            if (!(s2 < a.length)) return [3, 39];
            return [5, _ts_values(oe(a[s2], t))];
          case 37:
            _state.sent();
            _state.label = 38;
          case 38:
            s2++;
            return [3, 36];
          case 39:
            return [3, 40];
          case 40:
            return [2];
        }
      });
    }
    function j(e, t) {
      var r, _;
      var _arguments = arguments;
      return _ts_generator(this, function (_state) {
        switch (_state.label) {
          case 0:
            r =
              _arguments.length > 2 && _arguments[2] !== void 0
                ? _arguments[2]
                : {};
            _ = e.type;
            switch (_) {
              case "ObjectPattern":
                return [3, 1];
              case "ArrayPattern":
                return [3, 3];
              case "RestElement":
                return [3, 5];
              case "AssignmentPattern":
                return [3, 7];
            }
            return [3, 9];
          case 1:
            return [5, _ts_values(Ti(e, t, r))];
          case 2:
            return [2, _state.sent()];
          case 3:
            return [5, _ts_values(Ni(e, t, r))];
          case 4:
            return [2, _state.sent()];
          case 5:
            return [5, _ts_values(Ae(e, t, r))];
          case 6:
            return [2, _state.sent()];
          case 7:
            return [5, _ts_values(Ri(e, t, r))];
          case 8:
            return [2, _state.sent()];
          case 9:
            throw new SyntaxError("Unexpected token");
          case 10:
            return [2];
        }
      });
    }
    function J(e, t) {
      var r =
        arguments.length > 2 && arguments[2] !== void 0 ? arguments[2] : {};
      var c;
      if (!e.generator && !e.async) return Z(e, t, r);
      var i = r.superClass,
        a = r.construct,
        s = e.params,
        n = function _target() {
          var _len,
            h,
            _key,
            p,
            _tmp,
            _tmp1,
            _tmp2,
            C,
            L,
            _tmp3,
            _tmp4,
            S,
            _tmp5;
          var _arguments = arguments;
          return _ts_generator(this, function (_state) {
            switch (_state.label) {
              case 0:
                for (
                  _len = _arguments.length, h = new Array(_len), _key = 0;
                  _key < _len;
                  _key++
                ) {
                  h[_key] = _arguments[_key];
                }
                p = new P(t, !0);
                _tmp = e.type !== "ArrowFunctionExpression";
                if (!_tmp) return [3, 5];
                p.let("this", this),
                  p.let("arguments", _arguments),
                  p.const(
                    ot,
                    _instanceof(this, _target) ? this.constructor : void 0
                  );
                if (!i) return [3, 1];
                _tmp1 = (p.const(st, i), a && p.let(he, a));
                return [3, 4];
              case 1:
                _tmp2 = a;
                if (!_tmp2) return [3, 3];
                return [5, _ts_values(a(this))];
              case 2:
                _tmp2 = _state.sent();
                _state.label = 3;
              case 3:
                _tmp1 = _tmp2;
                _state.label = 4;
              case 4:
                _tmp = _tmp1;
                _state.label = 5;
              case 5:
                _tmp;
                C = 0;
                _state.label = 6;
              case 6:
                if (!(C < s.length)) return [3, 14];
                L = s[C];
                if (!(L.type === "Identifier")) return [3, 7];
                _tmp3 = p.var(L.name, h[C]);
                return [3, 12];
              case 7:
                if (!(L.type === "RestElement")) return [3, 9];
                return [
                  5,
                  _ts_values(Ae(L, p, { kind: "var", feed: h.slice(C) })),
                ];
              case 8:
                _tmp4 = _state.sent();
                return [3, 11];
              case 9:
                return [5, _ts_values(j(L, p, { kind: "var", feed: h[C] }))];
              case 10:
                _tmp4 = _state.sent();
                _state.label = 11;
              case 11:
                _tmp3 = _tmp4;
                _state.label = 12;
              case 12:
                _tmp3;
                _state.label = 13;
              case 13:
                C++;
                return [3, 6];
              case 14:
                if (!(e.body.type === "BlockStatement")) return [3, 17];
                return [5, _ts_values(Vt(e.body, p))];
              case 15:
                _state.sent();
                return [
                  5,
                  _ts_values(ae(e.body, p, { invasived: !0, hoisted: !0 })),
                ];
              case 16:
                _tmp5 = S = _state.sent();
                return [3, 19];
              case 17:
                return [5, _ts_values(d(e.body, p))];
              case 18:
                _tmp5 =
                  ((S = _state.sent()),
                  e.type === "ArrowFunctionExpression" &&
                    ((E.RES = S), (S = E)));
                _state.label = 19;
              case 19:
                if ((_tmp5, S === E)) return [2, S.RES];
                if (_instanceof(this, _target) ? this.constructor : void 0)
                  return [2, p.find("this").get()];
                return [2];
            }
          });
        };
      var u;
      e.async && e.generator
        ? (u = function u() {
            var h = n.apply(this, arguments);
            var p = Promise.resolve(),
              S = !1;
            var C = function (K) {
                return (p = p
                  .then(function () {
                    return Ct(h, N({ fullRet: !0 }, K));
                  })
                  .catch(function (de) {
                    if (!S) return (S = !0), Promise.reject(de);
                  }));
              },
              L = {
                next: function (K) {
                  return C({ res: K });
                },
                throw: function (K) {
                  return C({ err: K });
                },
                return: function (K) {
                  return C({ ret: K });
                },
              };
            return (
              typeof Symbol == "function" &&
                (L[Symbol.iterator] = function () {
                  return this;
                }),
              L
            );
          })
        : e.async
        ? (u = function u() {
            return Ct(n.apply(this, arguments));
          })
        : (u = n),
        w(u, nt, { value: !0 }),
        w(u, "name", { value: (e.id && e.id.name) || "", configurable: !0 }),
        w(u, "length", { value: s.length, configurable: !0 });
      var l = (c = e.loc) == null ? void 0 : c.source;
      return (
        l &&
          w(u, "toString", {
            value: function () {
              return l.substring(e.start, e.end);
            },
            configurable: !0,
          }),
        u
      );
    }
    function We(e, t) {
      var r, i, a, s, n, u;
      return _ts_generator(this, function (_state) {
        switch (_state.label) {
          case 0:
            return [5, _ts_values(d(e.superClass, t))];
          case 1:
            (r = _state.sent()),
              (i = e.body.body),
              (a = function a(n) {
                var u, l, _tmp;
                return _ts_generator(this, function (_state) {
                  switch (_state.label) {
                    case 0:
                      u = 0;
                      _state.label = 1;
                    case 1:
                      if (!(u < i.length)) return [3, 5];
                      l = i[u];
                      _tmp = l.type === "PropertyDefinition" && !l.static;
                      if (!_tmp) return [3, 3];
                      return [
                        5,
                        _ts_values(It(l, t, { klass: n, superClass: r })),
                      ];
                    case 2:
                      _tmp = _state.sent();
                      _state.label = 3;
                    case 3:
                      _tmp;
                      _state.label = 4;
                    case 4:
                      u++;
                      return [3, 1];
                    case 5:
                      return [2];
                  }
                });
              });
            s = function s() {
              var n;
              return _ts_generator(this, function (_state) {
                switch (_state.label) {
                  case 0:
                    n = r ? Ge(this, r) : this;
                    return [5, _ts_values(a(n))];
                  case 1:
                    return [2, (_state.sent(), n)];
                }
              });
            };
            for (n = 0; n < i.length; n++) {
              u = i[n];
              if (u.type === "MethodDefinition" && u.kind === "constructor") {
                s = J(u.value, t, { superClass: r, construct: a });
                break;
              }
            }
            r && Ut(s, r);
            return [5, _ts_values(Hi(e.body, t, { klass: s, superClass: r }))];
          case 2:
            return [
              2,
              (_state.sent(),
              w(s, _e, { value: !0 }),
              w(s, "name", {
                value: (e.id && e.id.name) || "",
                configurable: !0,
              }),
              s),
            ];
        }
      });
    }
    function Tt(e, t, r) {
      var i, a, s, _tmp, _tmp1, n, _tmp2;
      return _ts_generator(this, function (_state) {
        switch (_state.label) {
          case 0:
            (i = r.value), (a = e.left), (s = new P(t));
            if (!(a.type === "VariableDeclaration")) return [3, 2];
            return [5, _ts_values(xe(a, s, { feed: i }))];
          case 1:
            _tmp = _state.sent();
            return [3, 7];
          case 2:
            if (!(a.type === "Identifier")) return [3, 4];
            return [5, _ts_values(pe(a, t, { getVar: !0 }))];
          case 3:
            _tmp1 = _state.sent().set(i);
            return [3, 6];
          case 4:
            return [5, _ts_values(j(a, t, { feed: i }))];
          case 5:
            _tmp1 = _state.sent();
            _state.label = 6;
          case 6:
            _tmp = _tmp1;
            _state.label = 7;
          case 7:
            _tmp;
            if (!(e.body.type === "BlockStatement")) return [3, 9];
            return [5, _ts_values(ae(e.body, s, { invasived: !0 }))];
          case 8:
            _tmp2 = n = _state.sent();
            return [3, 11];
          case 9:
            return [5, _ts_values(d(e.body, s))];
          case 10:
            _tmp2 = n = _state.sent();
            _state.label = 11;
          case 11:
            return [2, (_tmp2, n)];
        }
      });
    }
    var Us = 15,
      Rt = /*#__PURE__*/ (function () {
        function Rt() {
          var t =
            arguments.length > 0 && arguments[0] !== void 0 ? arguments[0] : {};
          _class_call_check(this, Rt);
          (this.options = { ecmaVersion: "latest" }),
            (this.scope = new P(null, !0)),
            (this.exports = {});
          var tmp = t.ecmaVer,
            r = tmp === void 0 ? "latest" : tmp,
            tmp1 = t.sandBox,
            i = tmp1 === void 0 ? !0 : tmp1,
            tmp2 = t.sourceType,
            a = tmp2 === void 0 ? "script" : tmp2;
          if (
            (typeof r == "number" && (r -= r < 2015 ? 0 : 2009),
            r !== "latest" && r !== 3 && (r < 5 || r > Us))
          )
            throw new Error("unsupported ecmaVer");
          if (
            ((this.options.ecmaVersion = r), (this.options.sourceType = a), i)
          ) {
            var s = Er();
            this.scope.let("globalThis", s),
              this.scope.let("window", s),
              this.scope.let("self", s),
              this.scope.let("this", s);
          } else
            this.scope.let("globalThis", f),
              this.scope.let("window", f),
              this.scope.let("self", f),
              this.scope.let("this", f);
          this.scope.const(a === "module" ? U : "exports", (this.exports = {}));
        }
        _create_class(Rt, [
          {
            key: "import",
            value: function _import(t, r) {
              if (
                (typeof t == "string" && (t = _define_property({}, t, r)),
                (typeof t === "undefined" ? "undefined" : _type_of(t)) !=
                  "object")
              )
                return;
              var i = ct(t);
              for (var a = 0; a < i.length; a++) {
                var s = i[a],
                  n = this.options.sourceType === "module" ? ge + s : s;
                this.scope.var(n, t[s]);
              }
            },
          },
          {
            key: "parse",
            value: function parse(t, r) {
              return typeof r == "function"
                ? r(t, N({}, this.options))
                : ha(t, this.options);
            },
          },
          {
            key: "run",
            value: function run(t) {
              var r = typeof t == "string" ? this.parse(t) : t,
                i = this.scope;
              this.options.sourceType === "module" &&
              (this.options.ecmaVersion === "latest" ||
                this.options.ecmaVersion >= 13)
                ? Ct(
                    (function () {
                      return _ts_generator(this, function (_state) {
                        switch (_state.label) {
                          case 0:
                            return [5, _ts_values(Vt(r, i))];
                          case 1:
                            _state.sent();
                            return [5, _ts_values(d(r, i))];
                          case 2:
                            _state.sent();
                            return [2];
                        }
                      });
                    })()
                  )
                : (Lt(r, i), y(r, i));
            },
          },
        ]);
        return Rt;
      })();
    Rt.version = fa.version;
    var Nt = Rt;
    return Nt;
  });
})();
