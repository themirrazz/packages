((args, sp=[]) => {
    const keys = [];
    const argv = {
        length: 0,
        keys: () => keys,
        toArray: function () {
            /** @type {string[]} */
            const a0 = [];
            for(let i = 0; i < this.length; i++) {
                a0.push(this[i]);
            }
            return a0;
        },
        includes: function (k) { return this.keys().includes(k); },
        valueAt: function (d) { return this[d] },
        at: function (d) { return this[d] },
        indexOf: function (k) {
            for(let i = 0; i < this.length; i++)
                if(this[i] === k) return i;
            return -1;
        },
        map: function(...o0) { return argv.toArray().map(...o0) },
        reduce: function(...o0) { return argv.toArray().reduce(...o0) },
        join: function(...o0) { return argv.toArray().join(...o0) },
        forEach: function(...o0) { return argv.toArray().forEach(...o0) },
        forEachAsync: function(...o0) { return argv.toArray().forEachAsync(...o0) },
        forOptions: function (cb) {
            this.keys().forEach((key, i) => {
                cb(key, this[key], i, this);
            });
        },
        toString: () => "[object ArgvArray]"
    };
    let o = ''
    args.forEach(arg => {
        if(arg.startsWith('--')) {
            const s = arg.slice(2).split('=');
            const a0 = s.shift();
            keys.push(a0);
            if(s.length <= 0) {
                argv[a0] = true;
            } else {
                argv[a0] = s[0];
            }
            if(sp.includes(a0)) o = a0;
        } else if(arg.startsWith('-')) {
            const s = arg.slice(1).split('=');
            const a0 = s.shift();
            keys.push(a0);
            if(s.length <= 0) {
                argv[a0] = true;
            } else {
                argv[a0] = s[0];
            }
            if(sp.includes(a0)) o = a0;
        } else if(o) {
            argv[o] = arg;
            o = '';
        } else {
            argv[argv.length] = arg;
            argv.length++;
        }
    });
    return argv;
})