(({stdio, threads}={}) => {
    let n = new Map();
let e = null;
let i = /.+:wasm-function\[[0-9]+]:0x([0-9a-f]+).*/;
let k = function (e) {
    let t = n.get(e);
    if (typeof t === "undefined") {
        t = new Function("return " + e + ";");
        n.set(e, t);
    }
    return t();
};
let D = function (e, t) {
    new Function("value", e + " = value;")(t);
};
function y(e, t, n, r) {
    let o = { exports: null, userExports: t, stackDeobfuscator: null };
    if (!E()) {
        a(e);
    }
    l(e);
    u(e, o);
    s(e, o, n, r);
    c(e, o);
    m(e, o);
    e.teavmMath = Math;
    return {
        supplyExports(e) {
            o.exports = e;
        },
        supplyStackDeobfuscator(e) {
            o.stackDeobfuscator = e;
        },
    };
}
let W = Symbol("javaException");
class M extends Error {
    #context;
    constructor(e, t) {
        super();
        this.#context = e;
        this[W] = t;
        e.exports["teavm.setJsException"](t, this);
    }
    get message() {
        let t = this.#context.exports["teavm.exceptionMessage"];
        let n = this.#context.exports["teavm.stringToJs"];
        if (typeof t === "function" && typeof n === "function") {
            let e = t(this[W]);
            if (e != null) {
                return n(e);
            }
        }
        return "(could not fetch message)";
    }
}
function a(e) {
    e["wasm:js-string"] = {
        fromCharCode: (e) => String.fromCharCode(e),
        fromCharCodeArray: () => {
            throw new Error("Not supported");
        },
        intoCharCodeArray: () => {
            throw new Error("Not supported");
        },
        concat: (e, t) => e + t,
        charCodeAt: (e, t) => e.charCodeAt(t),
        length: (e) => e.length,
        substring: (e, t, n) => e.substring(t, n),
    };
}
function l(e) {
    e.teavmDate = {
        currentTimeMillis: () => new Date().getTime(),
        dateToString: (e) => new Date(e).toString(),
        getYear: (e) => new Date(e).getFullYear(),
        setYear(e, t) {
            let n = new Date(e);
            n.setFullYear(t);
            return n.getTime();
        },
        getMonth: (e) => new Date(e).getMonth(),
        setMonth(e, t) {
            let n = new Date(e);
            n.setMonth(t);
            return n.getTime();
        },
        getDate: (e) => new Date(e).getDate(),
        setDate(e, t) {
            let n = new Date(e);
            n.setDate(t);
            return n.getTime();
        },
        create: (e, t, n, r, o, a) => new Date(e, t, n, r, o, a).getTime(),
        createFromUTC: (e, t, n, r, o, a) => Date.UTC(e, t, n, r, o, a),
    };
}
function u(e) {
    let t = "";
    let n = "";
    e.teavmConsole = {
        putcharStderr(e) {
            if (e === 10) {
                stdio && stdio.stderr ? stdio.stderr(t) : console.error(t);
                t = "";
            } else {
                t += String.fromCharCode(e);
            }
        },
        putcharStdout(e) {
            if (e === 10) {
                stdio && stdio.stdout ? stdio.stdout(n) : console.log(n);
                n = "";
            } else {
                n += String.fromCharCode(e);
            }
        },
    };
}
function s(e, r, t, o) {
    let a = t.memory || {};
    let l = new FinalizationRegistry((e) => {
        let t = r.exports["teavm.reportGarbageCollectedValue"];
        if (typeof t !== "undefined") {
            t(e.queue, e.ref);
        }
    });
    let n = new FinalizationRegistry((e) => {
        let t = r.exports["teavm.reportGarbageCollectedString"];
        if (typeof t === "function") {
            t(e);
        }
    });
    e.teavm = {
        createWeakRef(e, t, n) {
            if (n !== null) {
                l.register(e, { ref: t, queue: n });
            }
            return new WeakRef(e);
        },
        deref: (e) => {
            let t = e.deref();
            return t !== void 0 ? t : null;
        },
        createStringWeakRef(e, t) {
            n.register(e, t);
            return new WeakRef(e);
        },
        stringDeref: (e) => e.deref(),
        takeStackTrace() {
            let t = new Error().stack;
            let n = [];
            for (let e of t.split("\n")) {
                let t = i.exec(e);
                if (t !== null && t.length >= 2) {
                    let e = parseInt(t[1], 16);
                    n.push(e);
                }
            }
            return {
                getStack() {
                    let e;
                    if (r.stackDeobfuscator) {
                        try {
                            e = r.stackDeobfuscator(n);
                        } catch (e) {
                            console.warn("Could not deobfuscate stack", e);
                        }
                    }
                    if (!e) {
                        e = n.map((e) => {
                            return {
                                className: "java.lang.Throwable$FakeClass",
                                method: "fakeMethod",
                                file: "Throwable.java",
                                line: e,
                            };
                        });
                    }
                    return e;
                },
            };
        },
        decorateException(e) {
            new M(r, e);
        },
        linearMemory() {
            return r.exports["teavm.memory"].buffer;
        },
        notifyHeapResized: a.onResize || function () {},
    };
    if (o && f(o)) {
        let r = a["external"];
        if (!r) {
            let e = p(o);
            let t = a.minSize || e.min || 0;
            let n = a.maxSize || e.max;
            r = new WebAssembly.Memory({ shared: a.shared === true, initial: t, maximum: n });
        }
        e.teavm.memory = r;
    }
}
function c(e) {
    e.teavmAsync = {
        offer(e, t, n) {
            if(threads && threads.onOfferCreated) threads.onOfferCreated();
            let r = Math.max(0, n - Date.now());
            return setTimeout(() => {
                t(e);
                if(threads && threads.onSyncCodeFinished) threads.onSyncCodeFinished();
            }, r);
        },
        kill(e) {
            clearTimeout(e);
        },
    };
}
function f(e) {
    return (
        WebAssembly.Module.imports(e).findIndex(
            ({ module: e, name: t, kind: n }) => e === "teavm" && t === "memory" && n === "memory"
        ) >= 0
    );
}
function p(e) {
    let t = WebAssembly.Module.customSections(e, "teavm.memoryRequirements");
    if (t.length !== 1) {
        return {};
    }
    return JSON.parse(new TextDecoder().decode(t[0]));
}
function m(o, l) {
    let i = Symbol("javaObject");
    let u = Symbol("functions");
    let a = Symbol("functionOrigin");
    let s = Symbol("wrapperCallMarker");
    let c = new WeakMap();
    let n = new WeakMap();
    let r = new Map();
    let f = new FinalizationRegistry((e) => r.delete(e));
    let p = new WeakMap();
    let t = 2463534242;
    let m = () => {
        let e = t;
        e ^= e << 13;
        e ^= e >>> 17;
        e ^= e << 5;
        t = e;
        return e;
    };
    function y(e) {
        return e;
    }
    function d(n) {
        let r = "";
        let e = n.charAt(0);
        r += w(e) ? e : "_";
        for (let t = 1; t < n.length; ++t) {
            let e = n.charAt(t);
            r += h(e) ? e : "_";
        }
        return r;
    }
    function w(e) {
        return (e >= "A" && e <= "Z") || (e >= "a" && e <= "z") || e === "_" || e === "$";
    }
    function h(e) {
        return w(e) || (e >= "0" && e <= "9");
    }
    function e(e, t, n) {
        if (e === null) {
            D(t, n);
        } else {
            e[t] = n;
        }
    }
    function b(a) {
        if (a instanceof WebAssembly.Exception) {
            let r = l.exports["teavm.javaException"];
            let o = l.exports["teavm.getJsException"];
            if (a.is(r)) {
                let e = a.getArg(r, 0);
                let t = x(e);
                if (t !== null) {
                    return t;
                }
                let n = o(e);
                if (typeof n === "undefined") {
                    n = new M(l, e);
                }
                return n;
            }
        }
        return a;
    }
    function g(e) {
        if (W in e) {
            return e[W];
        } else {
            return l.exports["teavm.js.wrapException"](e);
        }
    }
    function v(e) {
        l.exports["teavm.js.throwException"](g(e));
    }
    function x(e) {
        return l.exports["teavm.js.extractException"](e);
    }
    function j(e) {
        throw b(e);
    }
    function J(e, t) {
        try {
            return e !== null ? e[t] : k(t);
        } catch (e) {
            v(e);
        }
    }
    function A(e, t) {
        let n = [];
        let r = [];
        for (let t = 0; t < e.length; ++t) {
            let e = "p" + t;
            n.push(e);
            r.push(e);
        }
        if (t) {
            let e = r.length - 1;
            r[e] = "..." + r[e];
        }
        let o = r.join(", ");
        return new Function(
            "rethrowJavaAsJs",
            "fn",
            `return function(${o}) {\n` +
                `    try {\n` +
                `        return fn(${n.join(", ")});\n` +
                `    } catch (e) {\n` +
                `        rethrowJavaAsJs(e);\n` +
                `    }\n` +
                `};`
        )(j, e);
    }
    function C(e, t) {
        return new Function(
            "constructor",
            `return function ${e}(marker, javaObject) {\n` +
                `    return constructor.call(this, marker, javaObject);\n` +
                `}\n`
        )(t);
    }
    o.teavmJso = {
        stringBuiltinsSupported: () => E(),
        isUndefined: (e) => typeof e === "undefined",
        emptyArray: () => [],
        appendToArray: (e, t) => e.push(t),
        unwrapBoolean: (e) => (e ? 1 : 0),
        wrapBoolean: (e) => !!e,
        getProperty: J,
        setProperty: e,
        setPropertyPure: e,
        global(e) {
            try {
                return k(e);
            } catch (e) {
                v(e);
            }
        },
        createClass(e, t, n) {
            e = d(e || "JavaObject");
            let r;
            let o = C(e, function (e, t) {
                if (e === s) {
                    r.call(this, t);
                } else if (n === null) {
                    throw new Error("This class can't be instantiated directly");
                } else {
                    try {
                        return n.apply(null, arguments);
                    } catch (e) {
                        j(e);
                    }
                }
            });
            if (t === null) {
                r = function (e) {
                    this[i] = e;
                    this[u] = null;
                };
            } else {
                r = function (e) {
                    t.call(this, e);
                };
            }
            o.prototype = Object.create(t ? t.prototype : Object.prototype);
            o.prototype.constructor = o;
            let a = C(e, function (e) {
                return o.call(this, s, e);
            });
            a[s] = o;
            a.prototype = o.prototype;
            return a;
        },
        exportClass(e) {
            return e[s];
        },
        defineMethod(e, t, n, r) {
            let o = [];
            let a = [];
            for (let t = 1; t < n.length; ++t) {
                let e = "p" + t;
                o.push(e);
                a.push(e);
            }
            if (r) {
                let e = a.length - 1;
                a[e] = "..." + a[e];
            }
            let l = a.join(", ");
            e.prototype[t] = new Function(
                "rethrowJavaAsJs",
                "fn",
                `return function(${l}) {\n` +
                    `    try {\n` +
                    `        return fn(${["this", o].join(", ")});\n` +
                    `    } catch (e) {\n` +
                    `        rethrowJavaAsJs(e);\n` +
                    `    }\n` +
                    `};`
            )(j, n);
        },
        defineStaticMethod(e, t, n, r) {
            e[t] = A(n, r);
        },
        defineFunction: A,
        defineProperty(e, t, n, r) {
            let o = {
                get() {
                    try {
                        return n(this);
                    } catch (e) {
                        j(e);
                    }
                },
            };
            if (r !== null) {
                o.set = function (e) {
                    try {
                        r(this, e);
                    } catch (e) {
                        j(e);
                    }
                };
            }
            Object.defineProperty(e.prototype, t, o);
        },
        defineStaticProperty(e, t, n, r) {
            let o = {
                get() {
                    try {
                        return n();
                    } catch (e) {
                        j(e);
                    }
                },
            };
            if (r !== null) {
                o.set = function (e) {
                    try {
                        r(e);
                    } catch (e) {
                        j(e);
                    }
                };
            }
            Object.defineProperty(e, t, o);
        },
        javaObjectToJS(e, t) {
            if (e === null) {
                return null;
            }
            let n = c.get(e);
            if (typeof n != "undefined") {
                let e = n.deref();
                if (typeof e !== "undefined") {
                    return e;
                }
            }
            let r = new t(e);
            c.set(e, new WeakRef(r));
            return r;
        },
        unwrapJavaObject(e) {
            return e[i];
        },
        asFunction(e, t) {
            if (e === null || e === undefined) {
                return null;
            }
            let n = e[u];
            if (n === null) {
                n = Object.create(null);
                e[u] = n;
            }
            let r = n[t];
            if (typeof r !== "function") {
                r = function () {
                    return e[t].apply(e, arguments);
                };
                r[a] = e;
                n[t] = r;
            }
            return r;
        },
        functionAsObject(t, n) {
            if (t === null || t === void 0) {
                return null;
            }
            let r = t[a];
            if (typeof r !== "undefined") {
                let e = r[u];
                if (e !== void 0 && e[n] === t) {
                    return r;
                }
            }
            return {
                [n]: function (...e) {
                    try {
                        return t(...e);
                    } catch (e) {
                        j(e);
                    }
                },
            };
        },
        wrapObject(t) {
            if (t === null) {
                return null;
            }
            if (typeof t === "object" || typeof t === "function" || typeof "obj" === "symbol") {
                let e = t[i];
                if (typeof e === "object") {
                    return e;
                }
                e = n.get(t);
                if (e !== void 0) {
                    e = e.deref();
                    if (e !== void 0) {
                        return e;
                    }
                }
                e = l.exports["teavm.jso.createWrapper"](t);
                n.set(t, new WeakRef(e));
                return e;
            } else {
                let e = r.get(t);
                if (e !== void 0) {
                    e = e.deref();
                    if (e !== void 0) {
                        return e;
                    }
                }
                e = l.exports["teavm.jso.createWrapper"](t);
                r.set(t, new WeakRef(e));
                f.register(e, t);
                return e;
            }
        },
        isPrimitive: (e, t) => typeof e === t || e === null,
        instanceOf: (e, t) => e instanceof t,
        instanceOfOrNull: (e, t) => e === null || e instanceof t,
        sameRef: (e, t) => e === t,
        hashCode: (t) => {
            if (typeof t === "object" || typeof t === "function" || typeof t === "symbol") {
                let e = p.get(t);
                if (typeof e === "number") {
                    return e;
                }
                e = m();
                p.set(t, e);
                return e;
            } else if (typeof t === "number") {
                return t | 0;
            } else if (typeof t === "bigint") {
                return BigInt.asIntN(t, 32);
            } else if (typeof t === "boolean") {
                return t ? 1 : 0;
            } else {
                return 0;
            }
        },
        apply: (e, t, n) => {
            try {
                if (e === null) {
                    let e = k(t);
                    return e(...n);
                } else {
                    return e[t](...n);
                }
            } catch (e) {
                v(e);
            }
        },
        concatArray: (e, t) => [...e, ...t],
        getJavaException: (e) => e[W],
        getJSException: (e) => {
            let t = l.exports["teavm.getJsException"];
            return t(e);
        },
        jsExports: () => l.userExports,
    };
    for (let e of [
        "wrapByte",
        "wrapShort",
        "wrapChar",
        "wrapInt",
        "wrapLong",
        "wrapFloat",
        "wrapDouble",
        "unwrapByte",
        "unwrapShort",
        "unwrapChar",
        "unwrapInt",
        "unwrapLong",
        "unwrapFloat",
        "unwrapDouble",
    ]) {
        o.teavmJso[e] = y;
    }
    function S(e) {
        try {
            return e();
        } catch (e) {
            v(e);
        }
    }
    let F = [];
    for (let r = 0; r < 32; ++r) {
        let e = F.length === 0 ? "" : F.join(", ");
        let t = [...F, "body"].join(", ");
        o.teavmJso["createFunction" + r] = new Function(
            "wrapCallFromJavaToJs",
            ...F,
            "body",
            `return new Function('wrapCallFromJavaToJs', ${t}).bind(this, wrapCallFromJavaToJs);`
        ).bind(null, S);
        o.teavmJso["bindFunction" + r] = (e, ...t) => e.bind(null, ...t);
        o.teavmJso["callFunction" + r] = new Function(
            "rethrowJsAsJava",
            "fn",
            ...F,
            `try {\n` + `    return fn(${e});\n` + `} catch (e) {\n` + `    rethrowJsAsJava(e);\n` + `}`
        ).bind(null, v);
        o.teavmJso["callMethod" + r] = new Function(
            "rethrowJsAsJava",
            "getGlobalName",
            "instance",
            "method",
            ...F,
            `try {\n` +
                `    return instance !== null\n` +
                `        ? instance[method](${e})\n` +
                `        : getGlobalName(method)(${e});\n` +
                `} catch (e) {\n` +
                `    rethrowJsAsJava(e);\n` +
                `}`
        ).bind(null, v, k);
        o.teavmJso["construct" + r] = new Function(
            "rethrowJsAsJava",
            "constructor",
            ...F,
            `try {\n` + `    return new constructor(${e});\n` + `} catch (e) {\n` + `    rethrowJsAsJava(e);\n` + `}`
        ).bind(null, v);
        o.teavmJso["arrayOf" + r] = new Function(...F, "return [" + e + "]");
        let n = "p" + (r + 1);
        F.push(n);
    }
}
function t(e) {
    return new Proxy(e, {
        get(e, t) {
            let n = e[t];
            return new WebAssembly.Global({ value: "externref", mutable: false }, n);
        },
    });
}
async function d(t, a) {
    let n = [];
    let r = {};
    for (let { module: o, name: e } of w(t)) {
        if (o in a) {
            continue;
        }
        let t = r[o];
        if (t === void 0) {
            let e = [];
            t = e;
            r[o] = t;
            n.push(
                (async () => {
                    let n = await import(o);
                    let r = {};
                    for (let t of e) {
                        let e = t === "__self__" ? n : n[t];
                        r[t] = new WebAssembly.Global({ value: "externref", mutable: false }, e);
                    }
                    a[o] = r;
                })()
            );
        }
        t.push(e);
    }
    if (n.length === 0) {
        return;
    }
    await Promise.all(n);
}
function w(e) {
    let t = WebAssembly.Module.customSections(e, "teavm.imports");
    if (t.length !== 1) {
        return WebAssembly.Module.imports(e).filter((e) => e.kind === "global");
    }
    return JSON.parse(new TextDecoder().decode(t[0]));
}
async function r(e, t) {
    if (!t) {
        t = {};
    }
    let n = t.nodejs || typeof process !== "undefined";
    let r = t.stackDeobfuscator || {};
    let o = r.infoLocation || "auto";
    let a = h(e, n);
    let [l, i, u] = await Promise.all([r.enabled ? b(e, r, n) : Promise.resolve(null), a, A(e, o, r, n)]);
    const s = {};
    let c = {};
    const f = y(s, c, t, i);
    if (typeof t.installImports !== "undefined") {
        t.installImports(s);
    }
    if (!t.noAutoImports) {
        await d(i, s);
    }
    let p = await WebAssembly.instantiate(i, s);
    f.supplyExports(p.exports);
    if (l) {
        let e = o === "auto" || o === "embedded" ? i : null;
        let t = J(e, u, l);
        if (t !== null) {
            f.supplyStackDeobfuscator(t);
        }
    }
    let m = { exports: c, instance: p, module: p.module };
    for (let t in p.exports) {
        let e = p.exports[t];
        if (e instanceof WebAssembly.Global) {
            Object.defineProperty(c, t, { get: () => e.value });
        }
    }
    return m;
}
async function h(e, t) {
    if (typeof e !== "string") {
        return await WebAssembly.compile(e, { builtins: ["js-string"] });
    }
    let [n, r] = await v(e, t);
    let o = await WebAssembly.compileStreaming(n, { builtins: ["js-string"] });
    r();
    return o;
}
function E() {
    if (j === null) {
        let e = new Int8Array([
            0, 97, 115, 109, 1, 0, 0, 0, 1, 4, 1, 96, 0, 0, 2, 23, 1, 14, 119, 97, 115, 109, 58, 106, 115, 45, 115, 116,
            114, 105, 110, 103, 4, 99, 97, 115, 116, 0, 0, 3, 1, 0, 5, 4, 1, 1, 0, 0, 10, -127, -128, -128, 0, 0,
        ]);
        j = !WebAssembly.validate(e, { builtins: ["js-string"] });
    }
    return j;
}
async function b(e, t, n) {
    if (typeof e !== "string" && !t.path) {
        return null;
    }
    try {
        const r = {};
        const o = y(r, {}, {});
        const a = await g(t.path, e, n, r);
        o.supplyExports(a.exports);
        return a;
    } catch (e) {
        console.warn("Could not load deobfuscator", e);
        return null;
    }
}
async function g(e, t, n, r) {
    if (typeof e === "object") {
        return await WebAssembly.instantiate(e, r, { builtins: ["js-string"] });
    }
    const o = e || t + "-deobfuscator.wasm";
    let [a, l] = await v(o, n);
    const { instance: i } = await WebAssembly.instantiateStreaming(a, r, { builtins: ["js-string"] });
    l();
    return i;
}
async function v(r, e) {
    let o;
    let a;
    if (!e || true) {
        o = await fetch(r);
        a = () => {};
    } else {
        let e = await x();
        let t = await e.open(r, "r");
        let n = await t.readableWebStream();
        o = new Response(n, { headers: { "Content-Type": "application/wasm" } });
        a = () => t.close();
    }
    return [o, a];
}
let o;
async function x() {
    if (!o) {
        o = import("node:fs/promises");
    }
    return await o;
}
let j = null;
function J(e, t, n) {
    let r = null;
    let o = false;
    function a() {
        if (!o) {
            o = true;
            if (t !== null) {
                try {
                    r = n.exports.createFromExternalFile.value(t);
                } catch (e) {
                    console.warn("Could not load create deobfuscator", e);
                }
            }
            if (r == null && e !== null) {
                try {
                    r = n.exports.createForModule.value(e);
                } catch (e) {
                    console.warn("Could not create deobfuscator from module data", e);
                }
            }
        }
    }
    return (e) => {
        a();
        return r !== null ? r.deobfuscate(e) : [];
    };
}
async function A(e, t, n, r) {
    if (!n.enabled) {
        return null;
    }
    if (typeof e !== "string" && !n.externalInfoPath) {
        return null;
    }
    if (t !== "auto" && t !== "external") {
        return null;
    }
    if (typeof n.externalInfoPath === "object") {
        return n.externalInfoPath;
    }
    let o = n.externalInfoPath || e + ".teadbg";
    let a;
    if (!r) {
        let e = await fetch(o);
        if (!e.ok) {
            return null;
        }
        a = await e.arrayBuffer();
    } else {
        let e = await x();
        a = (await e.readFile(o)).buffer;
    }
    return new Int8Array(a);
}

return { load: r, defaults: y, wrapImport: t };
});